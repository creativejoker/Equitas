from HTTPClient import NVPair
from net.grinder.script.Grinder import grinder
from java.lang import String
from java.lang import Integer
from java.util.regex import Pattern
import sys
import config.settings
import scripts
from utils.parameters import ListParameter
from utils.parameters import RangeParameter
import utils.parse
import utils.random
import utils.baconLoremIpsum

class CourseSearch(scripts.base.Base):

    def __init__(self, request,bblearn):
        scripts.base.Base.__init__(self, request)
        self.bblearn=bblearn

    def openCourseSearch(self):
        #utils.webservice.getProviderProfile(self,self.bblearn,"EXTERNAL")
        self.GET("/webapps/blackboard/execute/courseManager?sourceType=COURSES")
    def openCourseSearchLogic(self):
        #Try to extract the grade form
        courseSearchForm=utils.parse.extractOnce(self.lastPage,'<form  method="post" name="courseManagerFormSearch"', ".+?", '</form>',False )
       
        #If the gradeform is empty, there's nothing to do so we should return False
        if courseSearchForm =="":
            self.info("CourseSearch.submitCourseSearch(): no course form found skipping")
            return  False
        
        #Extract the URL for the post
        self.submitCourseSearchUrl = utils.parse.extractOnce(courseSearchForm,'action="', ".+?", '"', False)
        
        #Extracts all parameters and puts them into an NVpair
        self.submitCourseSearchParameters =utils.parse.extractNVPairsFromForm(courseSearchForm)
        
        #Randomly select a grade
        grade=str(utils.random.randomlySelectInt(100))
        
        #actionString=Search&sourceType=COURSES&courseInfoSearchKeyString=CourseName&courseInfoSearchOperatorString=Contains&courseInfoSearchText=b
        #&dateCreatedSearchOperatorString=LessThan&bbDateTimePicker_datetime=2018-11-25 23:59:00&pickdate=&pickname=&bbDateTimePicker_date=11/25/2018
        #&filterNodeForm.selectedNode=ALL_ENTITIES
       
        #Adds additional post data that is not part of the form and handled through javascript
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'actionString', "Search" )
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'sourceType', "COURSES" )
        
        #Course search type
        courseInfoSearchKeyStringOptions = ['CourseName','CourseId','CourseDescription','Instructor','DataSourceKey','Term']
        courseInfoSearchKeyStringOptionsRandomlySelected = utils.random.randomlySelectValueFromList(courseInfoSearchKeyStringOptions)
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'courseInfoSearchKeyString',courseInfoSearchKeyStringOptionsRandomlySelected)
        
        #Operator String
        courseInfoSearchOperatorStringOptions = ['Contains','Equals','StartsWith','NotBlank']
        courseInfoSearchOperatorStringOptionsRandomlySelected = utils.random.randomlySelectValueFromList(courseInfoSearchOperatorStringOptions)
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'courseInfoSearchOperatorString',courseInfoSearchOperatorStringOptionsRandomlySelected)
        
        #SEARCH TEXT
        searchText = utils.baconLoremIpsum.getSearchText()
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'courseInfoSearchText',searchText)
        
        #DATE RANGE
        
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'dateCreatedSearchOperatorString',"LessThan")
        #TODO, this data is currently hard coded for 11-25-2018 which is fine, but probably should make this dynamic at some point
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'bbDateTimePicker_datetime',"2018-11-25 23:59:00")
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'pickdate',"")
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'pickname',"")
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'bbDateTimePicker_date',"11/25/2018")
        
        #FILTER
        utils.parse.smartUpdateNVPairs(self.submitCourseSearchParameters,'filterNodeForm.selectedNode',"ALL_ENTITIES")
        
        
        self.info("CourseSearch.submitCourseSearch(): Operator: \"" + courseInfoSearchOperatorStringOptionsRandomlySelected + "\" Search Type: \"" +courseInfoSearchKeyStringOptionsRandomlySelected + "\"Search Text:\"" + searchText+"\"")
        
    
    def submitCourseSearch(self):
        self.POST(self.submitCourseSearchUrl,self.submitCourseSearchParameters)
        self.debug("CourseSearch.submitCourseSearch(): Results:"+ self.lastPage)

class UserSearch(scripts.base.Base):

    def __init__(self, request,bblearn):
        scripts.base.Base.__init__(self, request)
        self.bblearn=bblearn
    def openUserSearch(self):
        self.GET("/webapps/blackboard/execute/userManager")
    def openUserSearchLogic(self):
        #Try to extract the grade form
        courseSearchForm=utils.parse.extractOnce(self.lastPage,'<form  method="POST" name="userManagerSearchForm"', ".+?", '</form>',False )
       
        #If the gradeform is empty, there's nothing to do so we should return False
        if courseSearchForm =="":
            self.info("UserSearch.openUserSearchLogic(): no user search form found skipping")
            return  False
        
        #Extract the URL for the post
        self.submitUserSearchUrl = utils.parse.extractOnce(courseSearchForm,'action="', ".+?", '"', False)
        
        #Extracts all parameters and puts them into an NVpair
        self.submitUserSearchParameters =utils.parse.extractNVPairsFromForm(courseSearchForm)
        

        
        #Support for Enrollments
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'enrollSearchOperatorString','Equals')
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'enrollCount','0')
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'enrollIsCourse','true')
        
        #Support for Last Login
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'loginSearchOperatorString','LessThan')
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'loginDateFilter_datetime','2018-12-3 23:59:00')
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'loginDateFilter_date','12/03/2018')
       
        #Adds additional post data that is not part of the form and handled through javascript
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'actionString', "Search" )
        
        #Currently we only support UserInformation searches, at some point we should included enrollmetns, last login, etc..
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'searchTypeString', "UserInformation" )
        
        #User search type
        userInfoSearchKeyStringOptions = ['UserName','GivenName','FamilyName','Email','DataSourceKey','StudentId']
        userInfoSearchKeyStringOptionsRandomlySelected = utils.random.randomlySelectValueFromList(userInfoSearchKeyStringOptions)
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'userInfoSearchKeyString',userInfoSearchKeyStringOptionsRandomlySelected)
        
        #User String
        userInfoSearchOperatorStringOptions = ['Contains','Equals','StartsWith','NotBlank']
        userInfoSearchOperatorStringOptionsRandomlySelected = utils.random.randomlySelectValueFromList(userInfoSearchOperatorStringOptions)
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'userInfoSearchOperatorString',userInfoSearchOperatorStringOptionsRandomlySelected)
        
        #SEARCH TEXT
        searchText = utils.baconLoremIpsum.getSearchText()
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'userInfoSearchText',utils.baconLoremIpsum.getSearchText())
        
       
        #FILTER
        utils.parse.smartUpdateNVPairs(self.submitUserSearchParameters,'filterNodeForm.selectedNode',"ALL_ENTITIES")
        
        
        self.info("UserSearch.submitUserSearch(): Operator: \"" + userInfoSearchOperatorStringOptionsRandomlySelected + "\" Search Type: \"" +userInfoSearchKeyStringOptionsRandomlySelected + "\"Search Text:\"" + searchText+"\"")
        
    
    def submitUserSearch(self):
        self.POST(self.submitUserSearchUrl,self.submitUserSearchParameters)
        self.debug("UserSearch.submitUserSearch(): Results:"+ self.lastPage)