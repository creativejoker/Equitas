# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Support for blogs.

from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPPluginControl
from HTTPClient import Codecs
from HTTPClient import NVPair
from jarray import zeros
import scripts
import utils.parse
import utils.baconLoremIpsum
 

class Blog(scripts.base.Base):

    def __init__(self, request, bblearn):
        scripts.base.Base.__init__(self, request)
        # This points to the current course object
        self.bblearn = bblearn
        self.reset()
        
    def reset(self):
        self.currentBlogPk=-1
        self.courseTOCMenuUrl = ""
        #self.bblearn.coursePk = ""
        self.createBlogEntryUrl = ""
        self.viewBlogDraftEntryUrl = ""
        self.uploadFile = ""
        self.submitCreateBlogEntryUrl = ""
        self.submitCreateBlogEntryData =[]
        self.submitCreateBlogEntryHeaders = ""
        
    def blogCourseTOCExist(self):
        #Pulls the course table of content(TOC) link that is associated with this class
        self.courseTOCMenuUrl=scripts.course.courseTOCMenuItem(self.bblearn,"Blogs")
        
        #If the course toc exist, we open it and return true, otherwise we return false
        if self.courseTOCMenuUrl == "":
            return False
        else:
            return True
            
    def openBlogsCourseTOC(self):
        #Opens the following URL example
        #/webapps/blackboard/content/launchLink.jsp?course_id=_1910_1&tool_id=_1695_1&tool_type=TOOL&mode=view&mode=reset      
        self.GET(self.courseTOCMenuUrl)
        
    def openBlogsCourseTOCCheck(self):
        #If we're in legacy mode, we need to extract the values here
        if self.bblearn.courseTOCModeIsLegacy:
            self.info("Blog.openBlogsCourseTOCCheck() Legacy mode, extracting the blog urls again")
            self.bblearn.extractBlogUrls(self.lastPage)
            
    def openBlogLogic(self):
        #Opens the followign URL Example
        #/webapps/blogs-journals/execute/viewBlog?course_id=_1910_1&blog_id=_5111_1&type=blogs&index_id=month 
        
        if len(self.bblearn.blogUrls)==0:
            self.info("Blog.openBlog(): No blogs found in this course:"+self.bblearn.coursePk+", skipping")
            return False
            
        self.blogUrl = utils.random.randomlySelectValueFromList(self.bblearn.blogUrls)
        self.info("Blog.openBlogLogic(): Opening blog")
        self.currentBlogPk = utils.parse.extractOnce(self.blogUrl, "blog_id=_", "[0-9]+", "_1",False)

    def openBlog(self):
        self.GET(self.blogUrl)
        

    def openCreateBlogEntryLogic(self, url=""):


        self.info("Blog.openCreateBlogEntry(): opening Create Blog Entry")
        
        #Use this if we're passing in a URL
        if url!="":
            if url.find("amp;")>0:
                url = url.replace("amp;","")
            self.createBlogEntryUrl = url
        else:
            #Check to see if blogs exist, if not, no point in creating them. 
            if self.currentBlogPk==-1:
                self.info("Blog.openCreateBlogEntry(): no blogs available, skipping use case")
                return False
                
            self.createBlogEntryUrl ='/webapps/blogs-journals/execute/editBlogEntry?course_id=_'+self.bblearn.coursePk+'_1&editBlogEntryAction=createBlogEntry&type=blogs&blog_id=_'+self.currentBlogPk+'_1&group_id='
        
    def openCreateBlogEntry(self):
        self.GET(self.createBlogEntryUrl)

    def extractCurrentBlogPk(self):
        #Recheck and grab the blog pk
        self.currentBlogPk=utils.parse.extractOnce(self.createBlogEntryUrl, "blog_id=_", "[0-9]+", "_1")  
        
    def submitCreateBlogEntryLogic(self, submitAction="post"):
        '''2 steps involved here.
        1. Open an empty blog form.
        2. Populate the blog info and submit.'''
        if self.currentBlogPk==-1:
            self.info("Blogs.submitCreateBlogEntryLogic(): no blogs available, skipping use case")
            return 
        
        self.info("Blogs.submitCreateBlogEntryLogic(): " + submitAction)
        #Pulls out submission form and URL to post to 
        form=utils.parse.extractOnce(self.lastPage,'name="editBlogEntryForm"', ".+", '</form>' )
        self.submitCreateBlogEntryUrl = utils.parse.extractOnce(form,'action="', ".+?", '"' )
        
        if len(form)==0 or len(self.submitCreateBlogEntryUrl)==0:
            self.info("Blogs.submitCreateBlogEntryLogic(): no form or url found on last page, nothing to submit, skipping...")
            return
        
        # Randomly selects a file to upload
        self.uploadFile = utils.uploadFiles.getRandomFile()
        if self.uploadFile==False:
            self.info("Blogs.submitCreateBlogEntryLogic(): Random file is not available, skipping file upload" )
            return
            
        self.info("Blogs.submitCreateBlogEntryLogic(): Selected file is: " +self.uploadFile)
        
        files = ( NVPair("newFile_LocalFile0", self.uploadFile), )
      
        
        #Extracts all parameters and puts them into an NVpair
        parameters =utils.parse.extractNVPairsFromForm(form)
        #Adds additional post data that is not part of the form and handled through javascript
        parameters.append(NVPair('newFile_attachmentType', 'L'))
        parameters.append(NVPair('newFile_fileId', 'new'))
        parameters.append(NVPair('newFile_linkTitle', self.uploadFile))
        
        #Update/Add Fields that aren't on the original form
        utils.parse.smartUpdateNVPairs(parameters,'submitAction', submitAction )
        utils.parse.smartUpdateNVPairs(parameters,'anonymous', 'false' )
        
        #Using new bacon lorem ipsum
        utils.parse.smartUpdateNVPairs(parameters,'title', utils.baconLoremIpsum.getBaconTitle() )
        utils.parse.smartUpdateNVPairs(parameters,'blogEntry_desc_text', utils.baconLoremIpsum.getBaconParagraph())

        
        # This is the Jython way of creating an NVPair[] Java array
        # with one element.
        self.submitCreateBlogEntryHeaders = zeros(1, NVPair)

        # Create a multi-part form encoded byte array.
        self.submitCreateBlogEntryData = Codecs.mpFormDataEncode(parameters, files, self.submitCreateBlogEntryHeaders)
        
        self.info("Blogs.submitCreateBlogEntryLogic(): " + submitAction)
    
    def submitCreateBlogEntry(self):
        #Performs the POST
        self.POST(self.submitCreateBlogEntryUrl, self.submitCreateBlogEntryData, self.submitCreateBlogEntryHeaders)
        
    def removeTempFile(self):
        #Remove Random Temp file
        utils.uploadFiles.removeFile(self.uploadFile)


    def viewBlogDraftEntryLogic(self):
        # Currently, all draft entries are only created in Individual Blogs.

        params=utils.parse.extractOnce(self.lastPage,'href="/webapps/blogs-journals/execute/blogEntryDraftList','[^"]+','"')
        params=params.replace("amp;","")
        if len(params)==0:
            self.info("Blog.viewBlogDraftEntry(): Unable to open page to view Blog Draft Entry!")
            return False
        else:
            self.viewBlogDraftEntryUrl="/webapps/blogs-journals/execute/blogEntryDraftList"+params
            self.info("Blogs.viewBlogDraftEntry(): " + self.viewBlogDraftEntryUrl)
            return True
            
    def viewBlogDraftEntry(self):
            self.GET(self.viewBlogDraftEntryUrl)

