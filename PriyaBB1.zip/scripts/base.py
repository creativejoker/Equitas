# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPRequest
import utils.logging
import config.settings

class Base:
    def __init__(self, request):
        self.request = request
        # Stores the content of the previously loaded page
        self.lastPage =''
        
        #Adding Logging alias to be used in scripts class
        self.info = utils.logging.info
        self.debug = utils.logging.checkDebugAndLog
        self.warn = utils.logging.warn
        self.error = utils.logging.error
        self.infoAndError=utils.logging.infoAndError

    def sleep(self, type):
        grinder.sleep(config.settings.thinkTime[type])        
    def GET(self, target, headers=None):
    
        #Checking to see if the url is valid(whitelisted and not blacklisted)     
        if self.request.isTargetValid(target) is not True:
            self.lastPage=''
            return
            
        result=self.request.GET(target,headers)
        if result.getStatusCode() < 300:
            self.lastPage=result.getText()
                
        elif result.getStatusCode()==302:
            self.lastPage=self.FollowRedirects(target,result)
        else:
            self.lastPage=''
        
        return result
    
    def PUT(self, target, data, headers=None):
        #Checking to see if the url is valid(whitelisted and not blacklisted)     
        if self.request.isTargetValid(target) is not True:
            self.lastPage=''
            return
            
            
        if headers==None:
            result=self.request.PUT(target, data)
        else:
            result=self.request.PUT(target, data, headers)

        if result.getStatusCode() < 300:
            self.lastPage=result.getText()
        
        elif result.getStatusCode()==302 or result.getStatusCode()==303:
            self.lastPage=self.FollowRedirects(target,result)
        else:
            self.lastPage=''
        return result
        
    def POST(self, target, data, headers=None):
        #Checking to see if the url is valid(whitelisted and not blacklisted)     
        if self.request.isTargetValid(target) is not True:
            return
            
            
        if headers==None:
            result=self.request.POST(target, data)
        else:
            result=self.request.POST(target, data, headers)

        if result.getStatusCode() < 300:
            self.lastPage=result.getText()
        
        elif result.getStatusCode()==302 or result.getStatusCode()==303:
            self.lastPage=self.FollowRedirects(target,result)
        else:
            self.lastPage=''
        return result
    
    def FollowRedirects(self,target,result):
        accumulatedLastPage = result.getText()
        host = ""
        while result.getStatusCode()==302 or result.getStatusCode()==303:

            #First we check if the Location header has an FQDN
            url = result.getHeader('Location')
            splitURL = url.split("/")
            if splitURL is not None:
                if splitURL[0].count("http:")>0 or splitURL[0].count("https:")>0:
                    host = splitURL[0]+"//" + splitURL[2]
                    self.info("HOST: " + host)
            
            #Otherwise we pull it from the previous target :
            if host == "":
                splitURL = target.split("/")
                if splitURL is not None:
                    if splitURL[0].count("http:")>0 or splitURL[0].count("https:")>0:
                        host = splitURL[0]+"//" + splitURL[2]
                        self.info("HOST: " + host)
            self.info("URL: "+url)
            #if we can't find the host in the URL, then we need to add it
            if url.count("https://")==0 and url.count("http://")==0 and host !="":
               url =  host + "/" + url
               self.info("URL Updated: "+url)
 
            result = self.request.GET(url)
            accumulatedLastPage = accumulatedLastPage + "\n" + result.getText()
        return accumulatedLastPage
    
    def distributionPercentage(self, type):
        return config.settings.distributionPercentages[type]