# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Support for wikis.


from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPPluginControl
from HTTPClient import Codecs
from HTTPClient import NVPair
from jarray import zeros
import scripts
import utils.parse
import utils.baconLoremIpsum

 
class Wiki(scripts.base.Base):

    def __init__(self, request, bblearn):
        scripts.base.Base.__init__(self, request)
        # This points to the current course object
        self.reset()
        self.bblearn = bblearn
        
    def reset(self):
        self.currentWikiPk= ""
        self.wikiPageUrls = ""
        self.courseTOCMenuUrl = ""
        self.createHomePage = False
        self.submitWikiPostData =[]
        self.editWikiPageUrl = ""
        self.submitWikiPageUrl = ""
        
    def wikiCourseTOCExist(self):
        self.courseTOCMenuUrl = scripts.course.courseTOCMenuItem(self.bblearn,"Wikis")
        
        #If the course toc exist, we open it and return true, otherwise we return false
        if self.courseTOCMenuUrl == "":
            return False
        else:
            return True
            
    def openWikisCourseTOC(self):
        #Pulls the course table of content(TOC) link that is associated with this class
        self.GET(self.courseTOCMenuUrl)
    
    def openWikisCourseTOCCheck(self):
        #If we're in legacy mode, we need to extract the values here
        if self.bblearn.courseTOCModeIsLegacy:
            self.info("Wiki.openWikisCourseTOCCheck() Legacy mode, extracting the wiki page urls again")
            self.bblearn.extractWikiPageUrls(self.lastPage)

    def openWikiLogic(self, pk=-1):
        ''' Open a particular wiki page from the list of wikis.
        If the wiki has no prior pages created, the system will 
        redirect the user to the "Create Wiki Page" link.'''
        
        #If there is an available wikiUrl stored in bblearn object, we randomly select one and open
        if len(self.bblearn.wikiPageUrls) ==0:
            self.info("Wiki.openWikiLogic(): No wiki list found in this course:"+self.bblearn.coursePk+", skipping")
            return False
            
        self.wikiUrl = utils.random.randomlySelectValueFromList(self.bblearn.wikiPageUrls)
        self.info("Wiki.openWikiLogic(): Opening wiki")
        
        #Grab the wiki and course pk for use later. 
        self.currentWikiPk= utils.parse.extractOnce(self.wikiUrl, "wiki_id=_","[0-9]+","_1")
        
    def openWiki(self):
        self.GET(self.wikiUrl)
    
    def openWikiCheck(self):

        
        #If this is the first loading of the message, we pull out the necessary information from the previous page
        self.wikiPageUrls = utils.parse.extractAll(self.lastPage, '<a href="', '[A-Z0-9a-z.\/:]+/Bb-wiki-'+self.bblearn.vi+'/wikiView\?[^"]+?', '">',30)
        
        self.info("Wiki.openWikiCheck(): found "+str(len(self.wikiPageUrls))+" sub wiki pages")
        
        #Check the response and check to see if we need to create the homepage
        if self.lastPage.find("No Pages exist for this Wiki")>0:
            self.info("Wiki.openWikiCheck(): No home page exist for this wiki, creating the home page...")
            self.createHomePage = True
    
    #Logic to opens a particular wiki page from the previous page's load
    def openWikiPageLogic(self):
        #if we still don't have anything than either the previous page didn't load correctly or there's no message, return
        if len(self.wikiPageUrls)==0:
            self.info("Wiki.openWikiPage(): no sub wiki pages found, skipping") 
            return False# Don't bother  
        else:
            self.wikiPageUrl = utils.random.randomlySelectValueFromList(self.wikiPageUrls)
            self.info("Wiki.openWikiPageLogic(): Opening wiki page")
            return True
        
        
    def openWikiPage(self):
        self.GET(self.wikiPageUrl)
        
    def openCreateWikiPage(self):
        self.GET('/webapps/Bb-wiki-'+self.bblearn.vi+'/pageProperties?action=create&course_id=_'+self.bblearn.coursePk+'_1&wiki_id=_'+self.currentWikiPk+'_1')



    def openEditWikiPageExist(self):
        # Assumption is there are existing wiki pages.
        # If not, redirect to createWikiPage method.
        
        params=utils.parse.extractOnce(self.lastPage, '/webapps/Bb-wiki-'+self.bblearn.vi+'/pageProperties\?action=modify&', '[^"]+', '"')
        
        if len(params)>0:
            self.info("Wikis.openEditWikiPage(): Opening Edit Wiki page.")
            self.editWikiPageUrl='/webapps/Bb-wiki-'+self.bblearn.vi+'/pageProperties?action=modify&'+params
            return True
        else:
            self.info("Wikis.openEditWikiPage(): no existing wiki pages.")
            return False
            
    def openEditWikiPage(self):
        self.GET(self.editWikiPageUrl)
        
    def submitWikiPageLogic(self, isModify):
        # Common method for createWikiPage and editWikiPage to populate/submit the wiki page info.
        # isModify parameter: true=editWikiPage; false=createWikiPage
        
        #Pulls out submission form
        form=utils.parse.extractOnce(self.lastPage,'<form.+name="mainForm"', ".+", '</form>' )

        #If the form is empty then we return, otherwise we move on
        if len(form)==0:
            self.info("Wiki.submitWikiPage(): no form found on last page, nothing to submit, skipping...")
            return False
        
        #the short version of the url is returned so we need to append it to the full url
        url = utils.parse.extractOnce(form,'action="', ".+?", '"' )
        self.submitWikiPageUrl = "/webapps/Bb-wiki-"+self.bblearn.vi+"/"+url
        
        #Extracts all parameters and puts them into an NVpair
        self.submitWikiPostData =utils.parse.extractNVPairsFromForm(form)
        #Adds additional post data that is not part of the form and handled through javascript
        self.submitWikiPostData.append(NVPair('top_Submit', 'Submit'))
        
        #Using new bacon lorem ipsum
        self.submitWikiPostData.append(NVPair('title', utils.baconLoremIpsum.getBaconTitle()))
        self.submitWikiPostData.append(NVPair('contenttext', utils.baconLoremIpsum.getBaconParagraph()))
        utils.parse.smartUpdateNVPairs(self.submitWikiPostData,'is_modify', isModify )
        return True
        
    def submitWikiPage(self):
        self.info("Wiki.submitWikiPage(): submitting wiki page") 
        self.POST(self.submitWikiPageUrl, self.submitWikiPostData)
    
        return self.lastPage
    
    #def commentWikiPage(self):
        # Too complicated with the javascript code...

