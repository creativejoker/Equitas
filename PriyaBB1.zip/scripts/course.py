# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.plugin.http import HTTPRequest
from net.grinder.plugin.http import HTTPPluginControl
from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from HTTPClient import Codecs
from jarray import zeros
import scripts
import utils.parse
import utils.random
import config.settings
from utils.parameters import ListParameter
from utils.parameters import RangeParameter

class Course(scripts.base.Base):

    def __init__(self, request,bblearn):
        scripts.base.Base.__init__(self, request)

        self.bblearn=bblearn

        self.bblearn.coursePk=-1   # Currently select course
        # Delegate portal activity to the portal object
        self.portal = scripts.portal.Portal(request,self.bblearn)
        #Initialize the variable to hold a list of folders the next level down
        self.foldersoneleveldown = []

        

    def openCoursesTab(self):
        self.portal.openTab(self.bblearn.courseTabPk)
        self.portal.loadPortalTabCheck()
        self.lastPage = self.portal.lastPage

    def loadCoursesTabModules(self):
        self.portal.loadTabModules()
        self.lastPage = self.portal.lastPage
        
#ULTRA
    def openUltraCourseStream(self):
        self.GET("/ultra/course")
        


    def openCourse(self,coursePk=""):
        '''Open a course.
        Parameter: pk; course ID without the leading _ and trailing _1
        if not provided, randomly select one'''
        
        #Reset the course information for the bblearn object each time we open a course
        self.bblearn.resetCourse()
        
        #check to see if there are course id's to open, if not return false and don't move forward
        if len(self.bblearn.coursePks)==0:
            self.info("Course.OpenCourse(): User is not enrolled in any courses, skipping opening a course....")
            return False

        #NEW RANDOMLY SELECTS COURSE PK FROM LIST OF COURSE PKS
        #Select a course ID for the user
        if coursePk != "":
            self.bblearn.coursePk = coursePk 
        else:
            self.bblearn.coursePk =utils.random.randomlySelectValueFromList(self.bblearn.coursePks)
        self.info("Course.OpenCourse(): Opening random Course Pk:  _" + self.bblearn.coursePk+"_1")

        
        # Open the courses tab delegating to the portal class
        # Note: this is going to be fairly long string of 302 (at least three)
        ########################################################
        #NEW VERSION SPECIFIC CODE
        
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(1)
        if self.bblearn.versionBelowSP14:
            self.portal.openTab(self.bblearn.courseTabPk, '%2Fwebapps%2Fblackboard%2Fexecute%2Flauncher%3Ftype%3DCourse%26id%3D_'+self.bblearn.coursePk+'_1%26url%3D')
            self.lastPage=self.portal.lastPage
        elif self.bblearn.versionAboveSP14:
            response = self.GET('/webapps/blackboard/execute/launcher?type=Course&id=_'+self.bblearn.coursePk+'_1&url=')
            #response = self.GET('/webapps/blackboard/execute/launcher?type=Course&id=_54534_1&url=')
            self.portal.lastPage = self.lastPage
        elif self.bblearn.isUltra == True:
            self.bblearn.ultraContentJsonResponse = self.GET('/learn/api/v1/courses/_'+self.bblearn.coursePk+'_1?expand=instructorsMembership,+instructorsMembership.courseRole,+effectiveAvailability').getText()
            self.bblearn.ultraContentJsonResponse += self.GET('/learn/api/v1/courses/_'+self.bblearn.coursePk+'_1/users/'+self.bblearn.userPk+'?expand=courseRole').getText()
            
            #Get the Content in the course
            self.bblearn.ultraContentJsonResponse += self.GET('/learn/api/v1/courses/_'+self.bblearn.coursePk+'_1/contents/ROOT/children?expand=assignedGroups&limit=25').getText()
        else:
            self.info("Course.OpenCourse(): Blackboard Version not recognized, returning")
            return

        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(0)



    def loadCourseModules(self):
    
        #delegate the loading of the course modules to the portal class
        self.portal.loadTabModules()
        self.lastPage = self.portal.lastPage
        #If we're in legacy mode, we need to extract the values here
        if self.bblearn.courseTOCModeIsLegacy:
            self.bblearn.extractLegacyCourseTOC(self.lastPage)
        else:
            #Search page for all content and tool pages, delegate to the bblearn class
            self.bblearn.extractBbLearnCourseTOC(self.lastPage)
   
    #Function that iterates through each course content table of content/tool link and determines what course content are available on that page
    #(i.e. folders/coursetool links/files or blogs/wikis/assignments/assessments)    
    def mapCourseTOC(self,type,index):

        
        #Determine what type of course table of contents it is
        ##Should be either "content" or "tool"
        if type =="content":
            courseToc = self.bblearn.courseContentTOCUrls
        elif type =="tool":
            courseToc = self.bblearn.courseToolsTOCUrls
        else:
            self.info("Course.mapCourseTOC(): Course table of contents type does not exist")
            return
        #    
        #For now we iterate over ALL course content table of content items in order.
        #TODO - In the future we might randomize this, but then we'd have to keep track of what we already checked.
        #for x in range(len(courseToc)):
        self.info("Course.mapCourseTOC(): Opening and Searching in "+str(index+1)+" of "+ str(len(courseToc))+" course "+str.upper(type)+" TOC menu link.")
                #Setting the verify Server distiguished name to false
        
        #javax.net.ssl.SSLException: Name in certificate `*.mindtouch.us' does not match host name `help.blackboard.com'
        #at HTTPClient.HTTPConnection.checkCert(HTTPConnection.java:3574) ~[grinder-httpclient-3.10.jar:na]

        HTTPPluginControl.getConnectionDefaults().setVerifyServerDistinguishedName(False)
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(0)
        #Open the course content table of content URL
        self.GET(courseToc[index])
        
        #This is where we extract out the assessments/assignments/blogs/wiki/dbs
        #Delegate it to the bblearn class
        self.bblearn.extractBbLearnCourseToolsFromTOC(self.lastPage,courseToc[index])
        
        #This is where we extract the files/folders/other course tool inks
        self.currentLevelFolders = self.bblearn.extractBbLearnCourseContentFromTOC(self.lastPage)
        


            
    #Breaking this out to it's own function so we can call it from action
    #Takes the subfolders found in the mapCourseTOC() and opens them.
    def mapSubFolder(self,index):
        #If folders exist, then we try to open those folders and drill down further for more folders and other course tools
       

        #Iterate through the available folders at the current level

        self.info("Course.mapSubFolder(): Opening the  "+ str(index+1)+" of "+ str(len(self.currentLevelFolders))+" sub folders...")
        
        #Open each folder
        self.GET(self.currentLevelFolders[index])
        
        #Check for course tools and content on this page
        self.bblearn.extractBbLearnCourseToolsFromTOC(self.lastPage,self.currentLevelFolders[index])
        
        #If we find a subfolder, add it to the list of folders one level down
        self.foldersoneleveldown += self.bblearn.extractBbLearnCourseContentFromTOC(self.lastPage)
        
    def setSubFolder(self):
        #Once we've completed the current level of folders, If there's folders one level down, 
        #we set that to be the current folder level so that it will iterate through those folders
        if len(self.foldersoneleveldown)>0:
            self.currentLevelFolders = self.foldersoneleveldown 
            self.info("Course.mapSubFolder(): Checking the next level down of folders")
        
        #If no more folders we set the current folder to be empty so the loop breaks
        else:
            self.currentLevelFolders =[]
            self.info("Course.mapSubFolder(): No more sub folders found, returning to parent folder...")
        
    def openCourseContentTOCItem(self):
    
        #If a content toc is available, randomly select and open one
        if len(self.bblearn.courseContentTOCUrls) ==0:
            self.info("Course.openCourseContentTOCItem(): No course content table of contents found in this course:"+self.bblearn.coursePk+", skipping")
            return False
            
        self.GET(utils.random.randomlySelectValueFromList(self.bblearn.courseContentTOCUrls))

    def openSubfolder(self):
        '''Randomly open a subfolder'''
        # Obtain a list of sub-folders based on the following parse
        #This is where we extract the files/folders

        self.info("Course.openSubfolder(): Attempting to open a random sub-folder")
        self.GET(utils.random.randomlySelectValueFromList(self.currentLevelFolders))


    def openDocument(self):
        '''Randomly open a document'''
        #Pulls out a content item that we have stored from the course mapping

        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(1)
        self.GET(utils.random.randomlySelectValueFromList(self.bblearn.fileUrls))
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(0)
            

    
    def courseTOCTargetExist(self,target):
        #Target names don't have a space in them, taking the space out
        target = target.replace(" ","")

        if self.bblearn.courseTOCLinks.has_key(target):
            
            if len(self.bblearn.courseTOCLinks[target])>0:
                return True
            else:
                self.info("Course.courseTOCTargetExist(): No url found for target \""+ target+"\"")
                return False
        else:
            self.info("Course.courseTOCTargetExist(): No course tool content table of content items found for target \""+ target+"\"")
            return False
    def courseTOCMenuItems(self,target):
        target = target.replace(" ","")
        courseTOCMenuItemUrl = scripts.course.courseTOCMenuItem(self.bblearn,target)
        if courseTOCMenuItemUrl != "":

            self.GET(courseTOCMenuItemUrl)   


# Call from other scripts to get a course tool TOC based on the type
# scripts.course.courseTOCMenuItem(self,self.bblearn,"assignment")
def courseTOCMenuItem(bblearn,target):
    '''course_button based navigation (primarily communication)
    Parameter: family'''
    targetUrl = ""
    
    #ULTRA SUPPORT
    if bblearn.isUltra:
        return 
        
    #If the target is in the dictionary, we set that to be the targetUrls
    if bblearn.courseTOCLinks.has_key(target):
        targetUrl=bblearn.courseTOCLinks[target]  
        
        #Check to see if there's actually a urls, if so we grab them from the list and return the URL
        if targetUrl !="":
        
            #targetUrl = utils.random.randomlySelectValueFromList(targetUrls)
            grinder.logger.info("Course.courseTOCMenuItem(): Opening target \""+ target+"\" from courseMenuItem ")
            return targetUrl
            
        else:
            grinder.logger.info("Course.courseTOCMenuItem(): No course tool content table of content items found for target \""+ target+"\"")
            return targetUrl
    else:
        grinder.logger.info("Course.courseTOCMenuItem(): Target \"" + target+"\" was not found, skipping...")
        return targetUrl


