# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Support for Announcements.
# NOTE: we currently only support multiple choice, all-at-once
# The test must be name as follows: 25Q-MC-AAO and stored under assignements.


from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from HTTPClient import Codecs
from jarray import zeros
import scripts
import utils.parse

 

class Announcement(scripts.base.Base):

    def __init__(self, request,  bblearn):
        scripts.base.Base.__init__(self, request)
        self.reset()
        self.bblearn = bblearn
        
        
    def reset(self):
        self.AnnouncementUrls=[]
        self.courseTOCMenuUrl=""
        self.AnnouncementAttemptUrl = ""
        self.AnnouncementAttemptUrls = []
        self.AnnouncementUrl =""
        self.submitAnnouncementUrl =""
        self.submitAnnouncementPostData =[]
        self.uploadFile = ""
        self.headers = ""
        self.hasAnnouncementAttempts = False
        self.newAttemptUrl = ""

    def AnnouncementsCourseTOCExist(self):
    
        #Pulls the course table of content(TOC) link that is associated with this class
        self.courseTOCMenuUrl=scripts.course.courseTOCMenuItem(self.bblearn,"Announcements")
        
        #If the course toc exist, we open it and return true, otherwise we return false
        if self.courseTOCMenuUrl=="":
            self.info("Announcement.openAnnouncementsCourseTOC(): No Announcements Table of Content Link found in course, skipping...")
            return False
        
        self.info("Announcement.openAnnouncementsCourseTOC(): Opening Announcement TOC link")
        return True
        
    def openAnnouncementsCourseTOC(self):
        self.GET('/webapps/blackboard/execute/announcement?method=search&context=course&course_id=_'+self.bblearn.coursePk+'_1&handle=cp_announcements&mode=cpview')
        self.secToken = utils.parse.extractOnce(self.lastPage,"<form name=\"announcementForm\" id=\"announcementForm\" method=\"post\" action=\"/webapps/blackboard/execute/announcement\"><input type='hidden' name='blackboard.platform.security.NonceUtil.nonce' value='", ".+?", "'>" )

    def openAnnouncementCreate(self):
        
        headers = zeros(1, NVPair)
        results = self.POST('/webapps/blackboard/execute/doCourseMenuAction?cmd=setDesignerParticipantViewMode&courseId=_'+self.bblearn.coursePk+'_1&mode=designer',headers)
        
        announcementCreateURL = '/webapps/blackboard/execute/announcement?blackboard.platform.security.NonceUtil.nonce='+self.secToken+'&method=add&viewChoice=2&editMode=true&tabAction=false&announcementId=&course_id=_'+self.bblearn.coursePk+'_1&context=course&internalHandle=cp_announcements&searchSelect=_'+self.bblearn.coursePk+'_1'
        self.GET(announcementCreateURL)
            
    def submitAnnouncementLogic(self):
        self.submitAnnouncementPostData = ""
        #Pulls out submission form and URL to post to 
        form=utils.parse.extractOnce(self.lastPage,'name="announcementForm"', ".+", '</form>' )
        if len(form)==0:
            self.info("Announcements.submitAnnouncementLogic(): No submit Announcement form found, skipping...")
            return False
            
        self.submitAnnouncementUrl = utils.parse.extractOnce(form,'action="', ".+?", '"' )
        
        files = zeros(1, NVPair)
        # This is the Jython way of creating an NVPair[] Java array
        # with one element.
        self.headers = zeros(1, NVPair)
        
        #Extracts all self.submitAnnouncementPostData and puts them into an NVpair
        self.submitAnnouncementPostData =utils.parse.extractNVPairsFromForm(form)
        
        #Adds additional post data that is not part of the form and handled through javascript
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'top_Submit', 'Submit')
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'subject', utils.baconLoremIpsum.getBaconTitle())
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'messagetext','<P>'+utils.baconLoremIpsum.getBaconParagraph()+'</P>')
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'permanent','true')
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'restrict_start_date','')
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'restrict_start_time','')
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'restrict_end_date','')
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'restrict_end_time','')
        utils.parse.smartUpdateNVPairs(self.submitAnnouncementPostData,'location','')

        
        return True
        
    def submitAnnouncement(self):
        self.info("Announcement.submitAnnouncement(): Submitting Announcement attempt.")
        #Performs the POST
        
        # This is the Jython way of creating an NVPair[] Java array
        # with one element.

        results = self.POST(self.submitAnnouncementUrl, self.submitAnnouncementPostData)

 


