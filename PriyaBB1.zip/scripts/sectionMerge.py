# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.plugin.http import HTTPRequest
from net.grinder.plugin.http import HTTPPluginControl
from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from HTTPClient import Codecs
from jarray import zeros
import scripts
import utils.parse
import utils.random
import config.settings
from utils.parameters import ListParameter
from utils.parameters import RangeParameter

class InstructorSectionMerge(scripts.base.Base):

    def __init__(self, request,bblearn):
        scripts.base.Base.__init__(self, request)

        self.bblearn=bblearn

    def isSectionMergeToolAvailable(self):
    
        #self.info(self.lastPage)
        # /webapps/bbgs-coursemergetool-bb_bb60/enter.do?tab_id=_1_1
        
        if self.bblearn.SectionMergeToolPortalEntryUrl  !="":
            return True
        else:
            self.info("InstructorSectionMerge.isSectionMergeToolAvailable(): Section Merge Tool is not available for this user")
            return False
            
    def openManagedMergedCourses(self):
        self.GET(self.bblearn.SectionMergeToolPortalEntryUrl)
        
    def openManagedMergedCoursesLogic(self):
    
        #<li class="mainButton"><a id="" href="/webapps/bbgs-coursemergetool-bb_bb60/selectCoursesToMerge.do?tab_id=_1_1"   >Setup New Merged Course</a></li>
        self.openMergedCourseMembershipsUrls = utils.parse.extractAll(self.lastPage,'<a href="','/webapps/bbgs-coursemergetool-'+self.bblearn.vi+'/manageMemberships.do[^"]+?','"',25,False)
        self.openMergedCourseModifyUrls = utils.parse.extractAll(self.lastPage,'<a href="','/webapps/bbgs-coursemergetool-'+self.bblearn.vi+'/manageSourceCourses.do[^"]+?','"',25,False)
        self.openSetupNewMergeCourseURL = utils.parse.extractOnce(self.lastPage,'href="','/webapps/bbgs-coursemergetool[^"]+?','"   >Setup New Merged Course</a></li>', False)
        if self.openSetupNewMergeCourseURL !="":
            return True
        else:
            self.info("InstructorSectionMerge.openSetupNewMergeCourseLogic(): open setup new merge course button not available")
            return False
    def openMergedCourseMemberships(self):

        self.GET(utils.random.randomlySelectValueFromList(self.openMergedCourseMembershipsUrls))
    def openMergedCourseModify(self):
        self.GET(utils.random.randomlySelectValueFromList(self.openMergedCourseModifyUrls))
    def disassociateMergedCourseLogic(self):
        self.disassociateMergedCourseUrls = utils.parse.extractAll(self.lastPage,'<a href="','/webapps/bbgs-coursemergetool-'+self.bblearn.vi+'/removeSourceCourse.do[^"]+?','"',25,False)
        if len(self.disassociateMergedCourseUrls)>0:
            self.info("InstructorSectionMerge.disassociateMergedCourseLogic(): There are " + str(len(self.disassociateMergedCourseUrls)) + " courses available to disassociate")
            return True
        else:
            return False
    def submitDisassociateMergedCourse(self):

        self.GET(utils.random.randomlySelectValueFromList(self.disassociateMergedCourseUrls))
    def openSetupNewMergeCourse(self):
    
        self.GET(self.openSetupNewMergeCourseURL)
        
    def selectCoursesToMergeLogic(self):
        #grab all courses to merge
        #<input type="checkbox" name="selectedCoursePkString" value="_1250975_1">
        self.availableCoursePks = utils.parse.extractAll(self.lastPage,'<input type="checkbox" name="selectedCoursePkString" value="_','[0-9]+?','_1">',25,False)
        self.info("InstructorSectionMerge.selectCoursesToMergeLogic(): There are " + str(len(self.availableCoursePks)) + " courses available to merge")
        
        self.selectedCoursePk=''
        self.selectedCoursePkList=[]
        
        #tab_id=_1_1&selectedCoursePkString=_1543955_1,_1503379_1&numResults=25&bottom_Submit=Submit

        self.submitSelectCoursesToMergeParameters = [
        NVPair('tab_id',"_1_1"),
        NVPair('numResults',"25"),
        NVPair('bottom_Submit',"Submit"),
        ]
    
        if len(self.availableCoursePks)>0:
        
            #If there is only 1 course, then it's the source course and should not be copied
            if len(self.availableCoursePks)==1:
                self.info("InstructorSectionMerge.selectCoursesToMergeLogic(): Only one course, the source Course ID cannot match the destination Course ID , skipping...")
                return False
                
            
            #Ensure that the chooser doesn't pick the source course from the list of available courses
            for i in range(utils.random.randomlySelectInt(5)):
            
                self.selectedCoursePk=utils.random.randomlySelectValueFromList(self.availableCoursePks)
                
                self.info("InstructorSectionMerge.selectCoursesToMergeLogic(): Selected course PK:"+self.selectedCoursePk)
                self.submitSelectCoursesToMergeParameters.append(NVPair('selectedCoursePkString',self.selectedCoursePk))
                count = 0
                self.selectedCoursePkList.append(self.selectedCoursePk)
                #if the selected course is already in the list, then we keep choosing till we find one
                #TODO, the logic on this isn't quite right but it works for now
                while(self.selectedCoursePk in self.selectedCoursePkList):
                    
                    self.selectedCoursePk=utils.random.randomlySelectValueFromList(self.availableCoursePks)
                    self.info("InstructorSectionMerge.selectCoursesToMergeLogic(): Selected course PK:"+self.selectedCoursePk)
                    
                    count +=1
                    #We have a break here in case the length of the available list of course is less than the number of iterations 
                    if count == len(self.availableCoursePks):
                        break
                #Add selected value to the list
                self.submitSelectCoursesToMergeParameters.append(NVPair('selectedCoursePkString',self.selectedCoursePk))
                self.selectedCoursePkList.append(self.selectedCoursePk)
            self.info("InstructorSectionMerge.selectCoursesToMergeLogic(): Selected course pk list: "+' '.join(self.selectedCoursePkList) )
            return True
        else:
            self.info("InstructorSectionMerge.selectCoursesToMergeLogic(): no courses available to merge")
            return False
            
    def submitSelectCoursesToMerge(self):

        self.POST('/webapps/bbgs-coursemergetool-'+self.bblearn.vi+'/defineMergedCourse.do',self.submitSelectCoursesToMergeParameters)
   
    def selectMergeCourseCreationLogic(self):
        #self.info(self.lastPage)
        #Page Option 1:Merge into an existing course, select from available courses
        self.existingCoursePKs = utils.parse.extractAll(self.lastPage,'<input type="radio" name="coursePkString" value="_','[0-9]+?','_1">',25,False)
        if len(self.existingCoursePKs)>0:
            self.info("InstructorSectionMerge.selectMergeCourseCreationLogic(): There are " + str(len(self.existingCoursePKs)) + " existing courses available to merge")
        #Page Option 2:#Merge into new course
        #href="/webapps/bbgs-coursemergetool-bb_bb60/newMergedCourse.do?tab_id=_1_1&selectedCoursePkString=_1543955_1&selectedCoursePkString=_1503379_1&numResults=25&bottom_Submit=Submit" 
        #self.openMergeCourseIntoNewCourseURL = utils.parse.extractOnce(self.lastPage,'href="','/webapps/bbgs-coursemergetool-'+self.bblearn.vi+'/newMergedCourse.do[^"]+?','"')
        
        #Page Option 3:#merge into an existing course
        #href="/webapps/bbgs-coursemergetool-bb_bb60/useExistingCourse.do?tab_id=_1_1&selectedCoursePkString=_1543955_1&selectedCoursePkString=_1503379_1&numResults=25&bottom_Submit=Submit"
        #self.openMergeCourseIntoExistingCourseURL = utils.parse.extractOnce(self.lastPage,'href="','/webapps/bbgs-coursemergetool-'+self.bblearn.vi+'/useExistingCourse.do[^"]+?','"')
    def submitSelectFromExistingCourse(self):
        #tab_id=_1_1&selectedCoursePkString=_1030606_1,_1102802_1&coursePkString=_1030606_1&numResults=25&bottom_Submit=Submit
        utils.parse.smartUpdateNVPairs(self.submitSelectCoursesToMergeParameters,'coursePkString', utils.random.randomlySelectValueFromList(self.existingCoursePKs) )
        self.POST('/webapps/bbgs-coursemergetool-'+self.bblearn.vi+'/setupMergedCourse.do',self.submitSelectCoursesToMergeParameters)
   

        
        
        
#def openCreateANewMergedCourse(self):
#    self.GET(self.openCreateANewMergedCourse)
#def openCreateANewMergedCourseLogic(self):
#    #tab_id=_1_1&selectedCoursePkString=_1543955_1,_1503379_1&courseId=dchow_test&courseName=test course&instructorUsername=bbsupport&courseAvailable=true&dataSourceBatchUid=SYSTEM&bottom_Submit=Submit
#    
#    #Should figure out how to make this unique
#    newCourseId = "dchow_test"
#    newCourseTitle = "test"
#    #Try to extract the grade form
#    createANewMergedCourseForm=utils.parse.extractOnce(self.lastPage,'<form name="CourseCreateForm"', ".+?", '</form>' )
#   
#    #If the gradeform is empty, there's nothing to do so we should return False
#    if createANewMergedCourseForm =="":
#        self.info("InstructorSectionMerge.openCreateANewMergedCourseLogic(): no form found")
#        return  False
#    
#    #Extract the URL for the post
#    self.submitCreateANewMergedCourseUrl = utils.parse.extractOnce(createANewMergedCourseForm,'action="', ".+?", '"' )
#    
#    #Extracts all parameters and puts them into an NVpair
#    self.createANewMergedCourseParameters =utils.parse.extractNVPairsFromForm(createANewMergedCourseForm)
#    
#
#    #Adds additional post data that is not part of the form and handled through javascript
#    utils.parse.smartUpdateNVPairs(self.createANewMergedCourseParameters,'courseId', newCourseId )
#    utils.parse.smartUpdateNVPairs(self.createANewMergedCourseParameters,'courseName', newCourseTitle )
#    utils.parse.smartUpdateNVPairs(self.createANewMergedCourseParameters,'courseAvailable', "true" )
#    utils.parse.smartUpdateNVPairs(self.createANewMergedCourseParameters,'bottom_Submit', "Submit" )
#
#    
#    return True
#def submitCreateANewMergedCourse(self):
#    self.POST(self.submitCreateANewMergedCourseUrl,self.createANewMergedCourseParameters)