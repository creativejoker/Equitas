# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.plugin.http import HTTPPluginControl
from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from HTTPClient import Codecs
from jarray import zeros
import scripts
import utils.parse
import utils.baconLoremIpsum



class Db(scripts.base.Base):

    def __init__(self, request, bblearn):
        scripts.base.Base.__init__(self, request)

        self.bblearn = bblearn
        self.reset()
        
    def reset(self):
        # List of forums in the current context
        self.dbForumsUrls = []
        # Currently selected discussion board
        self.forumPk = ''
        self.msgPks = ''
        self.confPk = ''
        self.createThreadUrl = ''
        self.currentMessagePk = ''
        self.coursePk = ''
        self.dbForumUrl = ''
        self.threadPk= ''
        self.courseTOCMenuUrl =''
        self.submitReplyUrl = ""
        self.submitReplyForm = ""
        self.submitReplyHeaders = ""
        self.isSubmitReply = False
        
        
    def dbCourseTOCExist(self):
        #Pulls the course table of content(TOC) link that is associated with this class
        self.courseTOCMenuUrl=scripts.course.courseTOCMenuItem(self.bblearn,"Discussions")
        
        #Or if this is ultra, then we just keep going as we know the DB TOC exist
        if self.bblearn.isUltra:
            return True
        
        #If the course toc exist, we open it and return true, otherwise we return false
        
        if self.courseTOCMenuUrl=="":
            return False
        else:
            return True
            
    def openDbCourseTOC(self):
        if self.bblearn.isUltra:
            self.GET("/ultra/courses/_"+self.bblearn.coursePk+"_1/engagement")
            self.GET("/learn/api/v1/courses/_"+self.bblearn.coursePk+"_1/contents/INTERACTIVE/children?expand=assignedGroups&limit=25")
        else:
            self.GET(self.courseTOCMenuUrl)
    
    def openDbCourseTOCCheck(self):
        #If we're in legacy mode, we need to extract the values here
        if self.bblearn.courseTOCModeIsLegacy or self.bblearn.isUltra:
            self.bblearn.extractDBForumUrls(self.lastPage)
            
    def openDbForumLogic(self):

        #Reset the messages each time we open a DB forum since there will be new messages in this forum
        self.reset()
        
        self.info("Db.openDbForum(): Opening the discussion board forums")       
        self.dbForumUrl = utils.random.randomlySelectValueFromList(self.bblearn.dbForumUrls)
    
    def openDbForum(self):
        self.GET(self.dbForumUrl)


    def extractDBinfo(self,lastPage=""):
    
        self.initialLoad=False
        if self.bblearn.isUltra:
            #e,"allowMembersToCreateNewThreads":true},"id":"_1383_1"}},"
            self.dbForumPk=utils.parse.extractOnce(lastPage, 'allowMembersToCreateNewThreads":true},"id":"_', "[0-9]+", "_1")
            #"userId":"_93_1","hitCount":0,"id":"_816_1","lifecycle":"PUBLISHED",
            self.dbParentPk=utils.parse.extractOnce(lastPage, '"id":"_', "[0-9]+", '_1","lifecycle":"PUBLISHED",')
          
        else:
            #For performance reasons, grab the following information from the discussionboard forum url instead of from the last page
            self.confPk=utils.parse.extractOnce(self.dbForumUrl, "conf_id=_", "[0-9]+", "_1")
            self.forumPk=utils.parse.extractOnce(self.dbForumUrl, "forum_id=_", "[0-9]+", "_1")
            self.coursePk = utils.parse.extractOnce(self.dbForumUrl, "course_id=_", "[0-9]+", "_1")

        #If this is the first loading of the message, we pull out the necessary information from the previous page
        if len(self.msgPks)==0:
            # Extract the list of messages from the previously loaded page.
            self.extractMsgPk()

            self.createThreadUrl = utils.parse.extractOnce(self.lastPage,'href="','message\?action=create&do=create[^"]+?','"')
            #Set the initial load to true so we don't have to pull this information again
            self.initialLoad=True
            # Log number of messages found
            self.info("Db.openMessage(): found "+str(len(self.msgPks))+" messages, continuing")
            


    def openMessageLogic(self):
        #Open a message in the current discussion board.

        #if we still don't have anything than either the previous page didn't load correctly or there's no message, return
        if len(self.msgPks)==0:
            self.info("Db.openMessage(): no messages, skipping") 
            return # Don't bother

        self.currentMessagePk=utils.random.randomlySelectValueFromList(self.msgPks)
    
    def openMessageTree(self):
        #if this is the first time in the discussion board message, load the tree
        if self.initialLoad==True:
            self.GET('/webapps/discussionboard/do/message?action=list_messages&course_id=_'+self.coursePk+'_1&conf_id=_'+self.confPk+'_1&forum_id=_'+self.forumPk+'_1&nav=discussion_board_entry&message_id=_'+self.currentMessagePk +'_1')
            self.threadPk=utils.parse.extractOnce(self.lastPage, "thread_id=_", "[0-9]+", "_1")
            
            # Get Message tree
            self.GET('/webapps/discussionboard/do/message?action=message_tree&course_id=_'+self.coursePk+'_1&conf_id=_'+self.confPk+'_1&forum_id=_'+self.forumPk+'_1&message_id=_'+self.currentMessagePk+'_1&nav=discussion_board_entry&thread_id=_'+self.threadPk+'_1&req_timestamp=1205100721864_0.7024496387236051')
            #reset this to false so that this only loads once
            self.initialLoad=False
    
    def openMessage(self):
        #Then get the message
        self.GET('/webapps/discussionboard/do/message?action=message_frame&course_id=_'+self.coursePk+'_1&conf_id=_'+self.confPk+'_1&forum_id=_'+self.forumPk+'_1&nav=db_thread_list_entry&nav=discussion_board_entry&message_id=_'+self.currentMessagePk+'_1&thread_id=null')
    
    #Logic to create a new thread
    def openCreateThread(self):
        self.info("Db.openCreateThread(): opening new create thread...") 
        self.GET("/webapps/discussionboard/do/"+self.createThreadUrl)

        

    def extractMsgPk(self):    
        #recheck the page for available message pks
        self.msgPks=utils.parse.extractAll(self.lastPage,"&message_id=_", "[0-9]+", "_1\">")
        
    def openReply(self):
        '''Open the Reply page for the currently open message'''
        self.info("Db.openReply(): opening new reply...") 
        #Otherwise open the reply
        self.GET('/webapps/discussionboard/do/message?action=reply&do=reply&type=message&course_id=_'+self.coursePk+'_1&conf_id=_'+self.confPk+'_1&thread_id=_'+self.threadPk+'_1&nav=discussion_board_entry&forum_id=_'+self.forumPk+'_1&message_id=_'+self.currentMessagePk+'_1')

        
   
    def submitReplyLogic(self,type):
        '''Post a reply to the currently open message'''

        
        self.info("Db.submitCreate(): creating new "+type+"...") 
        
        #Grab the message form
        #in Q4 2016 the form is <form  enctype="multipart/form-data" method="post" action="/webapps/discussionboard/do/message?action=save&pageLink=list_messages&nav=discussion_board_entry&course_id=_1149613_1&nav=discussion_board_entry&collection=false" id="inlineMessageForm" onsubmit="return validateMessageForm($('inlineMessageForm'))">
        messageForm=utils.parse.extractOnce(self.lastPage,'<form', '.+id="inlineMessageForm".+', '</form>')
        if len(messageForm)==0:
            self.info("Db.submitCreate(): no form found on last page, nothing to submit, skipping...")
            self.isSubmitReply = False
            return
        #extract the post url from the form
        self.submitReplyUrl =utils.parse.extractOnce(messageForm,'action="' ,".+?", '" ')
        
        #extract the textbox description for use later
        textboxPrefix=utils.parse.extractOnce(messageForm,"id='textbox_prefix' value=\"",'[^"]+','"/>')
        
        #extract the data from the form
        data =utils.parse.extractNVPairsFromForm(messageForm)
        
        #if this is a reply, then we append this data
        if type=="reply":

            data.append(NVPair('msgAttachment_attachmentType', ''))
            data.append(NVPair('msgAttachment_linkTitle', ''))
            data.append(NVPair('requestType', 'message'))
            data.append(NVPair('isAjax', 'true'))

        #For both we append this data
        #Using new bacon lorem ipsum
        utils.parse.smartUpdateNVPairs(data,'title', utils.baconLoremIpsum.getBaconTitle())
        utils.parse.smartUpdateNVPairs(data,textboxPrefix,'<P>'+utils.baconLoremIpsum.getBaconParagraph()+'</P>')
        
        # This is the Jython way of creating an NVPair[] Java array
        # with one element.
        files = zeros(1, NVPair)
        self.submitReplyHeaders = zeros(1, NVPair)
        
        # Create a multi-part form encoded byte array.
        self.submitReplyForm = Codecs.mpFormDataEncode(data, files,self.submitReplyHeaders)
        self.isSubmitReply = True
        
    def submitReply(self):
        response =self.POST(self.submitReplyUrl, self.submitReplyForm, self.submitReplyHeaders)
        
        #Then we grab the receipt
        receipt = utils.parse.extractOnce(response.getText(),'"message":"','[^"]+?','","')
        self.info("Db.submitCreate(): Reply Receipt:"+receipt+"...") 
        
        if type=="reply":
            #Check to see if we get the correct response back
            #,"message":"Success: Thread Re: This is a new grinder discussion board thread created.","nestedLocationId":"","receiptDivId":"","success":true,"type":"SUCCESS"}],"threadId":"_384_1"}
            utils.error.checkForPatternAndFailTest(self.lastPage,"SUCCESS","Db.submitCreate(): Reply Submit Attempt Not Successful",True)
            

            
            
#######ULTRA SUPPORT @@#############################
#
#    def openUltraDiscussionTOC(self):
#    
#        self.GET("/ultra/courses/_"+self.bblearn.coursePk+"_1/engagement")
#        self.GET("/learn/api/v1/courses/_"+self.bblearn.coursePk+"_1/contents/INTERACTIVE/children?expand=assignedGroups&limit=25")
#        
#        #extract out the Ultra Discussions
#        self.bblearn.extractDBForumUrls(self.lastPage)
#        
#    def openUltraDiscussionForum(self):
#            #resource/x-bb-forumlink","position":0,"permissions":{"copy":false,"contentHandlerPermissionMap":{"createDiscussion":true},"viewAdaptiveRelease":false,"createAdaptiveRelease":false,"modifyAdaptiveRelease":false,"deleteAdaptiveRelease":false,"dashboardView":false,"createLearningStandardsAlignment":false,"delete":true,"edit":false},"id":"_11216_1"}
#        forumPks = utils.parse.extractAll(self.lastPage, 'resource/x-bb-forumlink[^|]+"id":"_', '[0-9]+?', '_1',10,False)
#        #Loop through and build the assignment urls
#        self.dbForumPk = utils.random.randomlySelectValueFromList(forumPks)
#        self.GET("/ultra/courses/_"+self.bblearn.coursePk+"_1/engagement/discussion/view/_"+self.dbForumPk+"_1/_"+self.bblearn.coursePk+"_1")
#        self.GET("/learn/api/v1/courses/_"+self.bblearn.coursePk+"_1/contents/_"+self.dbForumPk+"_1")
#        self.extractDBinfo()
#    def openUltraMessage(self):
#        self.GET("/learn/api/v1/courses/_"+self.bblearn.coursePk+"_1/discussionboards/default/forums/_"+self.dbForumPk+"_1/messages")
#        self.extractDBinfo()
#    def openUltraMessageReplies(self):
#        self.GET("/learn/api/v1/courses/_"+self.bblearn.coursePk+"_1/discussionboards/default/forums/_"+self.dbForumPk+"_1/messages/_"+self.dbParentPk+"_1/replies?limit=5&offset=0&sort=postDate(desc)")
#        self.extractDBinfo()
#    def submitUltraReply(self):
#        url = "/learn/api/v1/courses/_"+self.bblearn.coursePk+"_1/discussionboards/default/forums/_"+self.dbForumPk+"_1/messages/_"+self.dbParentPk+"_1/replies"
#        
#        json = '''{
#        \"parentId\":\"_'''+self.dbParentPk+'''_1",
#        \"forumId\":\"_'''+self.dbForumPk+'''_1\",
#        \"userId\":\"_'''+self.bblearn.userPk+'''_1",
#        \"postedName\":\"First000000005 Last000000005",
#        \"subject\":null,
#        \"body\":{
#            \"rawText\":\"<p>'''+utils.baconLoremIpsum.getBaconParagraph()+'''</p>\",
#            \"displayText\":\"\"
#            },
#        \"isDeleted\":false,
#        \"postDate\":\"2016-03-17T21:41:00.080Z\",
#        \"editDate\":\"2016-03-17T21:41:00.080Z\"
#        }'''
#        response =self.POST(url, json)
        
