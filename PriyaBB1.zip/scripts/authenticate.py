# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from HTTPClient import Codecs
from net.grinder.plugin.http import HTTPPluginControl
import md5
import sys
import config.settings
import scripts
import time
import utils

class Authenticate(scripts.base.Base):

    def __init__(self, request, bblearn,usernameParam=config.settings.username):
        scripts.base.Base.__init__(self, request)
        self.usernameParam=usernameParam
        self.reset()
        self.portal=scripts.portal.Portal(request,bblearn)
        self.bblearn=bblearn
        self.serverHostname = ""
        
    # Unless you call this, will use the same user indefinitely
    def reset(self):
        self.username = self.usernameParam.getValue()
        self.password = config.settings.password.getValue()
        self.unicodedPassword = config.settings.password_unicode.getValue()
        self.redirectUrl =""
        self.loginSubmitData =""
        self.loginResponse =""
        self.form=[]
        self.parameters =[]
        self.url=""
        
    # Landing page
    def loginPage(self, loginPageUrl=""):
        #Reset on each login the bblearn object
        self.bblearn.reset()
        
        #if the url is not specified, then we go to the index page and let it redirect from there
        if loginPageUrl =="":
            loginPageUrl="/"
        
        #Initial GET To the application
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(1)
        results = self.GET(loginPageUrl)
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(0)   
        
    def redirectPageLogic(self):
        # If Tab page (Direct Access) entry is on, the response will contain a java script redirect for webapps/portal/frameset or defaultTab    
        #document.location.replace('https://performancetest1.blackboard.com/webapps/portal/frameset.jsp');
        
        
        self.redirectUrl=utils.parse.extractOnce(self.lastPage, "document.location.replace\('[^']+", '/webapps/[^"]+', "'\)",False)
        
        #if we don't find the redirect link, it looks like in 3400+ this might have been changed 
        # <html><head><meta http-equiv="refresh" content="0; url=/webapps/login/" /></head></html>
        if self.redirectUrl == "":
            self.redirectUrl=utils.parse.extractOnce(self.lastPage, '<meta http-equiv="refresh" content="0; url=', '/webapps/[^"]+', '"',False)
            #So what's happening in SENA's case is that they user is being redirected to /webapps/login and then gets redirectted back to //webapps/portal/execute/defaultTab once they have a guest sessions. Since there's no login page on the portal page, they then need to click the login link again.
            
            
        #We set the version here manually due to the fact self.portal.openTab() requires the bblearn version in order to know
        #which frameset to use. In SP14 and below, it's /webapps/portal/frameset.jsp and in April 2014 and above it's /webapps/portal/defaultTab.
        #The version can then be updated once the portal page has been properly loaded. 
        
        if self.redirectUrl.find("frameset.jsp")>0:
            self.bblearn.versionBelowSP14 = True
            #Default to defaultTab
        else:
            self.bblearn.versionAboveSP14 = True

    def openPortalTab(self):
            
        self.info("Authenticate.openPortalPage(): Direct access is on: opening portal, opening the redirect url " + self.redirectUrl)
        self.portal.openTab()
        self.portal.loadPortalTabCheck()
        self.portal.extractPortalObjects()
        
    def openPortalTabModules(self):
        self.portal.loadTabModules()
        self.lastPage = self.portal.lastPage
        


        

    def loginSubmitLogic(self):


        login = utils.parse.extractOnce(self.lastPage,'<input id="entry-login" type="submit" value="', ".+?", '"', False )
        self.loginSubmitUrl ="/webapps/login/"
        # Create Submit login form
        self.loginSubmitData = [
                NVPair('user_id', self.username),
                NVPair('login', login),
                NVPair('action', 'login'),
                NVPair('new_loc', '')
                ]
        ###################################################
        #SNHU CUSTOMIZATION TO SAVE THE USERNAME FOR LATER
        #####################################################
        self.bblearn.userId = self.username
        
        
        #If this is 3400 and above there is now a sec token as part of the exchange that needs to be extracted and passed along
        #<3400. user_id=bbsupport&password=&login=Login&action=login&remote-user=&new_loc=&auth_type=&one_time_token=&encoded_pw=MnVqYWtza2RqZjNpMml3&encoded_pw_unicode=MgB1AGoAYQBrAHMAawBkAGoAZgAzAGkAMgBpAHcAAAA=
        #>3400 user_id=user000016739&password=password&login=Iniciar sesión&action=login&new_loc=&blackboard.platform.security.NonceUtil.nonce=ef9ed2cd-3a01-4eb5-8d67-be10702907db

        #Check for the Security Nonce Token
        secToken = utils.parse.extractOnce(self.lastPage,"name='blackboard.platform.security.NonceUtil.nonce' value='", ".+?", "'", True )
        
        if secToken !="":
            self.loginSubmitData.append(NVPair('blackboard.platform.security.NonceUtil.nonce', secToken))
        
        
        #If this is LDAP, then we submit with the encoded Passwords
        if self.lastPage.count("encoded_pw")>0:
            self.loginSubmitData.append(NVPair('encoded_pw_unicode', self.unicodedPassword))
            self.loginSubmitData.append(NVPair('encoded_pw', self.password))
            self.loginSubmitData.append(NVPair('password', ""))
            self.info("Authenticate.loginSubmit(): LDAP: Logging in \""+self.username+"\" with encoded pw: \""+self.password+"\"")
        
        #else it's a regular submit
        else:
            self.loginSubmitData.append(NVPair('password', self.password))
            self.info("Authenticate.loginSubmit(): RDBMS: Logging in \""+self.username+"\" with \""+self.password+"\"")
    def loginSubmit(self):

        self.loginResponse  = self.POST(self.loginSubmitUrl, self.loginSubmitData )
        return utils.error.checkLoginError(self.loginResponse,self.loginSubmitUrl,self.loginSubmitData)


    def autosignon(self):
       self.sharedSecret=config.settings.autoSignonSecret
       self.autoSignonTimestamp=str(int(time.time()))
       m = md5.new()
       m.update(self.autoSignonTimestamp)
       m.update(self.username)
       m.update(self.sharedSecret)
       self.autoSignonMAC = m.hexdigest()
       self.info("Authenticate.autosignon(): Autosignon Login of"+self.username);
       self.GET('/webapps/bbgs-autosignon-'+config.settings.vi+'/autoSignon.do?timestamp=' + self.autoSignonTimestamp + '&userId=' + self.username + '&auth=' + self.autoSignonMAC)
       #self.info("Logging in "+self.username+" with secret of MAC of "+self.autoSignonMAC+" and Timestamp of "+self.autoSignonTimestamp+" via autosignon URL of /webapps/bbgs-autosignon-'+config.settings.vi+'/autoSignon.do?timestamp=" + self.autoSignonTimestamp + "&userId=" + self.username + "&auth=" + self.autoSignonMAC)
       #Verify contents of the previous page to ensure successful login
       #/webapps/login?action=logout" target="_top"
       loginSuccess=utils.parse.extractOnce(self.lastPage, "login\?", "action", "=logout")

       if len(loginSuccess)==0:
            self.info("Authenticate.autosignon(): Autosignon Authentication Failed for "+self.username)
            return False
       else:
            self.info("Authenticate.autosignon(): Autosignon Authentication Successful for "+self.username)
            return False
    def ShibLogin(self,queryString = ""):
        #Reset on each login the bblearn object
        self.bblearn.reset()
        self.info("Authenticate.ShibLogin(): Shib Login of "+self.username+" with "+self.password);  
        
        self.GET("/webapps/ubc-ctc-learn-ui-b2-BBLEARN/execute/shibbolethLogin"+queryString)
        
        
    
    def CASlogin(self):
        self.info("Authenticate.CASlogin(): CAS Login of "+self.username+" with "+self.password);    
        #Follow all redirects back to CAS server
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(1)
        self.GET('/')

        # Build up Get URL for CAS post
        getData = (
            #NVPair('service', 'https://mycourses.msstate.edu/webapps/bb-auth-provider-cas-'+config.settings.vi+'/execute/casLogin?'),
            NVPair('service', config.settings.CASservice),
            NVPair('cmd', 'login'),
            NVPair('authProviderId', config.settings.CASredirectURL),
            NVPair('redirectUrl', config.settings.CASredirectURL),
            #Works without a sessionId for now
            NVPair('sessionIdForLogout', '')
            )
        # Build GET String from NV pairs
        self.getURL=Codecs.nv2query(getData)

        # Determine lt and eventId Value for post
        self.ltValue=utils.parse.extractOnce(self.lastPage, 'lt" value="', '[^"]+', '"')
        self.execution=utils.parse.extractOnce(self.lastPage, 'execution" value="', '[^"]+', '"')
        #self.info("CAS lt = "+self.ltValue);
        #self.info("CAS execution = "+self.execution);

        # Build up post data for CAS Auth
        data = (
            NVPair('username', self.username),
            NVPair('password', self.password),
            NVPair('lt', self.ltValue),
            NVPair('execution', self.execution),
            NVPair('_eventId', 'submit'),
            NVPair('submit', 'LOGIN')
            )

        self.POST(config.settings.CASserverURL+self.getURL, data)
        # Turn off redirects
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(0)
        

    def logout(self):
        # Click the logout button
        self.GET('/webapps/login/?action=logout')
        self.username=''
        self.password=''
        # Return to login page
        self.loginPage()
    
    def checkServerHostname(self):
        self.GET('/webapps/portal/healthCheck')
        self.serverHostname = utils.parse.extractOnce(self.lastPage, 'Hostname:', '[^"]+', 'Status:')
        self.info('User: ' + self.username + ' is logged into server: '+self.serverHostname )
        
    def changePasswordSubmit(self,password):


        grinder.logger.info("Authenticate.changePasswordSubmit(): CHANGING "+self.username+" PASSWORD  "+password);
       
       #Saves the form from the first load, so we don't have to pull it out again
        if(len(self.form))==0:
            #Pulls out submission form
            self.form=utils.parse.extractOnce(self.lastPage,'<form name="passwordChangeFormBean"', ".+", '</form>' )
            self.url = utils.parse.extractOnce(self.form,'action="', ".+?", '"' )
            #Extracts all parameters and puts them into an NVpair
            self.parameters =utils.parse.extractNVPairsFromForm(self.form)

        #Each time we update the password
        utils.parse.smartUpdateNVPairs(self.parameters,'newPassword', password )
        utils.parse.smartUpdateNVPairs(self.parameters,'confirmNewPassword', password )
        self.POST(self.url, self.parameters)
        
        utils.error.checkForPatternAndFailTest(self.lastPage,'You have successfully changed your password. ',"Authenticate.changePasswordSubmit()::  BBGS Force Password not successful")
