# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPPluginControl
import scripts
import utils.parse
import utils.random
import utils.baconLoremIpsum
from HTTPClient import NVPair
from HTTPClient import Codecs
from jarray import zeros

class StudentGrade(scripts.base.Base):

    def __init__(self, request,bblearn):
        scripts.base.Base.__init__(self, request)

        self.bblearn=bblearn
        self.reset()
        
    def reset(self):
        self.gradeItemUrls = []
        self.reviewGradeItemUrls = ""
        self.isGradeItemAvailable = False
    def openCourseMyGrades(self):
        #reset the url each time we come here, this way each run is unique
        self.reset()
        #check to ensure that the user has a course available. If they don't, we just return.
        if len(self.bblearn.coursePk)==0:
            self.info("Grade.openCourseMyGrades(): User is not enrolled in any courses")
            return False
            
        '''Open the control panel (instructors only, will fail otherwise)'''
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(1)
        self.GET('/webapps/gradebook/do/student/viewGrades?course_id=_'+self.bblearn.coursePk+'_1&callback=course')
        HTTPPluginControl.getConnectionDefaults().setFollowRedirects(0)

            
    #Then we want to open up a grade item
    def reviewGradeItemLogic(self):
        #check to ensure that the user has a course available. If they don't, we just return.
        if len(self.bblearn.coursePk)==0:
            self.info("Grade.reviewGradeItem(): User is not enrolled in any courses")
            return False
            
        if len(self.gradeItemUrls)==0:
            self.gradeItemUrls = utils.parse.extractAll(self.lastPage,"onclick=\"mygrades.loadContentFrame\(\'","[^']+","'",20,False)
        
        if len(self.gradeItemUrls)>0:
            self.info("Grade.reviewGradeItem(): Opening a grade item")
            self.reviewGradeItemUrls=utils.random.randomlySelectValueFromList(self.gradeItemUrls)
            self.isGradeItemAvailable = True
        else:
            self.info("Grade.reviewGradeItem(): User does not have any viewable my grade items to review for this course, skipping...")
            self.isGradeItemAvailable = False
    
    def reviewGradeItem(self):
        self.GET(self.reviewGradeItemUrls)

        
        
################### Instructor actions ##########################
class InstructorGrade(scripts.base.Base):

    def __init__(self, request,bblearn):
        scripts.base.Base.__init__(self, request)

        self.bblearn=bblearn
        self.submitGradeParameters =[]
        self.submitGradeUrl =""
        self.coursePk = ""
        self.oid = ""
        self.mid = ""
        self.users = ""
        self.assignmentJson =""
        self.assignmentGbItems =""
        self.attemptId=""
    def chooseInstructorGradeCenter(self):
        #Check to make sure that we're enrolled in a course before proceeding
        if len(self.bblearn.coursePk)==0:
            self.info("Grade.openInstructorGradeCenter(): User is not an instructor in any classes, skipping grade book...")
            return False
        
        self.coursePk = self.bblearn.coursePk
        return True
    def openInstructorGradeCenter(self):
        '''Open the instructor grade center'''

        # 8.0 Grade Center:
        self.GET('/webapps/gradebook/do/instructor/enterGradeCenter?course_id=_'+self.coursePk+'_1')
        self.GET('/webapps/gradebook/do/instructor/getJSONData?course_id=_'+self.coursePk+'_1')
        # Note there should be two DWR calls and one more JSONData call here


    def chooseGradebookItem(self):
        '''Randomly open a grade on the current spreadsheet: todo, give more control'''
        
        #9.1 SP5, should use '"id":"', '[0-9]+', '","(name|symbols|points)"', however it always selects the same outcome definition.
        # Format "name":"GB Item 000000001","type":"N","id":"1163","points":50,
        # it's picking up the following, so added the {2,} to only take id's more than 2 characters
        #Assignment File Download","id":"1","actionUrl":"

        gbItems=utils.parse.extractAll(self.lastPage,'"N","id":"', '[0-9]+', '","points"',10, False)  # Limit to first 10 gradebook item, due to outrageous memory usage of extractAll!!!
        
        #grab the assignment items here
        #{"name":"Assign 000000004","type":"N","id":"22808032","points":100,"sid":"4009544","ssid":"","catid":"6727005","scrble":true,"manual":false,"userCreated":false,"vis":true,"pos":10,"limitedAttendance":false,"gbvis":true,"visAll":false,"hideAtt":false,"an":"n","isDeleg":false,"isAllowUnlimitedAttempts":true,"gpid":"","am":"y","src":"resource/x-bb-assignment","ldue":0,"due":0,"cdate":1368107447000,"align":"y"},
        self.assignmentGbItems = utils.parse.extractAll(self.lastPage,'"name":','"[^"]+?","type":"N","id":"[0-9]+?","points":[0-9]+?,"sid":"[^\']+?', 'x-bb-assignment',10, False)  # Limit to first 10 gradebook item, due to outrageous memory usage of extractAll!!!
        if len(gbItems)==0:
                self.info("Grade.openGradebookItem():  no items to grade found, skipping...")
                return False# Don't bother

        self.oid=utils.random.randomlySelectValueFromList(gbItems)
        
        #Randomize to select any user
        self.users = utils.parse.extractAll(self.lastPage, '"uid":"', '[0-9]+', '"',10) #due to memory issues
        if len(self.users)==0:
            self.info("Grade.openGradebookItem(): no users found, skipping...")
            return  False# Don't bother
            
        self.mid=utils.random.randomlySelectValueFromList(self.users)
        return True
    def openGradebookItem(self,assignmentGbItems=[]):
        # 8.0 Acessible View        
        
        if len(assignmentGbItems)>0:
            self.assignmentJson = utils.random.randomlySelectValueFromList(assignmentGbItems)
            self.oid = utils.parse.extractOnce(self.assignmentJson, '"N","id":"', '[0-9]+', '","points"', False)
            self.mid=utils.random.randomlySelectValueFromList(self.users)
            self.info(self.assignmentJson)
        self.GET('/webapps/gradebook/do/instructor/viewGradeDetails?course_id=_'+self.coursePk+'_1&outcomeDefinitionId=_'+self.oid+'_1&courseMembershipId=_'+self.mid+'_1')

    def chooseSubmitGradebookItem(self):
        '''Submit the currently open gradebook item change form'''
        #Try to extract the grade form
        modifyGradeForm=utils.parse.extractOnce(self.lastPage,'<form name="ModifyGradeForm"', ".+?", '</form>' )
       
        #If the gradeform is empty, there's nothing to do so we should return False
        if modifyGradeForm =="":
            self.info("Grade.submitGradebookItem(): modify gradebook: no users found, skipping")
            return  False
        
        #Extract the URL for the post
        self.submitGradeUrl = utils.parse.extractOnce(modifyGradeForm,'action="', ".+?", '"' )
        
        #Extracts all parameters and puts them into an NVpair
        self.submitGradeParameters =utils.parse.extractNVPairsFromForm(modifyGradeForm)
        
        #Randomly select a grade
        grade=str(utils.random.randomlySelectInt(100))
        
        #Adds additional post data that is not part of the form and handled through javascript
        utils.parse.smartUpdateNVPairs(self.submitGradeParameters,'score', grade )
        utils.parse.smartUpdateNVPairs(self.submitGradeParameters,'grade', grade )
    def submitGradebookItem(self):

        self.POST(self.submitGradeUrl, self.submitGradeParameters)
 

 
 ################################################ 
 #Box Grading

    def openBoxAssignmentForGradingCheck(self):
        #Get the attemptId from the previous page
        #return GB360.viewAttempt('_72708475_1')
        self.attemptId = utils.parse.extractOnce(self.lastPage,"viewAttempt\('_", '[0-9]+?', '_1', False)
        
        if self.attemptId !="":
            
            return True
        else:
            self.info('Grade.openBoxAssignmentForGrading(): No attempt ID found, skipping')
            return False
    def openBoxAssignmentForGrading(self):
        
        #"name":"Assign 000000001",
        name = utils.parse.extractOnce(self.assignmentJson, '"', '[^"]+?', '","type":"N"', False)
        self.GET('/webapps/gradebook/do/instructor/performGrading?course_id=_'+self.coursePk+'_1&status=ALL&viewInfo=Centro%20de%20calificaciones%20completo&itemId='+self.oid+'&category=Actividad&itemName='+name+'&source=cp_gradebook&sourceDetail=&mode=invokeFromGradeCenter&anonymousMode=false&cancelGradeUrl=%2Fwebapps%2Fgradebook%2Fdo%2Finstructor%2FenterGradeCenter%3Fcourse_id%3D_'+self.coursePk+'_1&courseMembershipId='+self.mid+'&attemptId=_'+self.attemptId+'_1')      
        self.sequenceId=self.coursePk

        
        self.submitBoxAssignmentGradeLogic()

        self.GET('/webapps/gradebook/do/instructor/getAttemptNavData?course_id=_'+self.coursePk+'_1&selectId=itemSelect&sequenceId=_'+self.sequenceId+'_1_0')

       #course_id=_2041025_1&navItemSubGroup=grade_center&newWindow=false&openInParentWindow=false
        data2=[NVPair("course_id", '_'+self.coursePk+'_1'),NVPair("navItemSubGroup", 'grade_center'),NVPair("newWindow", 'false'),NVPair("openInParentWindow", 'false')]
        self.POST('/webapps/blackboard/execute/course/getCPGradeCenterGroupItems',data2)

        



    def spellChecker(self):
    
        #{"id":"c0","method":"checkWords","params":["",["sd"]]}
        #Content-Type: application/json
        #X-Requested-With: XMLHttpRequest
        searchText = utils.baconLoremIpsum.getSearchText()
        data = '''{"id":"c0","method":"checkWords","params":["",["'''+searchText+'''"]]}'''
        #Ensure the header type is "text/xml" and the SOAPAction is set
        headers=[NVPair("Content-Type", "application/json"),NVPair("X-Requested-With", 'XMLHttpRequest')]
        

        #Posting to the web service                

        self.POST('/webapps/vtbe-tinymce/jmyspell-spellchecker',data,headers)

    def submitBoxAssignmentGradeLogic(self):
        #view-source:https://senaintro-loadtesting2018.blackboard.com/webapps/assignment/gradeAssignmentRedirector?outcomeDefinitionId=_22822728_1&currentAttemptIndex=1&numAttempts=27&anonymousMode=false&sequenceId=_2041025_1_0&course_id=_2041025_1&source=cp_gradebook&viewInfo=Centro+de+calificaciones+completo&attempt_id=_72038355_1&courseMembershipId=_55669782_1&cancelGradeUrl=%2Fwebapps%2Fgradebook%2Fdo%2Finstructor%2FenterGradeCenter%3Fcourse_id%3D_2041025_1&submitGradeUrl=%2Fwebapps%2Fgradebook%2Fdo%2Finstructor%2FperformGrading%3Fcourse_id%3D_2041025_1%26cmd%3Dnext%26sequenceId%3D_2041025_1_0
        #form id="currentAttempt_form" name="gradeAttemptForm"
        self.submitAssignmentGradeForm=utils.parse.extractOnce(self.lastPage,'form id="currentAttempt_form" name="gradeAttemptForm"', ".+?", '</form>', False )
        #If the gradeform is empty, there's nothing to do so we should return False
        if self.submitAssignmentGradeForm =="":
            self.info("Grade.submitBoxAssignmentGradeLogic(): no assignment grade form found, skipping" + self.lastPage)
            return  False

        #Extracts all parameters and puts them into an NVpair
        self.submitAssignmentGradeParameters =utils.parse.extractNVPairsFromForm(self.submitAssignmentGradeForm)
        grade=str(utils.random.randomlySelectInt(100))
        
        utils.parse.smartUpdateNVPairs(self.submitAssignmentGradeParameters,'grade',grade)
        utils.parse.smartUpdateNVPairs(self.submitAssignmentGradeParameters,'attempt_id','_'+self.attemptId+'_1')
        utils.parse.smartUpdateNVPairs(self.submitAssignmentGradeParameters,'course_id','_'+self.coursePk+'_1')
        utils.parse.smartUpdateNVPairs(self.submitAssignmentGradeParameters,'textbox_prefix','feedbacktext,gradingNotestext')
        utils.parse.smartUpdateNVPairs(self.submitAssignmentGradeParameters,'feedbacktext','<p><span class="mceItemHidden">This is <span class="mceItemHiddenSpellWord"></span></span><span class="mceItemHidden">a <span class="mceItemHiddenSpellWord"></span></span>'+utils.baconLoremIpsum.getBaconParagraph()+'<span class="mceItemHidden"><span class="mceItemHiddenSpellWord"></span>﻿</span><span class="mceItemHidden"><span class="mceItemHiddenSpellWord"></span>﻿</span><span class="mceItemHidden"><span class="mceItemHiddenSpellWord"></span>﻿asds <span class="mceItemHiddenSpellWord"></span></span><span class="mceItemHidden">sd <span class="mceItemHiddenSpellWord"></span></span><span class="mceItemHidden"><span class="mceItemHiddenSpellWord"></span>﻿</span><span class="mceItemHidden"><span class="mceItemHiddenSpellWord"></span></span><span class="mceItemHidden"><span class="mceItemHiddenSpellWord"></span>﻿</span><br data-mce-bogus="1"></p>')
        utils.parse.smartUpdateNVPairs(self.submitAssignmentGradeParameters,'gradingNotestext','<p><br data-mce-bogus="1"></p>')
        utils.parse.smartUpdateNVPairs(self.submitAssignmentGradeParameters,'cmd','next')
        utils.parse.smartUpdateNVPairs(self.submitAssignmentGradeParameters,'sequenceId','_'+self.coursePk+'_1_0')
    
    def submitBoxAssignmentGrade(self):
    
    
        # This is the Jython way of creating an NVPair[] Java array
        # with one element.
        # Randomly selects a file to upload
        file = utils.uploadFiles.getRandomFile()
        files = ( NVPair("newFile_LocalFile0", file), )
        headers = zeros(1, NVPair)

        # Create a multi-part form encoded byte array.
        data = Codecs.mpFormDataEncode(self.submitAssignmentGradeParameters, files, headers)

        #results = self.POST(url, data, headers)
        self.POST('/webapps/assignment//gradeAssignment/submit?course_id=_'+self.coursePk+'_1',data,headers)

################################################
 #Download Gradebook
 
 
    def openGradebookDownload(self):
        self.info("Grade.openGradebookDownload: Opening gradebook download for course pk "+self.coursePk)
        self.GET('/webapps/gradebook/do/instructor/downloadGradebook?dispatch=viewDownloadOptions&course_id=_'+self.coursePk+'_1')
    
    def submitGradebookDownloadLogic(self):
    
        #blackboard.platform.security.NonceUtil.nonce=54033138-1c2f-4e6e-a357-0ef79c171697&course_id=_1250191_1&userIds=&itemIds=&noCustomView=false&dispatch=setDownloadOptions
        #&downloadOption=ALL&item=_5886612_1&delimiter=TAB&hidden=false&downloadTo=LOCAL&targetPath_CSFile=&targetPath_attachmentType=C&targetPath_fileId=&bottom_Submit=Submit
            #Try to extract the grade form
        downloadGradebookForm=utils.parse.extractOnce(self.lastPage,'<form  method="post" name="downloadGradebookForm"', ".+?", '</form>', False )
        #If the gradeform is empty, there's nothing to do so we should return False
        if downloadGradebookForm =="":
            self.info("Grade.submitGradebookDownloadLogic(): no download gradebook form found, skipping" + self.lastPage)
            return  False
        
        
        #Extracts all parameters and puts them into an NVpair
        self.submitGradeDownloadParameters =utils.parse.extractNVPairsFromForm(downloadGradebookForm)
        
        #Currently we only do full grade center download
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'downloadOption',"ALL")
        
        #USERIDS
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'userIds',"")
        #Get the total column, always select the total
        #<option value="_5886612_1"  >Total</option>
        item = utils.parse.extractOnce(downloadGradebookForm,'<option value="_', "[0-9]+?", '_1"  >Total</option>' )
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'item',item)
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'itemIds',"")
        
        #Delimiter
        delimiterOptions = ['TAB','COMMA']
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'delimiter',utils.random.randomlySelectValueFromList(delimiterOptions))
        #Hidden Information
        hiddenInformationOptions = ['true','false']
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'hidden',utils.random.randomlySelectValueFromList(hiddenInformationOptions))
        #Download Location - Currently we just do locally for now
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'downloadTo',"LOCAL")
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'targetPath_CSFile',"")
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'targetPath_attachmentType',"C")
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'targetPath_fileId',"")
        utils.parse.smartUpdateNVPairs(self.submitGradeDownloadParameters,'bottom_Submit',"Submit")
        
        return True
    def submitGradebookDownload(self):
        self.POST('/webapps/gradebook/do/instructor/downloadGradebook',self.submitGradeDownloadParameters)
    
    def downloadGradebookDownloadLogic(self):
        #course_id=_1250191_1&downloadOption=ALL&delimiter=TAB&item=_5886612_1&gradePeriod=&comments=false&hidden=false&userIds=&itemIds=&downloadTo=LOCAL&blackboard.platform.security.NonceUtil.nonce=28f8fcf4-9402-4a63-a9a1-1c8ec36c48e8

            #Try to extract the grade form
        downloadGradebookDownloadForm=utils.parse.extractOnce(self.lastPage,'<form name="downloadGradebookForm"', ".+?", '</form>', False)
        #If the gradeform is empty, there's nothing to do so we should return False
        if downloadGradebookDownloadForm =="":
            self.info("Grade.downloadGradebookDownloadLogic(): no download gradebook form found, skipping")
            return  False

        #Extracts all parameters and puts them into an NVpair
        self.downloadGradebookDownloadParameters =utils.parse.extractNVPairsFromForm(downloadGradebookDownloadForm)

        return True
        
    def downloadGradebookDownload(self):
        self.POST('/webapps/gradebook/do/instructor/downloadGradebook?dispatch=executeDownload',self.downloadGradebookDownloadParameters)
        self.debug("Grade.downloadGradebookDownload(): Response: "+ self.lastPage)
