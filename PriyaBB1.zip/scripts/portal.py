# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
import config.settings
import scripts
import utils


class Portal(scripts.base.Base):


    def __init__(self, request, bblearn):
        scripts.base.Base.__init__(self, request)
        self.bblearn = bblearn
        self.portalModuleParameters = []
        self.topPortalTabURLs={}
        self.topPortalTabNames=[]
        self.resetSubPortalObjects()
        #Dictionary for the portal module titles
        self.portalModuleURLsAndNamesDictionary={}
        
        
    def resetSubPortalObjects(self):

        self.toolPanelURLs={}
        self.toolPanelNames=[]
        self.subPortalTabURLs={}
        self.subPortalTabNames=[]
        

    
    # Open a portal tab
    # If none is specified, open the default one
    # tabId: full tab identifier including underscores and suffixes: _31_1
    # url: forwarding URL, to open courses; use this URL instead of the default tabAction
    def openTab(self, tabId="", url=""):
        framesetUrl = ""
        defaultFramesetUrl = ""
        self.portalModuleParameters = []

        #VERSION SPECIFIC CODE
        if self.bblearn.versionBelowSP14:
            framesetUrl = "/webapps/portal/frameset.jsp"
            defaultFramesetUrl = "/webapps/portal/frameset.jsp"
        elif self.bblearn.versionAboveSP14:
            framesetUrl = "/webapps/portal/execute/tabs/tabAction"
            defaultFramesetUrl = "/webapps/portal/execute/defaultTab"
        else:
            self.info("Portal.openTab(): Blackboard Version not recognized, returning")
            return

        if(tabId==""):
            self.info("Portal.openTab(): Opening portal frameset")
            self.GET(defaultFramesetUrl)
            tabId=utils.parse.extractOnce(self.lastPage, 'tab_tab_group_id=_', "[0-9_]+", "_1")
        else:
            if(url==""):
                self.info("Portal.openTab(): GET "+framesetUrl+"?tab_tab_group_id=_"+tabId+"_1")
                self.GET(
				+ '?tab_tab_group_id=_'+tabId+'_1')
            else:
                self.info("Portal.openTab(): GET "+framesetUrl+"?tab_tab_group_id=_"+tabId+"_1")
                self.GET(framesetUrl + '?tab_tab_group_id=_'+tabId+"_1&url="+url)
        

        #VERSION SPECIFIC CODE
        #In Version SP14 and below we utilize frames, so here we pull out the frams and call each one
        if self.bblearn.versionBelowSP14:
            # Retrieve the new iframes
            iframes=utils.parse.extractAll(self.lastPage, '<iframe id="', '[^>]+', '></iframe>')
            
            #Iterate over each frame
            for f in iframes:
                
                # Pull out the individual src parameters
                src = utils.parse.extractOnce(f, 'src="', '[^"]+', '"')
               
                if src != "":
                    src=src.replace("amp;","")
                    self.GET(src)
                    
                     #Extract the Course Tab and the Content Collection Tab from the results and place it into the bblearn object
                    self.bblearn.extractBbLearnCourseContentTabPks(self.lastPage,framesetUrl)
       
        elif self.bblearn.versionAboveSP14:
            #Extract the Course Tab and the Content Collection Tab from the results and place it into the bblearn object
            self.bblearn.extractBbLearnCourseContentTabPks(self.lastPage,framesetUrl)
                    
    
    def loadPortalTabCheck(self):
    
        #Extract the Images/JS/CSS from the results and place it into the bblearn object
        self.bblearn.extractBbLearnImagesJSCSS(self.lastPage)
        # Pull out the string of parameters from the AJAX call
        #new Ajax.Request('/webapps/portal/execute/tabs/tabAction', {method: 'post',parameters: 'action=refreshAjaxModule&modId=_1_1&tabId=_30_1&course_id=_6_1&cmp_tab_id=_30_1',onSuccess: 
        
        
        ###self.portalModuleParameters=utils.parse.extractAll(self.lastPage, "parameters: '", "[^']+", "', onSuccess")
        self.portalModuleParameters=utils.parse.extractAll(self.lastPage, "parameters: '", "[^']+", "',",10,False)
        self.info("Portal.loadPortalTabCheck(): Found "+str(len(self.portalModuleParameters)) + " portal modules.")
        
        
          #Adding support for the module name
            #<span class="moduleTitle" >Lista de mis Programas de Formación</span>
            #<span class="moduleTitle" style="display:none;">mod_sabias_que</span>
        self.portalModuleTitles=utils.parse.extractAll(self.lastPage, "<span", '[^|]+?moduleTitle[^|]+?refreshAjaxModule[^|]+?', "onSuccess:",10,False)
        
        for portalModuleTitle in self.portalModuleTitles:
            individualModuleURL = utils.parse.extractOnce(portalModuleTitle, "parameters: '", "[^']+", "',",False)
            individualModuleTitle = utils.parse.extractOnce(portalModuleTitle, '"moduleTitle".+?>', ".+?", "</span>",False)
            if individualModuleURL!="":
                self.debug("Portal.loadPortalTabCheck(): Portal Module: "+individualModuleTitle+" with URL: " + individualModuleURL)
                #Store the array of tabNames for use later so they can be iterated through
                self.portalModuleURLsAndNamesDictionary[individualModuleURL] = individualModuleTitle
                

        

    # Load any asynchronous tab modules from the last tab loaded
    def loadTabModules(self):

        isCourseModule = False

        # Log any asynchronous module
        # Append any output to the main lastPage
        accumulatedLastPage = self.lastPage
        self.courseId = ""        
        if len(self.portalModuleParameters)==0:
            self.info("Portal.loadTabModules(): No portal modules found on this page, skipping..")
            return
            
        for parameter in self.portalModuleParameters:
            moduleTitle=" Module Title Not Available..."
            # Pull out the individual parameters
            modId =utils.parse.extractOnce(parameter, "modId=_", "[0-9]+", "_1",False)
            self.courseId =utils.parse.extractOnce(parameter, "course_id=_", "[0-9]+", "_1",False)
            self.cmpTabId =utils.parse.extractOnce(parameter, "cmp_tab_id=_", "[0-9]+", "_1",False)
            tabId=utils.parse.extractOnce(parameter, "tabId=_", "[0-9]+", "_1",False)
            tabtabId=utils.parse.extractOnce(parameter, "tab_tab_group_id=_", "[0-9]+", "_1",False)
            
            if self.portalModuleURLsAndNamesDictionary.has_key(parameter):
                moduleTitle = self.portalModuleURLsAndNamesDictionary[parameter] 

            if(self.courseId!=""):
                #if it has a course ID then it's a course module
                isCourseModule = True
                self.info("Portal.loadTabModules(): Loading async course module: " + moduleTitle)
                
                accumulatedLastPage = accumulatedLastPage + "\n" + self.loadCourseModule( modId, tabId, self.courseId, self.cmpTabId)
                
            else:
            #otherwise it's a portal module
                self.info("Portal.loadTabModules(): Loading async portal module: "+ moduleTitle)
                
                accumulatedLastPage = accumulatedLastPage + "\n" + self.loadPortalModule( modId, tabId,tabtabId)
        
        #if this is a course page, we should load the nautilius alerts module as well, but only once
        if(self.courseId!=""):
            self.info("Portal.loadTabModules(): Loading async alerts module "+self.cmpTabId)
            self.loadAlertModule(self.cmpTabId)
            accumulatedLastPage = accumulatedLastPage + "\n" + self.lastPage


        #Either way we should accumlate everything into the last page. Set all the accumlated pages as the last page
        self.lastPage = accumulatedLastPage
        ###Marcus added this if-else block to make course ID parsing more reliable (edited in bblearn.py as well: extractBbLearnCoursePk)
        if isCourseModule == False:
        
        #if this isn't a course module, we should check to see if we find the course id's first. 
            if self.bblearn.extractBbLearnCoursePk(self.lastPage) == False:
                #If we don't find them the traditional way through the course module, we should search in the global nav menu
                self.info("Portal.loadTabModules(): Did not find any courses with the usual methods grabbing it from the globalNavMenu" )
                self.GET('/webapps/blackboard/execute/globalCourseNavMenuSection?cmd=view&serviceLevel=blackboard.data.course.Course$ServiceLevel:FULL')
                bufferGlobalNavMenu = self.lastPage
                #self.info("Portal.loadTabModules(): DEBUG: bufferGlobalNavMenu: " + bufferGlobalNavMenu)
                #Set all the accumlated pages AND globalNameMenu as the last page
                self.lastPage = accumulatedLastPage + "\n" + bufferGlobalNavMenu
                #After we've loaded the global context menu, we should recheck the page for course-id's
                self.bblearn.extractBbLearnCoursePk(self.lastPage)
                
        #Extract the Images/JS/CSS from the results and place it into the bblearn object
        self.bblearn.extractBbLearnImagesJSCSS(self.lastPage)

  
        
    #special method for mapping that just loads the course information so we can bypass the rest of the portal use cases
    def loadCourseMemberships(self):
        self.GET('/webapps/blackboard/execute/globalCourseNavMenuSection?cmd=view&serviceLevel=blackboard.data.course.Course$ServiceLevel:FULL')
        #Extract the Course PK's from the portal page for the user and place it into the bblearn object
        self.bblearn.extractBbLearnCoursePk(self.lastPage)
    #Function to grab all of the portal objects from a page(i.e. top frame urls, my tools urls, and any sub pane tabs)
    def extractPortalObjects(self,isInitialLoad=False):
        
        
        if isInitialLoad:
            self.topPortalTabURLs={}
            self.topPortalTabNames=[]
            self.extractPortalObjectURLSAndNames("Top Frame",self.lastPage,'<div class="tabWrapper','<div class="clearfloats"></div>',self.topPortalTabURLs,self.topPortalTabNames) 
        
        self.resetSubPortalObjects()
        self.extractPortalObjectURLSAndNames("Tool Panel",self.lastPage,'<ul class="portletList">','</div>',self.toolPanelURLs,self.toolPanelNames) 
        self.extractPortalObjectURLSAndNames("Sub Tabs",self.lastPage,'<ul id="paneTabs"','</ul>',self.subPortalTabURLs,self.subPortalTabNames)
    
    #Helper function that does the heavy lifting       
    def extractPortalObjectURLSAndNames(self,identifier,page,leftDivRegex,rightDivRegex,portalObjectURLsAndNamesDictionary,portalObjectNameList):
        
        #Grab the name div class for a particular group of portal objects
        mainDivClassHTML=utils.parse.extractOnce(page, leftDivRegex, ".+?", rightDivRegex,False)
        
        #grab the snippet of HTML code for each of the unique URLS
        individualPortalURLsAndNames=utils.parse.extractAll(mainDivClassHTML, '<a ', 'href="/webapps/.+?', 'a>',10,False)
        
        
        
        for individualPortalURLsAndName in individualPortalURLsAndNames:
            #we breakdown the snippet into the tabId and tabName
            individualPortalURL = utils.parse.extractOnce(individualPortalURLsAndName,'href="',"/webapps/.+?",'"',False)
            individualPortalName = utils.parse.extractOnce(individualPortalURLsAndName,">",".+?","<",False)
            individualPortalName = individualPortalName.replace("<span>","")
            if individualPortalURL!="":
                #self.info("Portal.extractPortalObjectURLSAndNames(): Portal "+identifier+": \""+individualPortalName+"\" with URL: " + individualPortalURL)
                #For now we store the portal object names in the warn log so that they can then be used later
                
                #Run this awk script to grab the unique portal objects 
                #zcat student/warn_fgprd-bbperf-app*.log.gz |awk -F"|" '{key=$2"|"$3;count[key]++} END { for(key in count) {print key, count[key]}}'  |sort
                if config.settings.initialPortalNamesMapping:
                    self.warn("|"+identifier+"|"+individualPortalName)
                #Store the array of tabNames for use later so they can be iterated through
                portalObjectURLsAndNamesDictionary[individualPortalName] = individualPortalURL
                portalObjectNameList.append(individualPortalName)
            else:
                self.error("Portal.extractPortalObjectURLSAndNames(): Could not find URL for "+ individualPortalName+" "+identifier)
                
        self.info("Portal.extractPortalObjectURLSAndNames(): Found " + str(len(portalObjectNameList))+ " "+ identifier+ " on this page..."+', '.join(portalObjectNameList))
        #Method to check to see if a target exist and 
    def doesPortalObjectExist(self,target,dictionary):
        #If the target is in the dictionary, we set that to be the targetUrls
        if dictionary.has_key(target):
            return True
        else:
            return False

            
    #Method to check to see if a target exist and 
    def openPortalObject(self,identifier,target,dictionary):
        
        #If the target is in the dictionary, we set that to be the targetUrls
        if dictionary.has_key(target):
            targetUrl=dictionary[target]  
        
            #Check to see if there's actually a urls, if so we grab them from the list and return the URL
            if targetUrl !="":
            
                #targetUrl = utils.random.randomlySelectValueFromList(targetUrls)
                grinder.logger.info("Portal.openPortalObject(): Opening target \""+ target+"\" from "+identifier)
                self.GET(targetUrl)
                
            else:
                grinder.logger.info("Portal.openPortalObject(): No portal "+identifier+" URL found for target \""+ target+"\"")

        else:
            grinder.logger.info("Portal.openPortalObject(): Target \"" + target+"\" for "+identifier+"  was not found, skipping...")

    
    def loadPortalModule(self, modId, tabId,tabtabId):

        data = (
          NVPair('action', 'refreshAjaxModule'),
          NVPair('modId', '_'+ modId+'_1'),
          NVPair('tabId', '_'+ tabId+'_1'),
          NVPair('tab_tab_group_id','_'+tabtabId+'_1')
          )
        self.POST('/webapps/portal/execute/tabs/tabAction', data)
        accumulatedLastPage = self.lastPage
        accumulatedLastPage = accumulatedLastPage + "\n" + self.loadModuleObjects(self.lastPage)
        self.debug("Module HTML:" + accumulatedLastPage)
        return accumulatedLastPage
        
        
    def loadCourseModule(self, modId, tabId,courseId,cmpTabId):
        
        data = (
          NVPair('action', 'refreshAjaxModule'),
          NVPair('modId', '_'+ modId+'_1'),
          NVPair('tabId', '_'+tabId+'_1'),
          NVPair('course_id', '_'+ courseId+'_1'),
          NVPair('cmp_tab_id','_'+ cmpTabId+'_1')
          )
        self.POST('/webapps/portal/execute/tabs/tabAction', data)
        accumulatedLastPage = self.lastPage
        accumulatedLastPage = accumulatedLastPage + "\n" + self.loadModuleObjects(self.lastPage)
        self.debug("Module HTML:" + accumulatedLastPage)
        return accumulatedLastPage
    def loadAlertModule(self, cmpTabId):
                
        data = (
          NVPair('callCount', '1page'),
          NVPair('cmp_tab_id','_'+ cmpTabId+'_1httpSessionId' )
          )
        self.POST('/webapps/blackboard/dwr_open/call/plaincall/NautilusViewService.getEwsViewInfo.dwr',data)
        self.POST('/webapps/blackboard/dwr_open/call/plaincall/NautilusViewService.getViewInfo.dwr',data)
        
        data = (
          NVPair('callCount', '5page'),
          NVPair('cmp_tab_id','_'+ cmpTabId+'_1httpSessionId' )
          )
        self.POST('/webapps/blackboard/dwr_open/call/plaincall/Multiple.5.dwr',data)
   
    def loadModuleObjects(self,lastPage):
        #Extract the Images/JS/CSS from the results and place it into the bblearn object
        #self.info(self.lastPage)
        accumulatedLastPage = ""
        #need to figure out how to capture multiple
        #portalObjectURLs=utils.parse.extractAll(self.lastPage, 'src="', '[^"]+(png|jpg)', '"',10,True)
        portalObjectURLs=utils.parse.extractAll(self.lastPage, 'src="', '[^"]+?', '"',15,False)
        if len(portalObjectURLs)>0:
            self.info("Portal.loadModuleObjects(): Found "+str(len(portalObjectURLs)) + " HTML objects within this portal module.")
        for objectURL in portalObjectURLs:
           self.GET(objectURL)
           accumulatedLastPage = accumulatedLastPage + "\n" + self.lastPage
        return accumulatedLastPage
    def openPortalAnnouncements(self):
        
        if len(self.bblearn.portalAnnouncementUrl)>0:
            self.info("Portal.openPortalAnnouncements(): Opening the user's portal announcement link")
            self.GET(self.bblearn.portalAnnouncementUrl)
        else:
            self.info("Portal.openPortalAnnouncements(): User does not have a portal announcement link, skipping...")
    
    def openPortalMyGrades(self):
       
        if len(self.bblearn.studentPortalMyGradeUrl)>0:
            self.info("Portal.openPortalMyGrades(): Opening the user's portal my grade link")
            self.GET(self.bblearn.studentPortalMyGradeUrl)
            
            #Open the social b2 grades
            self.GET('/webapps/bb-social-learning-'+ self.bblearn.vi +'/execute/mybb?cmd=display&toolId=MyGradesOnMyBb_____MyGradesTool&extraParams=override_stream=mygrades')
            
            if len(self.bblearn.coursePks)==0:
                self.info("Portal.openPortalMyGrades():User is not enrolled in any courses, can not open course my grades module, skipping...")
                self.coursePk = utils.random.randomlySelectValueFromList(self.bblearn.coursePks)
            
                #Open the mygrades module as well
                self.GET('/webapps/bb-mygrades-'+self.bblearn.vi+'/myGrades?course_id=_'+self.coursePk+'_1&stream_name=mygrades')
        else:
            self.info("Portal.openPortalMyGrades(): User does not have a portal my grades link , skipping...")
    
    def openPortalCalendar(self):
       
        if len(self.bblearn.portalCalendarUrl)>0:
            self.info("Portal.OpenPortalCalendar(): Opening the user's portal calendar link")
            self.GET(self.bblearn.portalCalendarUrl)
            
                    
            #self.GET('/webapps/calendar/viewPersonal')
            #self.GET('/webapps/calendar/calendarData/calendars?mode=personal&course_id=&_=1425436269513')
            #self.GET('/webapps/calendar/calendarData/selectedCalendarEvents?start=1425186000000&end=1428811200000&course_id=&mode=personal')
        else:
            self.info("Portal.OpenPortalCalendar(): User does not have a portal calendar link , skipping...")
    def submitPortalCalendarEvent(self):
        #Performing JSON post
        payload= '''{
            \"calendarId\":\"PERSONAL\",    
            \"title\":\"THIS IS A TEST\",    
            \"description\":\"THIS IS A TEST\", 
            \"start\":\"2015-03-03T21:00:00\",
            \"end\":\"2015-03-03T21:30:00\",
            \"allDay\":false,
            \"recur\":false,
            \"freq\":\"WEEKLY\",
            \"interval\":\"1\", 
            \"byDay\":[\"TU\"],
            \"monthRepeatBy\":\"BYMONTHDAY\",
            \"byMonthDay\":\"1\", 
            \"bySetPos\":\"1\" ,
            \"endsBy\":\"COUNT\" ,
            \"count\":\"10\" ,
            \"untilDate\":\"2015-05-03T20:49:00\"
            }'''
            #JSESSIONID=8ADA280B3F98B48CED0E81D13ED38C33; JSESSIONID=8A403E807B344C1B4534E564DA8970EF; session_id=AD4266F2556421DCD47682498798BD14; s_session_id=ECBEC837C5DBDF6FBE3FEC82171E35F3; web_client_cache_guid=b767aede-c581-4023-9966-b952526cd7e2; NSC_555555_wjq_69.196.230.4*443=ffffffff090d1da045525d5f4f58455e445a4a4229a0; cookies_enabled=yes
    #"byMonthDay":"1","bySetPos":"1","endsBy":"COUNT","count":"10","untilDate":"2015-05-03T20:49:00"}
    #{"calendarId":"PERSONAL","title":"test","description":"sfdsdf","start":"2015-03-03T21:00:00","end":"2015-03-03T21:30:00","allDay":false,"recur":false,"freq":"WEEKLY","interval":"1","byDay":["TU"],"monthRepeatBy":"BYMONTHDAY","byMonthDay":"1","bySetPos":"1","endsBy":"COUNT","count":"10","untilDate":"2015-05-03T20:49:00"}
        headers=[]
    #add authorization header
    #set the content type = Application/json
        headers.append(NVPair("Accept", "application/json"),)
        headers.append(NVPair("Content-type", "application/json"),)
        headers.append(NVPair("X-Requested-With", "XMLHttpRequest"),)
        self.POST("/webapps/calendar/calendarData/event",payload,headers)

#ULTRA use cases    

    def openUltraActivityStream(self):
        self.GET("/ultra/")

        #Extract the Images/JS/CSS from the results and place it into the bblearn object
        self.bblearn.extractUltraUserPk(self.lastPage)
        
        self.GET("/learn/api/v1/users/_" + self.bblearn.userPk + "_1/memberships?fields=courseId,courseRole,role,courseCardColorIndex")
        
        #Extract the Ultra Course PK's from the page
        self.bblearn.extractBbLearnCoursePk(self.lastPage)
        #Parse result for Course ID {"results":[{"role":"S","courseId":"_170_1","courseRole":{"isAvailableForCourseEnrollment":true,"isAvailableForOrgEnrollment":true,"isActAsInstructor":false,"isRemovable":false,"description":"","courseName":{"serviceLevel":null,"languageKey":"S.name","bundle":"course_roles"},"orgName":{"serviceLevel":null,"languageKey":"S.org_name","bundle":"course_roles"},"roleAvailability":"Both","identifier":"S","sortOrder":32766,"roleBucket":"TAKING","name":null},"courseCardColorIndex":1}],"paging":{"nextPage":"","previousPage":"","limit":20,"count":1,"offset":0},"permissions":null}
