# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from HTTPClient import NVPair

from net.grinder.script.Grinder import grinder
import config.settings
import scripts
import utils
###import utils.baconLoremIpsum

class Bbmobile(scripts.base.Base):

    def __init__(self, request,bblearn):
        scripts.base.Base.__init__(self, request)
        #self.bbMobileVersion = config.settings.bbMobileVersion
        self.bbRegIdParam = config.settings.bbRegId
        self.bblearn = bblearn
        #randomly selects the mobile version
        self.bbMobileVersion = utils.random.utils.random.randomlySelectValueFromList(['4.1.2','4.1.4','3.1.2'])
        self.isBbStudentApp = False
        self.contentFolderIds = []
        self.contentItemURLs = []
        self.contentItemIds = []
        self.dbForumIds = []
        self.dbThreadIds = []
        self.blogURLs = []
        self.journalURLs = []
        self.taskURLs = []
        self.assessmentIds =[]
        self.errorStatus = False
        self.isMobileDisabled = False
    # Initial Bb Mobile request to grab list of enrolled courses
    
    def mobilePing(self):
        self.info("Mobile.mobilePing()")

        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/ping?is_mbaas=true')
        
        #Collab Ultra ping
        #self.GET('/learn/api/v1/collabultra/ping')
        
        #Commented out for now, as we need more information about the put
        #self.PUT('/learn/api/v1/utilities/batch')
    def getSystemRegistry(self):
    
        self.info("Mobile.getSystemRegistry()")
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/systemRegistry?registry_key=bb_cloud_site_id&is_mbaas=true')
    #def sslUserLogin(self):
    #    self.info("Mobile.sslUserLogin()")
    #
    #    self.POST('/webapps/Bb-mobile-' + self.bblearn.vi + '/sslUserLogin?v=1&ver=' + self.bbMobileVersion + 'language=en_US',data)

    def loadCourseEnrollments(self,isOrg = False):
        ### Marcus
        self.info("Mobile.loadCourses(): Requesting Bb Mobile Course ID's")

        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/enrollments?course_type=COURSE&is_mbaas=true&include_grades=false')
        self.isMobileDisabled = utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.loadCourseEnrollments(): Bb Mobile B2 is not enabled")

        if config.settings.logDebugMessages == True:
            self.debug("Mobile.loadCourseEnrollments(): Response " + ' '.join(self.lastPage.splitlines()))
            linkIds = utils.parse.extractAll(self.lastPage, '<course bbid="_', '[0-9]+?', '_1"', 50, False)
            self.debug("Mobile.loadCourseEnrollments(): All Section Link ID's: " + ' '.join(linkIds))

        
    def loadCoursesExtract(self):
        self.coursePks =[]
        
        if self.isMobileDisabled:
            return self.coursePks
        else:
            # Parse Course ID's from XML, we should only take available and visible courses
            #<course bbid="_1634748_1" name="2018 Fall Term (1) Advanced Criminalistics I FOS 710 01[11815] (John Jay College)" courseid="JJC01_FOS_710_01_1189_1" role="Courses in which you are enrolled:" courseRoleCanSeeUnavailableCourse="false" isAvail="true" isVisible="true" locale="en_US" ultraStatus="CLASSIC" dueDateExceptionType="Normal" lastAccessDate="2018-11-05T22:08:37-0500" enrollmentdate="2018-06-10T16:04:53-0400" roleIdentifier="S" durationType="CONTINUOUS" daysFromTheDateOfEnrollment="0"><term id="_113_1" name="2018 Fall Term (JJC01)" isAvailable="true" duration="C" daysFromEndOfEnrollment="0"><description></description></term><instructors><instructor id="_391857_1" avatarUrl="https://cuny-loadtesting2018.blackboard.com/images/ci/ng/default_profile_avatar.png" firstname="John" middleName="" lastName="Reffner" title="" suffix="" otherName=""/><instructor id="_339245_1" avatarUrl="https://cuny-loadtesting2018.blackboard.com/images/ci/ng/default_profile_avatar.png" firstname="Tiffany" middleName="J" lastName="Millett" title="" suffix="" otherName=""/></instructors></course>
            self.coursePks = utils.parse.extractAll(self.lastPage, '<course bbid="_', '[0-9]+?', '_1" name="[^"]+?" courseid="[^"]+?" role="[^"]+?" courseRoleCanSeeUnavailableCourse="false" isAvail="true" isVisible="true"', 50, False)
            self.debug("Mobile.loadCourseEnrollments(): All Available Section Link ID's: " + ' '.join(self.coursePks))
            return self.coursePks

    # Request to determine Bb Mobile settings (static request)
    #- DCHOW 10/29/2018 - Deprecated as of 3400 and Bb Student version 3.10.0
    #def getSettings(self):
    #    self.info("Mobile.getSettings(): Requesting Bb Mobile Settings")
    #
    #    ### Notice that the Ultra version of Bb Student doesn't actually generate any settings traffic unless an option is toggled
    #    self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/push/getAllSettings')
    #    utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile: Load Settings Not Successful")
    #
    # Open a course
    def loadCourseInfo(self, coursePk):
        ### Marcus
        self.info("Mobile.loadCourseInfo(): Requesting Bb Mobile Course Info for course pk: " + coursePk)

        # Opens Primary Course Data
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseDetail?course_id=_' + coursePk + '_1&is_mbaas=true&skip_roster=true')

        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.loadCourseInfo(): Load Course Info Not Successful")
        self.debug("Mobile.loadCourseInfo(): Section 1: " + ' '.join(self.lastPage.splitlines()))


        # Opens Secondary Course Data
        self.info("Mobile.loadCourseInfo(): Secondary BEGIN")
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseDetail?course_id=_' + coursePk + '_1&is_mbaas=true&ignore_roster_setting=true&role_type=INSTRUCTOR&role_type=TEACHING_ASSISTANT&role_type=GRADER&role_type=COURSE_BUILDER&avatar_count=0')
        self.debug("Mobile.loadCourseInfo(): Section A: " + ' '.join(self.lastPage.splitlines()))
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseData?course_id=_' + coursePk + '_1&course_section=GRADES&is_mbaas=true&locale_string=en_US')
        self.debug("Mobile.loadCourseInfo(): Section GRADE: " + ' '.join(self.lastPage.splitlines()))
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseData?course_id=_' + coursePk + '_1&course_section=ANNOUNCEMENTS&is_mbaas=true')
        self.debug("Mobile.loadCourseInfo(): Section ANNOUNCEMENT: " + ' '.join(self.lastPage.splitlines()))
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseData?course_id=_' + coursePk + '_1&course_section=FORUMS&is_mbaas=true')
        self.debug("Mobile.loadCourseInfo(): Section FORUMS: " + ' '.join(self.lastPage.splitlines()))

        self.info("Mobile.loadCourseInfo(): Tertiary BEGIN")
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseDetail?course_id=_' + coursePk + '_1&is_mbaas=true&ignore_roster_setting=true&role_type=INSTRUCTOR&role_type=TEACHING_ASSISTANT&role_type=GRADER&role_type=COURSE_BUILDER')
        self.debug("Mobile.loadCourseInfo(): Section X: " + ' '.join(self.lastPage.splitlines()))
        #self.GET('/learn/api/v1/courses/_'+ coursePk +'_1/collabultra/sessions?sessionCategory=COURSE,DEFAULT')
        #self.debug("Mobile.loadCourseInfo(): Section COLLAB: " + ' '.join(self.lastPage.splitlines()))
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseMap?course_id=_' + coursePk + '_1&is_mbaas=true&is_new=true&load_forums=true&rich_content_level=FULL&is_recursive=false&no_img2a_contentHandlers=resource/x-bb-document')
        self.debug("Mobile.loadCourseInfo(): Section DOCUMENTS: " + ' '.join(self.lastPage.splitlines()))

        
        #We should grab the course calendar as well, currenlty not implemented. 
        ###self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseCalendar?course_id=_' + coursePk + '_1&start_date=2018-10-29T16:16:39-0400&end_date=2018-11-12T15:16:39-0500' )
        ##self.debug("Mobile.Section Z: " + self.lastPage)
    
    
    #DCHOW 10/29/2018 - this gets called during course load, not sure why multiple users are being randomly loaded
    def loadUserInfo(self,userId):
        self.GET('/webapps/Bb-mobile-bb_bb60/userInfo?user_id=_'+userId+'_1&is_mbaas=true')
        self.debug("Mobile.loadUserInfo(): Load User Information: " + ' '.join(self.lastPage.splitlines()))
    def loadCourseExtract(self):
        self.debug("Mobile.loadCourseExtract(): Server Response: "+self.lastPage)

        #Get list of content folders
        self.contentFolderIds = utils.parse.extractAll(self.lastPage, '<map-item contentid="_', '[0-9]+', '_1" [^|]+? isfolder="true"', 50, False)
       
        #for assessments, we need to grab the whole xml as we have to unpackage it to get the assessment Pk and content pk value
        #<map-item contentid="_11722_1" itemFileSize="11" name="10Q-ESS-AAO" viewurl="/webapps/blackboard/content/launchAssessment.jsp?course_id=_496_1&amp;content_id=_11722_1&amp;mode=view&amp;fromMobile=true" isAvail="true" linktype="COURSE_ASSESSMENT" linktarget="_11722_1" assessment_type="resource/x-bb-asmt-test-link" is_assessment_mobile_friendly="false" isfolder="false" datemodified="2012-05-19T13:18:52-0400" createdDate="2008-06-19T12:58:48-0400" dueToday="0" pastDue="0" dueTomorrow="0" dueAfterTomorrow="0" submissionNumber="0" maxNumberOfSubmission="0" new="false" unreadItems="0"/>
        self.assessmentIdsXML = utils.parse.extractAll(self.lastPage, 'launchAssessment.jsp','[^|]+?linktype="COURSE_ASSESSMENT"[^|]+?', '/>', 50, False)
        
        self.assessmentURLs = utils.parse.extractAll(self.lastPage, '<map-item.+?viewurl="','launchAssessment.jsp[^"]+?', '" isAvail="true" linktype="COURSE_ASSESSMENT"', 50, False)
        #Assignment
        #<map-item contentid="_11720_1" itemFileSize="4393" name="Assign 000000011" viewurl="/webapps/assignment/uploadAssignment?content_id=_11720_1&amp;course_id=_496_1&amp;group_id=&amp;mode=view&amp;fromMobile=true" isAvail="true" linktype="resource/x-bb-assignment" linktarget="_11720_1" isfolder="false" datemodified="2012-05-19T13:18:52-0400" createdDate="2008-06-19T12:58:48-0400" dueToday="0" pastDue="0" dueTomorrow="0" dueAfterTomorrow="0" submissionNumber="0" maxNumberOfSubmission="0" new="false" unreadItems="0"/>
        self.assignmentURLs = self.blogURLs = utils.parse.extractAll(self.lastPage, '<map-item.+?viewurl="','/webapps/assignment/uploadAssignment[^"]+?', '" isAvail="true" linktype="resource/x-bb-assignment"', 50, False)
        #self.dbForumIds = utils.parse.extractAll(self.lastPage, '<map-item [^|]+? linktype="FORUM" linktarget="_', '[0-9]+', '_1"', 50, False)
        #if this is 3400, <forum name="Forum 000000003" bbid="_1081_1" threadCount=q"0" totalposts="16" unreadposts="16" isavailable="true" new="true" gradedForum="false" isGroup="false" showInWebView="false">
        self.dbForumIds = utils.parse.extractAll(self.lastPage, '<forum name="[^|]+? bbid="_', '[0-9]+', '_1"', 50, False)
        
        ###<map-item itemFileSize="0" name="Blogs" viewurl="/webapps/blackboard/content/launchLink.jsp?course_id=_136_1&tool_id=_1331_1&tool_type=TOOL&mode=view&fromMobile=true" isAvail="true" linktype="blogs" isfolder="false" unreadItems="0" unreadKey="21215719" canMarkAsRead="true" new="false"/>
        self.blogURLs = utils.parse.extractAll(self.lastPage, '<map-item.+?viewurl="','[^"]+?tool_type=TOOL[^"]+?', '" isAvail="true" linktype="blogs"', 50, False)
        ###<map-item itemFileSize="0" name="Journals" viewurl="/webapps/blackboard/content/launchLink.jsp?course_id=_136_1&tool_id=_1333_1&tool_type=TOOL&mode=view&fromMobile=true" isAvail="true" linktype="journal" isfolder="false" unreadItems="0" unreadKey="1015211814112" canMarkAsRead="true" new="false"/>
        self.journalURLs = utils.parse.extractAll(self.lastPage, '<map-item.+?viewurl="','[^"]+?tool_type=TOOL[^"]+?', '" isAvail="true" linktype="journal"', 50, False)
        ###<map-item itemFileSize="0" name="Tasks" viewurl="/webapps/blackboard/content/launchLink.jsp?course_id=_136_1&tool_id=_162_1&tool_type=TOOL&mode=view&fromMobile=true" isAvail="true" linktype="tasks" isfolder="false" new="false"/>
        self.taskURLs = utils.parse.extractAll(self.lastPage, '<map-item.+?viewurl="','[^"]+?tool_type=TOOL[^"]+?', '" isAvail="true" linktype="tasks"', 50, False)

        self.info("Mobile.loadCourseExtract(): Found " + str(len(self.contentFolderIds)) + " content folders Ids" )
        self.info("Mobile.loadCourseExtract(): Found " + str(len(self.assessmentIdsXML)) + " assessment XML" )
        self.info("Mobile.loadCourseExtract(): Found " + str(len(self.assessmentURLs)) + " assessment URLS" )
        self.info("Mobile.loadCourseExtract(): Found " + str(len(self.dbForumIds)) + " discussion board forums Ids" )
        self.info("Mobile.loadCourseExtract(): Found " + str(len(self.assignmentURLs)) + " assignment URLS" )
        self.info("Mobile.loadCourseExtract(): Found " + str(len(self.blogURLs)) + " blog tool URLs" )
        self.info("Mobile.loadCourseExtract(): Found " + str(len(self.journalURLs)) + " journal tool URLs" )
        self.info("Mobile.loadCourseExtract(): Found " + str(len(self.taskURLs)) + " task tool URLs" )
        
    #Gets what's new in each course -- Can't find an equivalent for this in Ultra Bb Student???
    def loadWhatsNew(self,coursePk):
        self.info("Mobile.loadWhatsNew(): Requesting Bb Mobile Loading What's New for course pk: " + coursePk)

        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/enrollments/whatsNew?course_id=_' + coursePk + '_1&language=en_US&v=1&ver=' + self.bbMobileVersion )
        
        self.debug ("Mobile.loadWhatsNew(): Server Response: " + self.lastPage)
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.loadWhatsNew(): Load Whats New Not Successful")
        
    # Other Bb Mobile Requests
    def openAnnouncements(self, coursePk):
        ### Marcus
        self.info("Mobile.openAnnouncements(): Requesting Bb Mobile Course Announcements")

        # Opens Announcements
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseData?course_id=_' + coursePk + '_1&course_section=ANNOUNCEMENTS&is_mbaas=true')
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.openAnnouncements(): Open Announcements Not Successful")
        self.debug("Mobile.openAnnouncements(): BEGIN")
        self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
        self.debug("Mobile.openAnnouncements(): END")

    def openDiscBoard(self, coursePk):
        ### Marcus
        self.info("Mobile.openDiscBoard(): Requesting Bb Mobile Course Discussion Boards")

        # Opens Discussion Board
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseData?course_id=_' + coursePk + '_1&is_mbaas=true&course_section=FORUMS')
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.openDiscBoard(): Open Discussion Board Not Successful")
        self.info("Mobile.openDiscBoard(): BEGIN")
        #self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
        linkIds = utils.parse.extractAll(self.lastPage, 'forumId="_', '[0-9]+?', '_1"', 50, False)
        self.info("Mobile.Section Link ID's: " + ' '.join(linkIds))
        self.info("Mobile.openDiscBoard(): END")

    def openDiscThread(self, coursePk, forumId):
        ### Marcus
        self.info("Mobile.openDiscThread(): Requesting Bb Mobile Course Discussion Boards Thread")

        # Opens Discussion Board Thread
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseData?course_id=_' + coursePk + '_1&is_mbaas=true&course_section=THREADS&forum_id=_' + forumId + '_1')
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.openDiscThread(): Open Discussion Board Thread Not Successful")
        self.info("Mobile.openDiscThread(): BEGIN")
        #self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
        linkIds = utils.parse.extractAll(self.lastPage, '<post bbid="_', '[0-9]+?', '_1"', 50, False)
        self.info("Mobile.Section Link ID's: " + ' '.join(linkIds))
        self.info("Mobile.openDiscThread(): END")
        
    def openDiscThreadExtract(self):
        self.debug(self.lastPage)

        self.dbThreadIds = utils.parse.extractAll(self.lastPage, '<post bbid="_', '[0-9]+?', '_1"', 50, False)

        self.info("Mobile.openDiscThreadExtract(): Found " + str(len(self.dbForumIds)) + " discussion board posts" )

    #Opens a discussion board post
    def openDiscPost(self, coursePk, threadId):
        ### Marcus
        self.info("Mobile.openDiscPost(): Requesting Bb Mobile Course Discussion Boards Post")

        # Opens Discussion Board Post
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseData?course_id=_' + coursePk + '_1&is_mbaas=true&course_section=POSTS&thread_id=_' + threadId + '_1')
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.openDiscPost(): Open Discussion Board Post Not Successful")
        self.info("Mobile.openDiscPost(): BEGIN")
        self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
        self.info("Mobile.openDiscPost(): END")

    #Replies a discussion board post
    def openDiscPostReply(self, coursePk, forumId, threadId):
        ### Marcus
        self.info("Mobile.openDiscPostReply(): Replying Bb Mobile Course Discussion Boards Post")

        # Reply Discussion Board Post
        postData = [
          NVPair("message_body", utils.baconLoremIpsum.getBaconParagraph()),
          NVPair("message_subject", utils.baconLoremIpsum.getBaconTitle()),
          NVPair("is_anonymous", "false")
        ]
        self.POST('/webapps/Bb-mobile-' + self.bblearn.vi + '/discussion/message?is_mbaas=true&course_id=_' + coursePk + '_1&forum_id=_' + forumId + '_1&parentMessage_id=_' + threadId + '_1&postCount=0', postData)
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.openDiscPostReply(): Open Discussion Board Post Reply Not Successful")
        self.info("Mobile.openDiscPostReply(): BEGIN")
        self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
        self.info("Mobile.openDiscPostReply(): END")

        ### Reload Discussion Board Post
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseData?course_id=_' + coursePk + '_1&is_mbaas=true&course_section=POSTS&thread_id=_' + threadId + '_1')
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.openDiscPostReply(): Open Discussion Board Post Not Successful")

    def openContentFolder(self,coursePk):
        ### Marcus
        self.info("Mobile.openContentFolder(): Requesting Bb Mobile Course Folder")

        # Opens Primary List of Content -- we skip opening the initial drill down view
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/offline/courseMapMetadata?course_id=_' + coursePk + '_1&is_mbaas=true')

        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.openContentFolder(): Open Content FolderNot Successful [1]")
        self.debug("Mobile.openContentFolder(): Section 1: " + ' '.join(self.lastPage.splitlines()))

        ###<map-item contentid="_11707_1" itemFileSize="208876" name="Document 000000006" viewurl="/webapps/blackboard/content/listContent.jsp?course_id=_496_1&amp;content_id=_6766_1&amp;fromMobile=true#_11707_1" isAvail="true" linktype="resource/x-bb-document" isfolder="false" datemodified="2012-05-19T13:18:52-0400" createdDate="2008-06-19T12:58:47-0400" new="false" unreadItems="0"/>
        self.contentItemIds = utils.parse.extractAll(self.lastPage, '<map-item contentid="_','[0-9]+?', '_1[^|]+? isAvail="true" linktype="resource/x-bb-document"', 50, False)
        self.info("Mobile.openContentFolder(): Found " + str(len(self.contentItemIds)) + " Content Item Ids" )
        
        
    def openContentItem(self,coursePk,contentItemId):

        
        self.info("Mobile.openContent(): Opening content item pk: " + contentItemId)
        # Opens Secondary Course Data -- we open the content item, e.g. a PDF, parsed from the Primary List of Content
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/contentDetail?course_id=_'+coursePk+'_1&content_id=_'+contentItemId+'_1&rich_content_level=FULL&needGroupInfo=true&needRubric=true&needGoals=true&is_mbaas=true&no_img2a_contentHandlers=resource/x-bb-document&isCheckParentUnavailability=true' )
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile.openContentItem(): Open Content Not Successful [2]")
        self.debug("Mobile.openContentItem(): Section 1: " + ' '.join(self.lastPage.splitlines()))
        #Pull out the attachment
        #<attachments><attachment id="_5168_1" name="Decoupling.1.1.PDF" uri="/courses/1/xlarge_000000001/content/_11732_1/Decoupling.1.1.PDF" action="LINK" csType="FILE" filesize="208858" linkLabel="Decoupling.1.1.PDF" fromHtmlParsing="false" modifiedDate="2008-06-19T12:58:45-0400"/></attachments>
        contentLinkURLS = utils.parse.extractAll(self.lastPage, '<attachment.+?uri="','[^"]+?', '" action="LINK" csType="FILE"', 50, False)

        for contentLinkURL in contentLinkURLS:
            self.GET(contentLinkURL)
            
         

        #Not including this get for now. Can't figure out the HASH or registration ID
        #"GET /webapps/Bb-mobile-bb_bb60/content?username=user000000001&xid=%2Fxid-254105920_1&content_id=_37928436_1&timestamp=2018-10-31T09%3A44%3A06-0400&registration_id=39885&hash=15E6CB812E15EF0BDE7B7D09FC903B9B


    def openAssignment(self,coursePk,contentPk,parentPk):
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/courseMap?course_id=_' + coursePk + '_1&is_mbaas=true&is_new=true&load_forums=true&rich_content_level=FULL&is_recursive=false&no_img2a_contentHandlers=resource/x-bb-document&parent_id=_'+parentPk+'_1')
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/contentDetail?course_id=_' + coursePk + '_1&content_id=_'+contentPk+'_1&rich_content_level=FULL&needGroupInfo=true&needRubric=true&needGoals=true&is_mbaas=true&no_img2a_contentHandlers=resource/x-bb-document&isCheckParentUnavailability=true')
        
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/content/attempts/_'+contentPk+'_1?course_id=_' + coursePk + '_1&sort_by_id=true&need_grading_schema=true&is_mbaas=true')
        
        
    def openAssignmentStart(self,coursePk):
    
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/contentDetail?course_id=_' + coursePk + '_1&content_id=_'+contentPk+'_1&rich_content_level=FULL&needGroupInfo=true&needRubric=true&needGoals=true&is_mbaas=true&no_img2a_contentHandlers=resource/x-bb-document&isCheckParentUnavailability=true')
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/assignment/start_attempt?content_id=_'+contentPk+'_1&course_id=_' + coursePk + '_1&is_mbaas=true')
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/content/attempt/_' + attemptPk + '_1?course_id=_' + coursePk + '_1&content_id=_'+contentPk+'_1&password=&is_mbaas=true')
    
    def submitAssignment(self,coursePk):
    
    


        self.POST('/webapps/Bb-mobile-bb_bb60/assignment/submit?content_id=_'+contentPk+'_1&course_id=_' + coursePk + '_1&is_mbaas=true&attempt_id=_' + attemptPk + '_1')

    def openAssessment(self,coursePk,contentId,assessmentId):
        self.info("Mobile.openAssessment(): Requesting Bb Mobile Assessment")
        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/assessment/info?course_id=_' + coursePk + '_1&content_id=_'+contentId+'_1&assessment_id=_'+assessmentId+'_1&language=en_US&v=1&ver=' + self.bbMobileVersion )
        utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile: Open Assessment Not Successful",True)
        
    def openBlogs(self, coursePk):
        ### Marcus
        self.info("Mobile.openBlogs(): Requesting Bb Mobile Course Blogs")

        if(len(self.blogURLs) > 0):
            self.GET(utils.random.randomlySelectValueFromList(self.blogURLs, True))
            #These return the whole page, so we don't check for the task unless there's an error
            #utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile: Open Blogs Not Successful",True)
            self.debug("Mobile.openBlogs(): BEGIN")
            self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
            self.debug("Mobile.openBlogs(): END")

    def openJournals(self, coursePk):
        ### Marcus
        self.info("Mobile.openJournals(): Requesting Bb Mobile Course Journals")

        if(len(self.journalURLs) > 0):
            self.GET(utils.random.randomlySelectValueFromList(self.journalURLs, True))
             #These return the whole page, so we don't check for the task unless there's an error
            #utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile: Open Journals Not Successful", True)
            self.debug("Mobile.openJournals(): BEGIN")
            self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
            self.debug("Mobile.openJournals(): END")

    def openTasks(self, coursePk):
        ### Marcus
        self.info("Mobile.openTasks(): Requesting Bb Mobile Course Tasks")

        if(len(self.taskURLs) > 0):
            self.GET(utils.random.randomlySelectValueFromList(self.taskURLs, True))
             #These return the whole page, so we don't check for the task unless there's an error
            #utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile: Open Tasks Not Successful",True)
            self.debug("Mobile.openTasks(): BEGIN")
            self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
            self.debug("Mobile.openTasks(): END")

    def openMyGrades(self, coursePk):
        ### Marcus
        self.info("Mobile.openMyGrades(): Requesting Bb Mobile Course My Grades")

        self.GET('/webapps/Bb-mobile-' + self.bblearn.vi + '/enrollments?course_type=ALL&is_mbaas=true&include_grades=true')
        self.isMobileDisabled = utils.error.checkForPatternAndFailTest(self.lastPage, 'status="OK"', "Bb Mobile: Open My Grades Not Successful")
        self.info("Mobile.openMyGrades(): BEGIN")
        #self.debug("Mobile.Section 1: " + ' '.join(self.lastPage.splitlines()))
        grades = utils.parse.extractAll(self.lastPage, 'totalPoints="', '[0-9\.]+?', '"', 50, False)
        self.info("Mobile.Section Grades: " + ' '.join(grades))
        self.info("Mobile.openMyGrades(): END")
