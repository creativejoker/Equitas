# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from HTTPClient import Codecs
from jarray import zeros
import scripts
import utils.parse
import utils.random
import utils.baconLoremIpsum
from scripts.portal import Portal



class ContentSystem(scripts.base.Base):


    def __init__(self, request, bblearn):
        scripts.base.Base.__init__(self, request)
        self.portal=Portal(request,bblearn)     
        self.userId = ""
        self.files = ""
        self.bblearn = bblearn
        self.file = ""
        self.fileUrl = ""
        self.folders = ""
        self.folderUrl = ""
        self.collectionType="institution"
    def openUserCollection(self):
        ''' Open the content collection tab -- default landing page is user collection '''
       
        self.info("ContentSystem.openUserCollection():Opening the user collection :" + self.bblearn.contentSystemTabPk)    
        self.portal.openTab(self.bblearn.contentSystemTabPk)
        #self.portal.loadTabModules()
        self.lastPage=self.portal.lastPage
    
        # Load the frameset 
        frames=utils.parse.extractAll(self.lastPage, '<frame src="', '[^"]+', '"', False)
        for f in frames:
            self.GET(f)


            
    def openCourseCollection(self):

        #If there is a course content collection URL, then we select one from the list
        if len(self.bblearn.courseContentCollectionURL)== 0:
            self.info("ContentSystem.openCourseCollection(): Content Collection tab is not found/or available")
            return True
        
        self.info("ContentSystem.openCourseCollection():Opening the course collection")
        self.courseContentCollectionUrl = utils.random.randomlySelectValueFromList(self.bblearn.courseContentCollectionURL)
        self.GET(self.courseContentCollectionUrl)

            

    def openCollection(self,collectionType="institution"):
        ''' Open the institution collection in the right-side frame '''
        #Set Collection Type, defaults to institution
        self.collectionType=collectionType
        self.info("ContentSystem.openCollection(): User \""+self.bblearn.userId+"\" is opening the \""+str.upper(self.collectionType)+"\" content collection ")
        self.GET("/webapps/cmsmain/webui/"+self.collectionType+"?action=frameset&subaction=view&numResults=25")
        #Reset the files list
        self.files =[]

        #Check to see if user has access to this collection
        #        #  <!-- Error message  -->
        #<P class="warnFont" style="color:#8b0000">Sorry! We can't access your Content Collection due to a permissions issue. Please ask your administrator for help.</P>


        if self.lastPage.count("Sorry! We can't access your Content Collection due to a permissions issue. Please ask your administrator for help")>0:
            self.info("ContentSystem.openCollection(): User \""+self.bblearn.userId+"\" does not have access to the \""+str.upper(self.collectionType)+"\" content collection ")
            return False
        else:
            return True
        
    def openFileLogic(self):
        '''Randomly open a content item on the current page
        Parameters: none'''
        
        
        if self.fileUrl != "":
            #if the file URL is already set, then we don't need to do anything
            return
        

        #<li id="openId_2ace4d4159824ddaa821664d7c3a98f2"><a href="https://connect.ubc.ca/bbcswebdav/institution/UBC_Vancouver/CTLT_PD/Getting%20Started%20%28online%29%20Spring%202013/.DS_Store" id="openId_2ace4d4159824ddaa821664d7c3a98f2"   title="Open"   target="_blank" >Open</a></li>
        #If this is the first time that we hit the page, then we'll need to go through and load stuff. Otherwise we can just use what's already in the self.files
        if len(self.files) == 0:
            
            #Extract all files on the previous page load of the institution page
            self.files=utils.parse.extractAll(self.lastPage,'<th  scope="row" class="" valign="top"><a href="','[^"]+?/bbcswebdav/'+self.collectionType+'/[^"]+?', '"', 10,False)
            if len(self.files)>0:
                self.info("ContentSystem.openFileLogic(): "+str(len(self.files))+" items found on this page: "+ ' '.join(self.files))
            #Extract all Folders from the previous page
            #<li id="openId_ed46001540f742f69d0dc3e06532f027"><a href="/webapps/cmsmain/webui/institution/Common?action=frameset&subaction=view&uniq=jix2xg&mask=/institution" id="openId_ed46001540f742f69d0dc3e06532f027"   title="Open"    >Open</a></li>
            self.folders = utils.parse.extractAll(self.lastPage,'<li id="openId_[0-9a-z]+"><a href="', '/webapps/cmsmain/webui/[^"]+?', '" id="openId_[a-z0-9]+"', 10,False)
            #self.folders=utils.parse.extractAll(self.lastPage,'<li id="openId_[0-9a-z]+"><a href="', '[^"]+', '" id="openId_[a-z0-9]+"   title="Open"    >Open</a></li>', 10, False)
            if len(self.folders)>0:
                self.info("ContentSystem.openFileLogic(): "+str(len(self.folders))+" folders found on this page")
                self.debug("ContentSystem.openFileLogic(): folders found on this page: "+ ' '.join(self.folders))
            #Set the current level of files to be the level above so that we can save it for later
            self.fileslevelup=self.files
            
            #Random percentage selector, returns true 50% of the time. 
            #if it's true, then we disregard the files that we found and move on
            #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
            if len(self.files)>0:
                if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("ContentSystem.openInstitutionFileRandomSelectionPercentage")):
                    self.info("ContentSystem.openFileLogic(): "+str(len(self.files))+" items found; however, ignoring items and trying to open a sub folder: ")
                    self.files = []
            
 
        elif len(self.files)!=0:
            self.file = utils.random.randomlySelectValueFromList(self.files)
            if self.file.count(".mov") ==0:
                self.fileUrl = self.file
                self.debug("ContentSystem.openFileLogic(): File URL is: "+ self.fileUrl)
            
        else:
            self.info("ContentSystem.open"+self.collectionType+"FileLogic(): no items found, skipping....")
    def openCSFoldersLogic(self):
        #if there is a folder, pick a random folder and open it
        if len(self.folders) != 0:
            #Pick a random folder and open it
            p = utils.random.randomlySelectValueFromList(self.folders)
            
            #Grab the folder name so we can log it
            foldername = utils.parse.extractOnce(p,'/webapps/cmsmain/webui/'+self.collectionType+'/', '[^"]+?', '\?action=', False)
            self.info("ContentSystem.openCSFoldersLogic(): no items found, trying to open sub folder: \"" + foldername +"\"")

            #set the folderURL for use later
            self.folderUrl = p
        #So if there's no items and no more sub folders to open in this folder, then we break out of the loop as there's nothing to do
        else:
           
            self.info("ContentSystem.openCSFoldersLogic(): no more folders found, skipping")
            

            
    def openCSFolderCheck(self):
            if len(self.folders) ==0 and len(self.files) == 0 and len(self.fileslevelup)!= 0:
            # if there are files in the level above, then we use that
                
                self.info("ContentSystem.openCSFolderCheck(): using resultset from previous folder")
                self.files = self.fileslevelup
                return

            #Tries to find folders and items in sub folder. If it finds something, it should break out of the while loop
            #self.files = utils.parse.extractAll(self.lastPage,'/bbcswebdav/'+self.collectionType+'/', "[^']+", "' \)\"  title=\"Open\"     >Open</a></li>", 10,False)
            self.files=utils.parse.extractAll(self.lastPage,'<th  scope="row" class="" valign="top"><a href="','[^"]+?/bbcswebdav/'+self.collectionType+'/[^"]+?', '"', 10,False)
            self.folders = utils.parse.extractAll(self.lastPage,'<li id="openId_[0-9a-z]+"><a href="', '/webapps/cmsmain/webui/[^"]+?', '" id="openId_[a-z0-9]+"', 10,False)
            self.debug("ContentSystem.openCSFolderCheck(): items found on this page: "+ ' '.join(self.files))
            self.debug("ContentSystem.openCSFolderCheck(): folders found on this page: "+ ' '.join(self.folders))
            self.info("ContentSystem.openCSFolderCheck(): "+str(len(self.files))+" files and "+str(len(self.folders))+" sub folders found on this page.")
            # if this is the first file we see, might want to keep on going. 
            if len(self.files)!= 0:
                #Set the current level of files to be the level above so that we can save it for later
                self.fileslevelup = self.files
                
                
                #Randomly decide to keep going further down or use the current file
                #if true, then we null the items and move on:
                if len(self.folders) !=0:
                    if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("ContentSystem.openFolderRandomSelectionPercentage")):
                        self.info("ContentSystem.openCSFolderCheck(): "+str(len(self.files))+" items found; however, ignoring items and trying to open a sub folder: ")
                        self.files = []
                else:
                    self.info("ContentSystem.openCSFolderCheck(): no more folders found, using current level")
                    
                    
            

    def openCSFolder(self):
        if len(self.folderUrl) !=0:
            self.GET(self.folderUrl)
        else:
            self.info("ContentSystem.openCSFolder(): Folder url is null")
    def openCSFile(self):
        if len(self.fileUrl) !=0:
            self.GET(self.fileUrl)
            #reset the file URL
            self.fileUrl = ""
        else:
            self.info("ContentSystem.openCSFile(): File url\""+self.fileUrl+"\" is null")
    def openSingleFileUploadForm(self):
        ''' Open the file upload form '''
        
        #Grab the userid or the course id from the previous page
        self.userId=utils.parse.extractOnce(self.lastPage, '/webapps/cmsmain/webui/users/','[^"]+', '\?action')
        self.courseId=utils.parse.extractOnce(self.lastPage, '/webapps/cmsmain/webui/courses/','[^"]+?', '\?action')
        
        #If it's a course id that we find, then we know that this is a course collection
        if self.courseId !="":
            self.info("ContentSystem.openSingleFileUploadForm(): Course ID: " + self.courseId+ " found, this is a course content collection, opening the upload single file form")
            uniq = utils.parse.extractOnce(self.lastPage, '&uniq=', '[^&]+', '&gobackto')
            
            #extract it here in case the bblearn.coursePk is not the same as the current course
            self.coursePk = utils.parse.extractOnce(self.courseContentCollectionUrl, "course_id=_","[0-9]+","_1")
            
            #The following URL ensures that we do a single page upload
            self.GET('/webapps/cmsmain/webui/courses/'+self.courseId+'?action=upload&subaction=print&uniq='+uniq+'&course_id=_'+self.coursePk+'_1')
            
        #If no user is found, the user's folder needs to be created by accessing the user folder
        elif self.userId  ==  '' and self.courseId  ==  "":
            
            self.info("ContentSystem.openSingleFileUploadForm(): User folder not found, creating user folder...")
            self.GET('/webapps/cmsmain/webui/users?action=frameset&subaction=view&uniq=&mask=/')
            
            #Grab the user id from the page
            self.userId=utils.parse.extractOnce(self.lastPage, '/webapps/cmsmain/webui/users/','[^"]+', '\?action')
    
        #If we have a user id then we call the hardcoded single file upload page to ensure a single page upload
        if self.userId != "":
            
            self.info("ContentSystem.openSingleFileUploadForm(): User ID: " + self.userId + " found, this is a user collection, opening the upload single file form")
            uniq = utils.parse.extractOnce(self.lastPage, '&uniq=', '[^&]+', '&gobackto')
            
            self.GET('/webapps/cmsmain/webui/users/'+self.userId+'?action=upload&subaction=print&uniq='+uniq+'&gobackto=/users/'+self.userId)
       
        
    def submitSingleFileUploadForm(self):
        
        #extract out the necessary files from the form
        form = utils.parse.extractOnce(self.lastPage,'name="fileUpload"', ".+", '<div id="dataCollectionContainer">' )
        if len(form)==0:
            self.info("ContentSystem.submitSingleFileUploadForm(): no form found on last page, nothing to submit, skipping...")
            return
            
        url = utils.parse.extractOnce(form,'action="', '[^"]+?', '"' )
        secToken = utils.parse.extractOnce(form,"name='blackboard.platform.security.NonceUtil.nonce' value='", ".+", "'" )
        targetPath = utils.parse.extractOnce(form,'id="targetPath" value="', ".+?", '"' )
        
        # Randomly selects a file to upload
        file = utils.uploadFiles.getRandomFile()
        if file==False:
            self.info("ContentSystem.submitSingleFileUploadForm(): Random file is not available, skipping file upload" )
            return
            
        self.info("ContentSystem.submitSingleFileUploadForm(): Selected file is: " +file)
        
        files = ( NVPair("newFile_LocalFile0", file), )
        
        parameters = ( 
            NVPair("overwrite", "true"), 
            NVPair("top_submit", "Submit"), 
            NVPair("view", ""),
            NVPair("updateCommentType", "updateCommentType"),
            NVPair("updateVersionsSetting", "updateVersionsSetting"),
            NVPair("updateTrackingSetting", "updateTrackingSetting"),
            NVPair("blackboard.platform.security.NonceUtil.nonce", secToken),
            NVPair("newFile_attachmentType","L"),
            NVPair("newFile_fileId","new"),
            NVPair("newFile_artifactFileId","undefined"),
            NVPair("newFile_artifactType","undefined"),
            NVPair("newFile_linkTitle",file),
            NVPair("newFilefilePickerLastInput", "dummyValue"),
            NVPair("isLightbox", "false"),
            NVPair("targetPath", targetPath)
             )
             
        #New 3400 Submit https://cuny-loadtesting2018.blackboard.com/webapps/cmsmain/webui/courses/JJC01_ENG_101_36_1169_1?action=upload&subaction=file&uniq=-fplx64&gobackto=%2Fcourses%2FJJC01_ENG_101_36_1169_1&course_id=_1319528_1
        #blackboard.platform.security.NonceUtil.nonce=31780fbb-0b89-4c70-84f3-9f5bd30b60d6
        #&targetPath=/courses/JJC01_ENG_101_36_1169_1
        #&view=
        #&isLightbox=false
        #&newFile_attachmentType=L
        #&newFile_fileId=new
        #&newFile_artifactFileId=undefined
        #&newFile_artifactType=undefined
        #&newFile_artifactTypeResourceKey=undefined
        #&newFile_linkTitle=CUNY_PROD_login.jsp
        #&updateCommentType=updateCommentType
        #&updateVersionsSetting=updateVersionsSetting
        #&updateTrackingSetting=updateTrackingSetting
        #&newFilefilePickerLastInput=dummyValue
        #&newFile_LocalFile0=CUNY_PROD_login.jsp
        
        
        self.info("ContentSystem.submitSingleFileUploadForm(): Submitting Single "+file+" Document " + url)
        
        # This is the Jython way of creating an NVPair[] Java array
        # with one element.
        headers = zeros(1, NVPair)

        # Create a multi-part form encoded byte array.
        data = Codecs.mpFormDataEncode(parameters, files, headers)

        results = self.POST(url, data, headers)
        
        self.info(results.getText())
    
        #Remove Random Temp file
        utils.uploadFiles.removeFile(file)


        
        
        #BASIC SEARCH
        
    def openBasicSearch(self):
        self.GET('/webapps/bbcms/execute/searchBasic?isPicker=false&isFolderPicker=false&isFilePicker=false&principalID=&pathstub=/webapps/cmsmain/webui')
    def openBasicSearchLogic(self):
   #Try to extract the grade form
        basicSearchForm=utils.parse.extractOnce(self.lastPage,'<form  method="post" ', ".+?", '</form>',False )
       
        #If the gradeform is empty, there's nothing to do so we should return False
        if basicSearchForm =="":
            self.info("ContentSystem.openBasicSearchLogic(): no basic search form found skipping")
            return  False
        
        #Extract the URL for the post
        self.submitBasicSearchUrl = utils.parse.extractOnce(basicSearchForm,'action="', ".+?", '"', False)
        
        #Extracts all parameters and puts them into an NVpair
        self.submitBasicSearchhParameters =utils.parse.extractNVPairsFromForm(basicSearchForm)
        


        #blackboard.platform.security.NonceUtil.nonce=abdc5bd4-6e9e-441c-884f-694a1db9d214&searchType=basic&targetPath=/users/bbsupport&searchComments=N&isPicker=false&isFolderPicker=false&isFilePicker=false&pathstub=/webapps/cmsmain/webui&pickerPrincipalID=
        #&fileoper=contains&filename=bbssddd&isUserEntitledToSearchInTLD=true&targetPath_CSFile=/users/bbsupport&targetPath_attachmentType=C&targetPath_fileId=&bottom_Submit=Submit
         

        
        #Course search type
        fileoperOptions = ['contains','equals']
        fileoperOptionsRandomlySelected = utils.random.randomlySelectValueFromList(fileoperOptions)
        utils.parse.smartUpdateNVPairs(self.submitBasicSearchhParameters,'fileoper',fileoperOptionsRandomlySelected)
        
        
        #SEARCH TEXT
        searchText = utils.baconLoremIpsum.getSearchText()
        utils.parse.smartUpdateNVPairs(self.submitBasicSearchhParameters,'filename',searchText)
        
        #Path
        targetPath = utils.parse.extractOnce(basicSearchForm,'<input type="text" name="targetPath_CSFile" id="targetPath_CSFile" size="[0-9]+"  value="', '[^"]+?', '" >',False )
        utils.parse.smartUpdateNVPairs(self.submitBasicSearchhParameters,'targetPath_CSFile',targetPath)
        utils.parse.smartUpdateNVPairs(self.submitBasicSearchhParameters,'targetPath_attachmentType',"C")
        utils.parse.smartUpdateNVPairs(self.submitBasicSearchhParameters,'targetPath_fileId',"")
        utils.parse.smartUpdateNVPairs(self.submitBasicSearchhParameters,'bottom_Submit',"Submit")
       
        self.info("ContentSystem.openBasicSearchLogic(): Operator: \"" + fileoperOptionsRandomlySelected +  "\" Search Text:\"" + searchText+"\"")
        return True
    def submitBasicSearch(self):
        self.POST(self.submitBasicSearchUrl,self.submitBasicSearchhParameters)
    def openBasicSearchFileLogic(self):
    
        if self.lastPage.count("No se han encontrado elementos que coincidan") > 0 or self.lastPage.count("No items matched the Search Criteria") > 0:
            self.info("ContentSystem.openBasicSearchFileLogic(): Nothing found on based on the search terms")
            return False
        self.files = utils.parse.extractAll(self.lastPage,'<li id="openId_[0-9a-z]+"><a href="', '/bbcswebdav[^"]+?', '" id="openId_[a-z0-9]+"', 10,False)
        if len(self.files)>0:
            self.info("ContentSystem.openBasicSearchFileLogic(): items found on this page: "+ ' '.join(self.files))
            self.fileUrl = utils.random.randomlySelectValueFromList(self.files)
            self.info("ContentSystem.openBasicSearchFileLogic(): "+str(len(self.files))+" files found on this page. Selected the following file: "+self.fileUrl)
            return True
        else:
            return False
        
