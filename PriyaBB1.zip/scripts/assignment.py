# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Support for assignments.
# NOTE: we currently only support multiple choice, all-at-once
# The test must be name as follows: 25Q-MC-AAO and stored under assignements.


from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from HTTPClient import Codecs
from jarray import zeros
import scripts
import utils.parse

 

class Assignment(scripts.base.Base):

    def __init__(self, request,  bblearn):
        scripts.base.Base.__init__(self, request)
        self.reset()
        self.bblearn = bblearn
        
        
    def reset(self):
        self.assignmentUrls=[]
        self.courseTOCMenuUrl=""
        self.assignmentAttemptUrl = ""
        self.assignmentAttemptUrls = []
        self.assignmentUrl =""
        self.submitAssignmentUrl =""
        self.submitAssignmentPostData =[]
        self.uploadFile = ""
        self.headers = ""
        self.hasAssignmentAttempts = False
        self.newAttemptUrl = ""

    def assignmentsCourseTOCExist(self):
    
        #Pulls the course table of content(TOC) link that is associated with this class
        self.courseTOCMenuUrl=scripts.course.courseTOCMenuItem(self.bblearn,"Assignments")
        
        #If the course toc exist, we open it and return true, otherwise we return false
        if self.courseTOCMenuUrl=="":
            self.info("Assignment.openAssignmentsCourseTOC(): No Assignments Table of Content Link found in course, skipping...")
            return False
        
        self.info("Assignment.openAssignmentsCourseTOC(): Opening Assignment TOC link")
        return True
        
    def openAssignmentsCourseTOC(self):
        self.GET(self.courseTOCMenuUrl)


    def openAssignmentLogic(self):
        #If self.assignmentUrls is empty, this is our first go around so we need to extract the available assignment urls from the previous page.
        #otherwise, we assume that there are no assignments available or that 
        self.assignmentUrl =""
        self.info("Assignment.openAssignment(): Opening Assignment page")
        self.assignmentUrl = utils.random.randomlySelectValueFromList(self.bblearn.assignmentUrls)
        
            
    def openAssignment(self):
        self.GET(self.assignmentUrl)
        
    def openAssignmentCheck(self):
        #Pull out previous assignment attempts
        self.assignmentAttemptUrls=utils.parse.extractAll(self.lastPage, 'href="', '[A-Z0-9a-z.\/:]+uploadAssignment\?[^"]+attempt_id[^"]+', '"',15, False) 
        self.info("Assignment.openAssignmentCheck(): Found " + str(len(self.assignmentAttemptUrls))+" assignments attempts on this page...")
        
        #Adding check for the new attempt. If there's just a single attempt there won't be the any attempts listed so we need to check for the existence of the new attempt button
        self.newAttemptUrl=utils.parse.extractOnce(self.lastPage, "document.location='","[^']+uploadAssignment\?action=newAttempt[^']+", "'", False)
        if self.newAttemptUrl !="":
            self.info("Assignment.openAssignmentCheck(): Found 1 assignments attempts on this page...")
            self.hasAssignmentAttempts = True

    def openAssignmentAttemptLogic(self):
        
        self.assignmentAttemptUrl = ""
        #if we still don't have anything than either the previous page didn't load correctly or there's no message, return
        self.info("Assignment.openAssignmentAttemptLogic(): Opening Assignment attempt page")
        self.assignmentAttemptUrl = utils.random.randomlySelectValueFromList(self.assignmentAttemptUrls)
        self.hasAssignmentAttempts = True
        
    def openAssignmentAttempt(self):
        self.GET(self.assignmentAttemptUrl)

    def openNewAssignmentAttemptLogic(self):
        #if this is on the page, we need to start a new attempt
        #<input  class="submit button-1" name="top_Start New Submission" type="submit" value="Start New Submission" onClick="document.location='/webapps/blackboard/execute/uploadAssignment?action=newAttempt&content_id=_139364_1&course_id=_1237_1&assign_group_id=&lu_link_id=';">
        #Grab the new attempt URL from the page
        self.newAttemptUrl=utils.parse.extractOnce(self.lastPage, "document.location='","[^']+uploadAssignment\?action=newAttempt[^']+", "'", False)

        #If the new attempt url exist, we call that first. 
        if self.newAttemptUrl!="":
            self.info("Assignments.openNewAssignmentAttempt(): Assignment already submitted, performing a new assignment attempt")
            return True
        else:
            return False
            
    def openNewAssignmentAttempt(self):
        self.GET(self.newAttemptUrl)
            
    def submitAssignmentLogic(self):
        self.submitAssignmentPostData = ""
        #Pulls out submission form and URL to post to 
        form=utils.parse.extractOnce(self.lastPage,'name="uploadAssignmentForm"', ".+", '</form>', False )
        if len(form)==0:
            self.info("Assignments.submitAssignmentLogic(): No submit assignment form found, skipping...")
            return False
            
        self.submitAssignmentUrl = utils.parse.extractOnce(form,'action="', ".+?", '"' , False)
        
        self.uploadFile = utils.uploadFiles.getRandomFile()
        if self.uploadFile==False:
            self.info("Assignment.submitAssignmentLogic(): Random file is not available, skipping file upload" )
            return False
            
        self.info("Assignment.submitAssignmentLogic(): Selected file is: " +self.uploadFile)
        files = ( NVPair("newFile_LocalFile0", self.uploadFile), )

        
        #Extracts all parameters and puts them into an NVpair
        parameters =utils.parse.extractNVPairsFromForm(form)
        
        #Adds additional post data that is not part of the form and handled through javascript
        parameters.append(NVPair('newFile_attachmentType', 'L'))
        parameters.append(NVPair('newFile_fileId', 'new'))
        parameters.append(NVPair('newFile_linkTitle', self.uploadFile))

        # This is the Jython way of creating an NVPair[] Java array
        # with one element.
        self.headers = zeros(1, NVPair)

        # Create a multi-part form encoded byte array.
        self.submitAssignmentPostData = Codecs.mpFormDataEncode(parameters, files, self.headers)
        return True
        
    def submitAssignment(self):
        self.info("Assignment.submitAssignment(): Submitting assignment attempt.")
        #Performs the POST
        
        # This is the Jython way of creating an NVPair[] Java array
        # with one element.

        self.POST(self.submitAssignmentUrl, self.submitAssignmentPostData, self.headers)

    def removeTempFile(self):
        #Remove Random Temp file
        utils.uploadFiles.removeFile(self.uploadFile)


    def reviewAssignment(self):
        self.info("Assignment.reviewAssignment(): Opening Assignment Review page.")
        self.GET(self.assignmentUrl)


