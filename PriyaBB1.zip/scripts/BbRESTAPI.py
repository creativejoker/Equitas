# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Support for REST APIs

from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPUtilities
from net.grinder.plugin.http import HTTPPluginControl
from net.grinder.plugin.http import HTTPRequest
from HTTPClient import NVPair
from HTTPClient import Codecs
from time import gmtime, strftime
import config.settings
import scripts
import utils.parse
import utils.logging

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = utils.logging.info
error = utils.logging.error
clientApplicationKey=config.settings.clientApplicationKey
clientSecret=config.settings.clientSecret


#get the initial bearer token for all threads/processes
def GetInitialOAuth2BearerToken():
    info("BbRESTAPI.GetInitialOAuth2BearerToken(): Posting to the /learn/api/public/v1/oauth2/token to obtain the access token ")
    data=[NVPair("grant_type","client_credentials")]
    basicAuthBase64Encoded=Codecs.base64Encode(clientApplicationKey+":"+clientSecret)
    header=[NVPair("Authorization"," Basic "+basicAuthBase64Encoded)]
    request=HTTPRequest()
    httpResponse = request.POST(config.settings.targetURL.getValue()+"/learn/api/public/v1/oauth2/token",data,header)
    info("BbRESTAPI.GetInitialOAuth2BearerToken(): Response" + httpResponse.getText())
    return utils.parse.extractOnce(httpResponse.getText(), '"access_token":"', '.+','","token_type"')

initialOAuth2BearerToken=GetInitialOAuth2BearerToken()

#https://community.blackboard.com/docs/DOC-4258-developer-groups-site-quotas-and-rate-limits

#Bb REST API services class that uses a proxy tool configured in the GUI
class BbRESTAPIService(scripts.base.Base):

    def __init__(self, request,userList,initialOAuth2BearerToken):
        scripts.base.Base.__init__(self, request)      
        self.userList = userList
        self.rateLimitReached=False
        self.authToken=initialOAuth2BearerToken
        self.reset()
        
        #Need to setup the Proxy Tools under the System Admin > Building Blocks > Proxy Tools
        #webapps/ws/wsadmin/wsclientprograms
        self.clientApplicationKey=config.settings.clientApplicationKey
        self.clientSecret=config.settings.clientSecret

        

    def reset(self):
        self.userId = self.userList.getValue()
        self.userIdParameter = "userName:"+self.userId
        self.coursePk = ""
        self.contentPk = ""
        self.contentPks = []
        

     
    def isOAuth2AccessTokenValid(self):
        self.reset()
        if self.authToken =="":
            self.info("BbRESTAPI.GetOAuth2AccessToken(): No Oauth2 Access Token Present")
            return False
        else:
            return True
    
    #Initial step to grab the OAuth2 token which gets used later on
    def GetOAuth2AccessToken(self):
    
        #Reset all of the variables
        
        
        if self.authToken =="":
            #--user $REST_API_CREDS --data "grant_type=client_credentials"  https://$ENV_URL/learn/api/public/v1/oauth2/token

            self.info("BbRESTAPI.GetOAuth2AccessToken(): Posting to the /learn/api/public/v1/oauth2/token to obtain the access token ")
            data=[NVPair("grant_type","client_credentials")]
            basicAuthBase64Encoded=Codecs.base64Encode(self.clientApplicationKey+":"+self.clientSecret)
            header=[NVPair("Authorization"," Basic "+basicAuthBase64Encoded)]

            response = self.POST("/learn/api/public/v1/oauth2/token",data,header)
            self.info("BbRESTAPI.GetOAuth2AccessToken(): Response" + response.getText())
        
        
        
            #Check response, should be a{"access_token":"ztk3YURsRT4WFBNxjzG5tsyG3tMIHwAH","token_type":"bearer","expires_in":3599}. This gets used in all subsequent request
            self.authToken = utils.parse.extractOnce(self.lastPage, '"access_token":"', '.+','","token_type"')
        if self.authToken =="":
            self.info("BbRESTAPI.GetOAuth2AccessToken(): Server did not provide a valid OAuth2 Token. Server Response: "+self.lastPage)
            return False
        else:
            return True
    
    # Tool Login, needed to authenticate the session
            
    def getAnnouncement(self):
        self.info("BbRESTAPI.getAnnouncement(): Requesting all system announcements")
        self.getRESTServices("/learn/api/public/v1/announcements")
        self.info("BbRESTAPI.getAnnouncement(): Response: "+self.lastPage)
        
    #Grab the user object
    def getUserCourseEnrollments(self):

        
        #Posting to the web service                
        self.info("BbRESTAPI.getUserCourseEnrollments(): Requesting Course Memberships for userId: "+self.userId)
        if self.getRESTServices("/learn/api/public/v1/users/"+self.userIdParameter+"/courses")==False:
            return False
        
        #Response: {"results":[{"userId":"_874028_1","courseId":"_16380818_1","dataSourceId":"_16922_1","created":"2018-02-26T23:48:14.000Z","availability":{"available":"Yes"},"courseRoleId":"Student"},{"userId":"_874028_1","courseId":"_16381025_1","dataSourceId":"_16922_1","created":"2018-02-26T23:48:55.000Z","availability":{"available":"Yes"},"courseRoleId":"Student"},{"userId":"_874028_1","courseId":"_16382491_1","dataSourceId":"_16922_1","created":"2018-02-26T23:56:06.000Z","availability":{"available":"Yes"},"courseRoleId":"Student"},{"userId":"_874028_1","courseId":"_16392216_1","dataSourceId":"_16910_1","created":"2018-02-27T21:13:33.000Z","availability":{"available":"Yes"},"courseRoleId":"Student"}],"paging":{"nextPage":"/learn/api/public/v1/users/userName:usw1.a00973568/courses?offset=4"}}
        
        #Should only pull available courses {"userId":"_39280_1","courseId":"_16333103_1","dataSourceId":"_16831_1","created":"2017-10-04T17:52:44.000Z","availability":{"available":"Yes"},
        self.coursePks=utils.parse.extractAll(self.lastPage,'"courseId":"','_[0-9]+?_1','","dataSourceId":"_[0-9]+?_1","created":"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9:.A-Z]+?","availability"\:\{"available"\:"Yes"\}')
        self.info("BbRESTAPI.getUserCourseEnrollments(): Found "+str(len(self.coursePks))+" Available Course Pks objects for User : "+self.userId+" COURSEPKS: "+" ".join(self.coursePks) )

        if len(self.coursePks)==0:
            self.info("BbRESTAPI.getUserCourseEnrollments(): User "+self.userId+" does not have any courses.")
            return False
        else:
            self.coursePk =utils.random.randomlySelectValueFromList(self.coursePks)
            self.info("BbRESTAPI.getUserCourseEnrollments(): Opening random Course Pk:" +  self.coursePk)
            return True
            

        
   
    def getGradeByUserId(self):
        #GET /learn/api/public/v1/courses/{courseId}/gradebook/columns/{columnId}/users/{userId}
        
                        
        self.info("BbRESTAPI.getGradeColumnByUserId(): Requesting Grade Column Information for userId: "+self.userId+" in course: "+ self.coursePk)
        return self.getRESTServices("/learn/api/public/v1/courses/"+self.coursePk+"/gradebook/users/"+self.userIdParameter)
        #BbRESTAPI.getRESTServices(): Response: {"results":[{"userId":"_880820_1","columnId":"_16775522_1","exempt":false},{"userId":"_880820_1","columnId":"_16775523_1","score":180.0,"exempt":false},{"userId":"_880820_1","columnId":"_16775526_1","status":"Graded","score":70.0,"exempt":false},{"userId":"_880820_1","columnId":"_16775527_1","status":"Graded","score":110.0,"exempt":false},{"userId":"_880820_1","columnId":"_16775528_1","status":"NeedsGrading","exempt":false},{"userId":"_880820_1","columnId":"_16775529_1","status":"Graded","score":0.0,"exempt":false},{"userId":"_880820_1","columnId":"_16775530_1","status":"NeedsGrading","exempt":false},{"userId":"_880820_1","columnId":"_16775533_1","status":"NeedsGrading","exempt":false},{"userId":"_880820_1","columnId":"_16775534_1","status":"NeedsGrading","exempt":false},{"userId":"_880820_1","columnId":"_16775535_1","status":"NeedsGrading","exempt":false}]}

        
    def getGradebookColumnByCourse(self):
        #GET /learn/api/public/v1/courses/{courseId}/gradebook/columns
        
        self.info("BbRESTAPI.getGradebookColumnByCourse(): Requesting Grade Column Information for course: "+ self.coursePk)

        return self.getRESTServices("/learn/api/public/v1/courses/"+self.coursePk+"/gradebook/columns")
        
        #BbRESTAPI.getRESTServices(): Response: {"results":[{"id":"_15603447_1","name":"Discussion - Week 1","created":"2016-10-14T14:00:41.000Z","score":{"possible":100.0},"availability":{"available":"Yes"},"grading":{"type":"Attempts","due":"2017-10-13T05:59:00.000Z","attemptsAllowed":0,"scoringModel":"Last","anonymousGrading":{"type":"None"}}},{"id":"_15603448_1","name":"Assignment - Week 1","created":"2016-10-13T20:11:53.000Z","score":{"possible":25.0},"availability":{"available":"Yes"},"grading":{"type":"Attempts","due":"2017-10-16T05:59:00.000Z","attemptsAllowed":0,"scoringModel":"Last","anonymousGrading":{"type":"None"}}},{"id":"_15603449_1","name":"Assignment 1 - Week 2","created":"2016-10-14T13:26:09.000Z","score":{"possible":25.0},"availability":{"available":"Yes"},"grading":{"type":"Attempts","due":"2017-10-20T05:59:00.000Z","attemptsAllowed":0,"scoringModel":"Last","anonymousGrading":{"type":"None"}}},{"id":"_15603450_1","name":"Assignment 2 - Week 2","contentId":"_43632937_1","score":{"possible":125.0},"availability":{"available":"Yes"},"grading":{"type":"Attempts","due":"2017-10-23T05:59:00.000Z","attemptsAllowed":1,"scoringModel":"Last","anonymousGrading":{"type":"None"}}},{"id":"_15603451_1","name":"Assignment - Week 
    def getGradebookColumnByCourseLogic(self):

        self.gradebookColumnPks=utils.parse.extractAll(self.lastPage,'"id":"','_[0-9]+?_1','","name"')
        self.info("BbRESTAPI.getGradebookColumnByCourseLogic(): Found "+str(len(self.gradebookColumnPks))+" gradebook columns for : "+self.coursePk)

        if len(self.gradebookColumnPks)==0:
            self.info("BbRESTAPI.getGradebookColumnByCourseLogic(): Course "+self.coursePk+" does not have any gradebook columns.")
            return False
        else:
            self.gradebookColumnPk =utils.random.randomlySelectValueFromList(self.gradebookColumnPks)
            self.info("BbRESTAPI.getGradebookColumnByCourseLogic(): retrieving random gradebook column:" +  self.gradebookColumnPk)
            return True
    def getGradebookColumnAttemptsByCourseAndColumnId(self,gradebookColumnPk):
        #GET /learn/api/public/v1/courses/{courseId}/gradebook/columns
        
        self.info("BbRESTAPI.getGradebookColumnAttemptsByCourseAndColumnId(): Requesting Grade Column Attempt Information for course: "+ self.coursePk+" and gradebook column pk: " + gradebookColumnPk)

        return self.getRESTServices("/learn/api/public/v1/courses/"+self.coursePk+"/gradebook/columns/"+gradebookColumnPk+"/attempts",True)
        
    #def getCourseContentByCourse(self):
    #    #GET /learn/api/public/v1/courses/{courseId}/contents
    #    
    #    self.info("BbRESTAPI.getGradebookColumnByCourse(): Requesting Grade Column Information for course: "+ self.coursePk)
    #
    #    return self.getRESTServices("/learn/api/public/v1/courses/"+self.coursePk+"/contents")
    #    
    #    #07/13/18 12:20:10 PM  fgprd-bbperf-app002-0 thread-0 [ run-0, test-5 ]: BbRESTAPI.getRESTServices(): Response: {"results":[{"id":"_46129894_1","title":"Course Information","created":"2018-04-10T22:17:46.000Z","position":1,"hasChildren":true,"availability":{"available":"Yes","allowGuests":true,"adaptiveRelease":{}},"contentHandler":{"id":"resource/x-bb-folder"}},{"id":"_46129891_1","title":"Course Documents","created":"2018-04-10T22:17:46.000Z","position":2,"hasChildren":true,"availability":{"available":"Yes","allowGuests":true,"adaptiveRelease":{}},"contentHandler":{"id":"resource/x-bb-folder"}},{"id":"_46129890_1","title":"Assessments","created":"2018-04-10T22:17:46.000Z","position":8,"hasChildren":true,"availability":{"available":"Yes","allowGuests":false,"adaptiveRelease":{}},"contentHandler":{"id":"resource/x-bb-folder"}},{"id":"_46129893_1","title":"Assignments","created":"2018-04-10T22:17:46.000Z","position":9,"hasChildren":true,"availability":{"available":"Yes","allowGuests":false,"adaptiveRelease":{}},"contentHandler":{"id":"resource/x-bb-folder"}},{"id":"_46129892_1","title":"Web Links","created":"2018-04-10T22:17:46.000Z","position":12,"hasChildren":true,"availability":{"available":"Yes","allowGuests":false,"adaptiveRelease":{}},"contentHandler":{"id":"resource/x-bb-folder"}}]}
    #
    #    
    ##def getCourseContentByCourseLogic(self):
    ##    self.coursePks=utils.parse.extractAll(self.lastPage,'"id":"','_[0-9]+?_1','","title":"Course Information","created":"2018-04-10T22:17:46.000Z","position":1,"hasChildren":true,"availability":{"available":"Yes","allowGuests":true,"adaptiveRelease":{}},"contentHandler":{"id":"resource/x-bb-folder"}}')
    #def getCourseContentByCourseAndContentId(self):
    #    #GET /learn/api/public/v1/courses/{courseId}/contents
    #    
    #    self.info("BbRESTAPI.getGradebookColumnByCourse(): Requesting Grade Column Information for course: "+ self.coursePk)
    #
    #    return self.getRESTServices("/learn/api/public/v1/courses/"+self.coursePk+"/contents")
    #This is where we call the post for the webservices    
    def postRESTServices(self,uri,body,logging=False):
        
        
        if self.authToken=="":
            self.info("BbRESTAPI.postRESTServices(): Oauth2 Bearer token is empty")
            return False
            
        authorizationBearerHeader = [NVPair("Authorization", " Bearer "+self.authToken)]
        #Performs the POST
        response = self.POST(uri, body, authorizationBearerHeader)
        if logging:
            self.info("BbRESTAPI.postRESTServices(): Response: "+response.getText())
        return self.checkRESTAPIResponse(response)
    
    def getRESTServices(self,uri,logging=False):
         if self.authToken=="":
            self.info("BbRESTAPI.getRESTServices(): Oauth2 Bearer token is empty")
            return False
            
         authorizationBearerHeader = [NVPair("Authorization", " Bearer "+self.authToken)]
         response = self.GET(uri,authorizationBearerHeader)
         if logging:
            self.info("BbRESTAPI.getRESTServices(): Response: "+response.getText())
         return self.checkRESTAPIResponse(response)
         
    def checkRESTAPIResponse(self,response):
        
        #{"status":401,"message":"Bearer token is invalid"}
        #Bearer token is invalid, need to get a new token
        responseText=response.getText()
        
        if response.getStatusCode()==401 and responseText.find("Bearer token is invalid")>0:
            self.authToken=""
            self.info("BbRESTAPI.checkRESTAPIResponse(): Oauth2 Bearer token is invalid")
            self.GetOAuth2AccessToken()
        if response.getStatusCode()==429 and int(response.getHeader("X-Rate-Limit-Remaining"))==0:
            self.info("BbRESTAPI.checkRESTAPIResponse(): RATE LIMIT OF "+str(response.getHeader("X-Rate-Limit-Limit"))+" EXCEEDED. REMAINING:"+str(response.getHeader("X-Rate-Limit-Remaining")))
            self.rateLimitReached = True
            return False
        if response.getStatusCode()==200 and int(response.getHeader("X-Rate-Limit-Remaining"))>=0:
            self.info("BbRESTAPI.checkRESTAPIResponse(): RATE LIMIT "+ str(response.getHeader("X-Rate-Limit-Remaining"))+" of "+str(response.getHeader("X-Rate-Limit-Limit")))
            self.rateLimitReached = False
            return True
            
       