# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Support for webservices

from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from time import gmtime, strftime
import config.settings
import scripts
import utils.parse

#Bb Soap Web services class that uses a proxy tool configured in the GUI
class BbSoapWebServices(scripts.base.Base):

    def __init__(self, request):
        scripts.base.Base.__init__(self, request)      
        self.usernameParam = config.settings.username
        self.reset()
        

    def reset(self):
        self.sessionId = "nosession"
        self.userPk = ""
        self.userBatchUID = self.usernameParam.getValue()
        self.userPassword = config.settings.password.getValue()
        self.coursePk = ""
        self.contentPk = ""
        self.contentPks = []
        
        #Need to setup the Proxy Tools under the System Admin > Building Blocks > Proxy Tools
        #webapps/ws/wsadmin/wsclientprograms
        self.clientVendorId = "<PLEASE UPDATE>"
        self.clientProgramId = "<PLEASE UPDATE>"
        self.toolPassword = "<PLEASE UPDATE>"
        
    #Initial step to grab the session Id which gets used later on
    def initialize(self):
    
        #Reset all of the variables
        self.reset()
        
        #Build the soap body
        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://context.ws.blackboard">
                        <ns1:initialize></ns1:initialize>'''
        
        #Make the WS call to initialize the Context
        self.info("BbSoapWebServices.initialize(): Posting to the Context.initialize() WS")
        response = self.postWebServices("/webapps/ws/services/Context.WS",soapBody,"initialize")
        
        #Check response, should be a sessionId <ns:return>bca875811e024c5e99c4b3c532003931</ns:return>. This gets used in all subsequent request
        self.sessionId = utils.parse.extractOnce(self.lastPage, '<ns:return>', '[a-z0-9]{32}','</ns:return>')
        if self.sessionId =="nosession" or self.sessionId =="":
            self.info("BbSoapWebServices.initialize(): Server did not return valid sessionId. Server Response: "+self.lastPage)
            return False
        else:
            return True
    
    # Tool Login, needed to authenticate the session
    def loginTool(self):

        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://context.ws.blackboard">
                        <ns1:loginTool>
                            <ns1:password>'''+self.toolPassword+'''</ns1:password>
                            <ns1:clientVendorId>'''+self.clientVendorId+'''</ns1:clientVendorId>
                            <ns1:clientProgramId>'''+self.clientProgramId+'''</ns1:clientProgramId>
                            <ns1:loginExtraInfo></ns1:loginExtraInfo>
                            <ns1:expectedLifeSeconds>3600</ns1:expectedLifeSeconds>
                        </ns1:loginTool>'''
        
        #Posting to the web service                
        self.info("BbSoapWebServices.loginTool(): Posting to the Context.loginTool() WS")
        self.postWebServices("/webapps/ws/services/Context.WS",soapBody,"loginTool")
        
        #Check the response, ensure the response back is "<ns:return>true</ns:return>"
        if self.lastPage.count("<ns:return>true</ns:return>") ==0:
            self.info("BbSoapWebServices.loginTool(): Tool Login Failed Not Successful. Server Response:" + self.lastPage)
            return False
        else:
            return True
            
    #Extended the life of the session
    def extendSessionLife(self):
        
        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://context.ws.blackboard">
                        <ns1:extendSessionLife>
                            <ns1:additionalSeconds>3600</ns1:additionalSeconds>
                        </ns1:extendSessionLife>'''
        
        #Posting to the web service
        self.info("BbSoapWebServices.extendSession(): Posting to the Context.extendSessionLife() WS")
        self.postWebServices("/webapps/ws/services/Context.WS",soapBody,"extendSessionLife")
    
    #Grab the user object
    def getUser(self):
        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://user.ws.blackboard">
                        <ns1:getUser>
                            <ns1:filter xmlns:ns2="http://user.ws.blackboard/xsd">
                                <ns2:filterType>3</ns2:filterType>
                                <ns2:batchId>'''+self.userBatchUID+'''</ns2:batchId>
                            </ns1:filter>
                        </ns1:getUser>'''
        
        #Posting to the web service                
        self.info("BbSoapWebServices.getUser(): Requesting UserVO for userId: "+self.userBatchUID)
        self.info("BbSoapWebServices.getUser(): Posting to the User.getUser() WS")
        self.postWebServices("/webapps/ws/services/User.WS",soapBody,"getUser")
        
        #Grab the user pk from the user object
        self.userPk=utils.parse.extractOnce(self.lastPage, '<ax[0-9]+?:id>', '_[0-9]+?_1','</ax[0-9]+?:id>')
        if self.userPk =="":
            self.info("BbSoapWebServices.getUser(): User PK lookup for batchUID: "+self.userBatchUID+" failed. Server Response:" + self.lastPage)
            return False
        else:
            return True
            
    #Grab the user's course memberships
    def getMemberships(self):
    
        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://context.ws.blackboard">
                        <ns1:getMemberships>
                            <ns1:userid>'''+self.userBatchUID+'''</ns1:userid>
                        </ns1:getMemberships>'''
        
        #Posting to the web service
        self.info("BbSoapWebServices.getMemberships(): Posting to the Context.getMemberships() WS")
        self.postWebServices("/webapps/ws/services/Context.WS",soapBody,"getMemberships")
        
        #Grab the course pk's from the response
        self.coursePks = utils.parse.extractAll(self.lastPage, '<ax[0-9]+?:externalId>', '_[0-9]+?_1','</ax[0-9]+?:externalId>')
        if len(self.coursePks) ==0:
            self.info("BbSoapWebServices.getMemberships(): User is not enrolled in any courses. Server Response:" + self.lastPage)
            return False
        else:
            #Randomly select a course pk1
            self.coursePk = utils.random.randomlySelectValueFromList(self.coursePks)
            self.info("BbSoapWebServices.getMemberships(): User is enrolled in "+str(len(self.coursePks))+" courses. Randomly selected coursePk: "+self.coursePk)
            return True
            
    #Load the course object
    def getCourse(self):
        
        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://course.ws.blackboard">
                        <ns1:getCourse>
                            <ns1:filter xmlns:ns2="http://course.ws.blackboard/xsd">
                                <ns2:filterType>3</ns2:filterType>
                                <ns2:ids>'''+self.coursePk+'''</ns2:ids>
                            </ns1:filter>
                        </ns1:getCourse>'''
        
        #Posting to the web service
        self.info("BbSoapWebServices.getCourse(): Posting to the Course.getCourse() WS")
        self.postWebServices("/webapps/ws/services/Course.WS",soapBody,"getCourse")
        
    #Load the course announcements
    def getCourseAnnouncements(self):
        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://announcement.ws.blackboard">
                        <ns1:getCourseAnnouncements>
                            <ns1:coursePk>'''+self.coursePk+'''</ns1:coursePk>
                            <ns1:filter xmlns:ns2="http://announcement.ws.blackboard/xsd">
                                <ns2:filterType>2</ns2:filterType>
                                <ns2:coursePk>'''+self.coursePk+'''</ns2:coursePk>
                            </ns1:filter>
                        </ns1:getCourseAnnouncements>'''
        
        #Posting to the web service
        self.info("BbSoapWebServices.getCourseAnnouncements(): Posting to the Announcement.getCourseAnnouncements() WS")
        self.postWebServices("/webapps/ws/services/Announcement.WS",soapBody,"getCourseAnnouncements")
    
    #This method returns the content from the course top level and then allows you to drill down further based on the content pk
    def getFilteredContent(self,contentPk=""):
    
        #If the contentPk is not empty, then this is a subsequent call for a folder
        if contentPk !="":
            soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://content.ws.blackboard">
                            <ns1:getFilteredContent>
                                <ns1:coursePk>'''+self.coursePk+'''</ns1:coursePk>
                                <ns1:filter xmlns:ns2="http://content.ws.blackboard/xsd">
                                    <ns2:filterType>9</ns2:filterType>
                                    <ns2:contentId>'''+contentPk+'''</ns2:contentId>
                                    <ns2:userId>'''+self.userPk+'''</ns2:userId>
                                </ns1:filter>
                            </ns1:getFilteredContent>'''
                            
        #Otherwise, this is a top level call for the table of contents  
        else:
            soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://content.ws.blackboard">
                            <ns1:getFilteredContent>
                                <ns1:coursePk>'''+self.coursePk+'''</ns1:coursePk>
                                <ns1:filter xmlns:ns2="http://content.ws.blackboard/xsd">
                                    <ns2:filterType>7</ns2:filterType>
                                    <ns2:userId>'''+self.userPk+'''</ns2:userId>
                                </ns1:filter>
                            </ns1:getFilteredContent>'''
        
        #Posting to the web service
        self.info("BbSoapWebServices.getFilteredContent(): Posting to the Content.getFilteredContent() WS")
        self.postWebServices("/webapps/ws/services/Content.WS",soapBody,"getFilteredContent")
        
        #Extracting out the content pk's and checking to see if there are available content pks in the folder
        self.contentPksOneLevelUp = self.contentPks
        self.contentPks = utils.parse.extractAll(self.lastPage, '<ax[0-9]+?:id>', '_[0-9]+?_1','</ax[0-9]+?:id>')
        if len(self.contentPks) ==0:
            self.info("BbSoapWebServices.getFilteredContent(): No content items found")
            
            #If no content pks are found and there were content pk's in the level above, then we use those as the content pks
            if len(self.contentPksOneLevelUp)>0:
                self.info("BbSoapWebServices.getFilteredContent(): Setting the content items to the previous level found")
                self.contentPks = self.contentPksOneLevelUp
            return False
        else:
            self.contentPk = utils.random.randomlySelectValueFromList(self.contentPks)
            self.info("BbSoapWebServices.getFilteredContent(): User has "+str(len(self.contentPks))+" content items.")
            return True
            
    #This method actually load a specific content item 
    def getContentFiles(self):
    
        #Randomly select a content item from the lsit
        self.contentPk = utils.random.randomlySelectValueFromList(self.contentPks)
        self.info("BbSoapWebServices.getContentFiles(): Randomly selected contentPk: "+self.contentPk)
        
        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://content.ws.blackboard">
                        <ns1:getContentFiles>
                            <ns1:coursePk>'''+self.coursePk+'''</ns1:coursePk>
                            <ns1:contentId>'''+self.contentPk+'''</ns1:contentId>
                        </ns1:getContentFiles>'''
                        
        #Posting to the web service            
        self.info("BbSoapWebServices.getContentFiles(): Posting to the Content.getContentFiles() WS")
        self.postWebServices("/webapps/ws/services/Content.WS",soapBody,"getContentFiles")
        
        #Check the files name that are found
        fileName = utils.parse.extractOnce(self.lastPage, '<ax[0-9]+?:linkName>', '[^"]+?','</ax[0-9]+?:linkName>')
        if(fileName !=""):
            self.info("BbSoapWebServices.getContentFiles(): "+fileName+" file found")
        else:
            self.info("BbSoapWebServices.getContentFiles(): no file found" +self.lastPage)
    
    #Loads all of the gradbook columns
    def getGradebookColumns(self):
    
        #Create the soap body
        soapBody = '''<SOAP-ENV:Body xmlns:ns1="http://gradebook.ws.blackboard">
                        <ns1:getGradebookColumns>
                            <ns1:coursePk>'''+self.coursePk+'''</ns1:coursePk>
                            <ns1:filter xmlns:ns2="http://gradebook.ws.blackboard/xsd">
                                <ns2:filterType>1</ns2:filterType>
                                <ns2:coursePk>'''+self.coursePk+'''</ns2:coursePk>
                            </ns1:filter>
                        </ns1:getGradebookColumns>'''
        
        #Posting to the web service
        self.info("BbSoapWebServices.getGradebookColumns(): Posting to the Gradebook.getGradebookColumns() WS")
        self.postWebServices("/webapps/ws/services/Gradebook.WS",soapBody,"getGradebookColumns")
        
        #Check the response
        self.gradebookPks = utils.parse.extractAll(self.lastPage, '<ax[0-9]+?:id>', '_[0-9]+?_1','</ax[0-9]+?:id>')
        if len(self.gradebookPks) ==0:
            self.info("BbSoapWebServices.getGradebookColumns(): No gradebook column items found")
            return False
        else:
            self.info("BbSoapWebServices.getGradebookColumns(): User has "+str(len(self.gradebookPks))+" gradebook column items.")
            return True
    
    #Helper Method, this method creates the WS Security Header and timestamp
    #It needs the session id from the context.initialize(). However for the first load, it just uses "nosession"
    def getWSSecurityHeader(self):
        timestamp = strftime("%Y-%m-%dT%H:%M:%SZ", gmtime())
        soapEnvelopeAndHeader = '''<SOAP-ENV:Envelope xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">
                                        <SOAP-ENV:Header>
                                            <wsse:Security SOAP-ENV:mustunderstand=\"true\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">
                                                <wsse:Timestamp xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">
                                                    <wsse:Created xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">'''+timestamp+'''</wsse:Created>
                                                </wsse:Timestamp>
                                                <wsse:UsernameToken xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">
                                                    <wsse:Username xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">session</wsse:Username>
                                                    <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">'''+self.sessionId+'''</wsse:Password>
                                                </wsse:UsernameToken>
                                            </wsse:Security>
                                        </SOAP-ENV:Header>'''
        
        return soapEnvelopeAndHeader
        
    #This is where we call the post for the webservices    
    def postWebServices(self,uri,soapBody,action):
        
        #creates the whole soap envelop by grabbing the WS Security header, adding the soap body and then closing body and envelope end tags
        soapEnvelope = self.getWSSecurityHeader()+ soapBody +"</SOAP-ENV:Body></SOAP-ENV:Envelope>"
        
        #Ensure the header type is "text/xml" and the SOAPAction is set
        headers=[NVPair("Content-Type", "text/xml"),NVPair("SOAPAction", '"'+action+'"')]
        
        #Performs the POST
        response = self.POST(uri, soapEnvelope, headers)
        return response