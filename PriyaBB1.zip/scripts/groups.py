# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Support for groups


from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPPluginControl
import config.settings
import scripts
import utils.parse
from utils.parameters import ListParameter
 

class Groups(scripts.base.Base):

	def __init__(self, request, course,bblearn):
		scripts.base.Base.__init__(self, request)
		# This points to the current course object
		self.course=course
		self.groupPk=-1
		self.courseMemId=-1
#		self.wikiTitle="Wiki Page by Automated user"
#		self.wikiContent="This is the content of a wiki page added by Automated user."


	def openGroups(self):
		# Assumption: Already navigated to a course.
		# self.course.courseMenuTool('blogs')
		self.GET('/webapps/blackboard/execute/groupContentList?course_id=_508_1&action=list')
		if self.courseMemId==-1:
                	self.courseMemId=utils.parse.extractOnce(self.lastPage, 'course_id%3D_[0-9]+_1&courseMembershipId=_', '[0-9]+', '_1')
		HTTPPluginControl.getConnectionDefaults().setFollowRedirects(1)
		self.GET('/webapps/portal/frameset.jsp?tab_tab_group_id=_2_1&url=%2Fwebapps%2Fblackboard%2Fexecute%2Flauncher%3Ftype%3DCourse%26id%3D_508_1%26url%3D')
		self.GET('/webapps/blackboard/content/launchLink.jsp?course_id=_508_1&tool_id=_123_1&tool_type=TOOL&mode=view&mode=reset&courseTocLabel=Groups')
		HTTPPluginControl.getConnectionDefaults().setFollowRedirects(0)
		self.GET('/webapps/blackboard/execute/groupSetSignUp?course_id=_508_1&group_id=_3725_1&backUrl=%2Fexecute%2FgroupContentList%3Faction%3Dlist%26course_id%3D_508_1&courseMembershipId=_'+self.courseMemId+'_1')
		return self.lastPage


	def openGroupPage(self, pk=-1):
		
		self.GET('/webapps/blackboard/execute/groupSetSignUp?course_id=_508_1&group_id=_3725_1&backUrl=%2Fexecute%2FgroupContentList%3Faction%3Dlist%26course_id%3D_508_1&courseMembershipId=_'+self.courseMemId+'_1')

		if pk==-1:
			pks=utils.parse.extractAll(self.lastPage, 'course_id=_[0-9]+_1&group_id=_', '[0-9]+', '_1')
			
			if len(pks)>0:
				messageChooser=ListParameter('pk', 'each', 'random', pks)
				pk=messageChooser.getValue()
				self.groupPk=pk
				
			else:
				self.info("Groups: no groups available") 
		else:
			self.groupPk=pk
		
		#self.GET('/webapps/Bb-wiki-BBLEARN/wikiView?course_id=_'+self.course.coursePk+'_1&wiki_id=_'+self.wikiPk+'_1')

	def subscribeGroup(self):

		HTTPPluginControl.getConnectionDefaults().setFollowRedirects(1)
		self.GET('/webapps/blackboard/execute/groupSetSignUp?action=signUp&course_id=_508_1&group_id=_'+self.groupPk+'_1&courseMembershipId=_'+self.courseMemId+'_1&backUrl=%2Fexecute%2FgroupContentList%3Faction%3Dlist%26course_id%3D_508_1')
		HTTPPluginControl.getConnectionDefaults().setFollowRedirects(0)
		return self.lastPage
