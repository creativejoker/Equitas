# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Support for assessments.
# NOTE: we currently only support multiple choice, all-at-once
# The test must be name as follows: 25Q-MC-AAO and stored under assignements.


from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPPluginControl
from HTTPClient import NVPair
import scripts
import utils.parse
import utils.rampup
import utils.error
import utils.baconLoremIpsum
from utils.parameters import ListParameter
 

class Assessment(scripts.base.Base):

    def __init__(self, request, bblearn):
        scripts.base.Base.__init__(self, request)

        self.bblearn = bblearn
        self.reset()
        
    def reset(self):
        self.astPk=-1
        self.parameters=[]
        self.testPresentationOption=""
        self.assessmentUrls=[]
        self.numOfQuestions=""
        self.currentQuestionNum=""
        #Save the original AAO page load to use it later on
        self.orginalAAOPageLoad = ""
        self.courseTOCMenuUrl = ""
        self.assessmentUrl = ""
        self.assessmentLaunchUrl = ""
        self.isNewAttempt = False
        self.isPasswordProtected = False
        self.result = ""
        self.isSubmit = False
    def astCourseTOCExist(self):
        #Pulls the course table of content(TOC) link that is associated with this class
        self.courseTOCMenuUrl=scripts.course.courseTOCMenuItem(self.bblearn,"Assessments")
        
        #If the course toc exist, we open it and return true, otherwise we return false
        if self.courseTOCMenuUrl == "":
            return False
        else:
            return True
###################################################################################################
# Function to Open the assessment table of contents within a course
# Assumption: user has already navigated to a course. 
# self.testPresentationOption: Takes a string of either "QBQ" or "AAO" for One at a Time or All at Once test.  By default, it goes to AAO. 
###################################################################################################            

    def openAssessmentCourseTOC(self):

           
        self.GET(self.courseTOCMenuUrl)
        
    def openAssessmentCourseTOCCheck(self):
        #If we're in legacy mode, we need to extract the values here
        if self.bblearn.courseTOCModeIsLegacy:
            self.bblearn.extractAssessmentUrls(self.lastPage)

###################################################################################################
# Function to Open a Multiple Choice/Fill in the Blank, or Essay assessment based on Test Presentation Type(i.e. All at Once(AAO) or One at a Time(QBQ))
# Searches for any assessment with the assessment title in the following format [0-9]+Q-MC-QBQ or [0-9]+Q-MC-AAO
# self.testPresentationOption: Takes a string of either "QBQ" or "AAO" for One at a Time or All at Once test.  By default, it goes to AAO. 
# testQuestionType: Supports Multiple Choice(MC), Fill in the Blank(FIB), and Essay(ESS) question types when QBQ test presentation is used.Defaults to Multiple Choice. Only Multiple Choice is supported for AAO test presentation currently.
###################################################################################################            


    def openAssessmentLogic(self):
        #Resets the parameters each time we open a test
        self.reset()

        # Initial Open Assessment, same for QBQ or AAO

        self.assessmentUrl = utils.random.randomlySelectValueFromList(self.bblearn.assessmentUrls)
    def openAssessment(self):
        self.GET(self.assessmentUrl)

    def launchAssessmentLogic(self):
        
        #Extract the assessment launch URL
        self.assessmentLaunchUrl = utils.parse.extractOnce(self.lastPage, "'", '/webapps/assessment/take/launch.jsp[^"]+?',"'", False)
        
        # Locate course assessment ID
        self.astPk = utils.parse.extractOnce(self.assessmentLaunchUrl, "course_assessment_id=_","[0-9]+",'_1', False)
        self.asmtContentPk = utils.parse.extractOnce(self.assessmentLaunchUrl, "content_id=_", "[0-9]+", "_1", False)
        
        #setting this manually in case the bblearn.coursePk changes during the thread
        self.coursePk = utils.parse.extractOnce(self.assessmentLaunchUrl, "course_id=_", "[0-9]+", "_1")
    
    def launchAssessment(self):
        # Click Initial Begin Assessment    
        self.GET(self.assessmentLaunchUrl)
        
    def launchAssessmentCheck(self):
        # Check to see if this assessment has to be taken again
        self.takeAgain=utils.parse.extractOnce(self.lastPage, 'new_attempt=', '[0-9]', '&', False)
        self.info("Assessment.launchAssessmentCheck(): takeAgain=" + self.takeAgain)
        if self.takeAgain=='1':
            self.info("Assessment.launchAssessmentCheck(): Taking again...")
            self.isNewAttempt = True
        
        # Check to see if password protected
        if self.lastPage.find("Enter Password:")>0:
            self.info("Assessment.launchAssessmentCheck(): Submitting with password...")
            self.isPasswordProtected = True
            
    def launchAssessmentNewAttempt(self):
        self.GET('/webapps/assessment/take/launch.jsp?course_assessment_id=_'+self.astPk+'_1&course_id=_'+self.coursePk+'_1&new_attempt=1&content_id=_'+self.asmtContentPk+'_1&step=')

    def launchAssessmentWithPassword(self,password ="1a1dc91c907325c69271ddf0c944bc72"):
        # Note: starting with 7.0, the password ("pass") is MD5-encoded.
        #Default password is "pass"
        self.GET('/webapps/assessment/take/launch.jsp?course_assessment_id=_'+self.astPk+'_1&course_id=_'+self.coursePk+'_1&new_attempt=true&content_id=_'+self.asmtContentPk+'_1&isPasswordAttempted=true&password='+password+'&step=')
            
    def launchAssessmentExtract(self):
        #Extract the list of questions. For each question, we're going to save the question. 
        self.questionId=utils.parse.extractAll(self.lastPage,'Check_Answer[^.]+name:"','[a-z0-9_-]+', '"}',10,False)
        
        #For QBQ, we only need the current question Id. Also we grab the number of questions for use later
        ##This method of finding the number of questions only works if A. client is using English as a language pack and B. if backtracking is turned off
        self.numOfQuestions=utils.parse.extractOnce(self.lastPage,"title=\"Last Question\" onclick=\"navigate\('question_num_","[0-9_]+?", "'\);", False)

        
        #If we can't find the number of questions that way, let's try this way which should account for spanish and english
        #Quick hack to get the language pack and use the according regex, ideally we should just externalize this
        #<span>Pregunta <strong>1</strong> de <strong>60</strong></span>
        if self.numOfQuestions == "" and self.lastPage.count('lang="es-ES')>0:
            self.numOfQuestions=utils.parse.extractOnce(self.lastPage,'<span>Pregunta <strong>[0-9]+?</strong> de <strong>','[0-9]+?', '</strong></span>', True)
        if self.numOfQuestions == "" and self.lastPage.count('lang="en-US')>0:
            self.numOfQuestions=utils.parse.extractOnce(self.lastPage,'<span>Question <strong>[0-9]+?</strong> of <strong>','[0-9]+?', '</strong></span>', True)
            
            
        self.currentQuestionNum = utils.parse.extractOnce(self.lastPage, 'name="current_question" id="current_question" value="', '[0-9]+?', '"', False)
        

        #To handle if you start the test on the last question
        if self.numOfQuestions=="":
            self.numOfQuestions=self.currentQuestionNum
            

        #If there are more than one question, then it's an ALL at Once test
        if len(self.questionId) > 1:
            self.testPresentationOption="AAO"
            self.info("Assessment.launchAssessment(): This is an All at Once(AAO) type test")
            #Count should always be 1 when we first load the test
            self.currentQuestionNum=1
            
        elif len(self.questionId) == 1:
            self.testPresentationOption="QBQ"
            self.info("Assessment.launchAssessment(): This is an Question by Question(QBQ) type test")
        
        #Save the original page for later user
        self.orginalAAOPageLoad = self.lastPage

###################################################################################################
#Simple helper function to return the total number of assessment questions
#self.testPresentationOption: Takes a string of either "QBQ" or "AAO" for One at a Time or All at Once test.  By default, it goes to AAO. 
###################################################################################################            

    def getTotalNumberofQuestions(self):

        if self.testPresentationOption=="AAO":
            self.currentQuestionNum=len(self.questionId)
            self.currentQuestionNumIndex=self.currentQuestionNum-1
            return self.currentQuestionNum
            
        elif self.testPresentationOption=="QBQ":
            self.currentQuestionNum=len(self.numOfQuestions)
            self.currentQuestionNumIndex=self.currentQuestionNum-1
            return int(self.numOfQuestions)
            
###################################################################################################            
#Simple helper function to return the current question number. 
#To be used in the action/assessment.py to determine where to start the count for iterating through the questions
#self.testPresentationOption: Takes a string of either "QBQ" or "AAO" for One at a Time or All at Once test.  By default, it goes to AAO. 
#This is for QBQ for a test that has already been started. 
#For AAO, we don't really care so we just start at 1. 
###################################################################################################            
    
    def getCurrentQuestionNumber(self):
        if self.testPresentationOption=="AAO":
            #assumption is that the current question will be 1
            return self.currentQuestionNum

        elif self.testPresentationOption=="QBQ":
            #Find the current question number
            return int(self.currentQuestionNum)
            
###################################################################################################
# Dumb Function to save a question in a Multiple Choice assessment based on Test Presentation Type(i.e. All at Once(AAO) or One at a Time(QBQ))
# The position of which question to save is controlled in action/assessment.py
# self.testPresentationOption: Takes a string of either "QBQ" or "AAO" for One at a Time or All at Once test.  By default, it goes to AAO. 
###################################################################################################            
   
    def saveAssessmentLogic(self,count):
        
        #Checks the count, makes sure that it's an integer then sets it to be the current question number
        if ( isinstance(count,int) is True):
            self.currentQuestionNum=count
            self.currentQuestionNumIndex=count-1
        else:
            self.info("Assessment.saveAssessmentLogic():Count is not a valid integer")
            return False
            
        # for AAO only need to load the data on the first go around, since we should be able to use the same NVpairs for the later save post
        if(not self.parameters and self.testPresentationOption=="AAO" ):
            #Extract the parameters from the page and if we don't find anything just return
            if self.extractFormParameterDataFromLastPage() == False:
                self.info("Assessment.saveAssessmentLogic(): no assessment data found on previous page or question type does not exist, skipping save...")
                return False
        
        #AAO SAVE LOGIC
        if(self.testPresentationOption=="AAO" ):
            
            #Check for the various question types and upate the answer for the current question accordingly
            if(self.checkIfQuestionTypeExist(self.currentQuestionNumIndex)):
                
                self.info("Assessment.saveAssessmentLogic():Saving "+self.testPresentationOption+" Question # "+str(self.currentQuestionNum)+" with pk "+ self.questionId[self.currentQuestionNumIndex])
                return True
            
            else:
                self.info("Assessment.saveAssessmentLogic(): Test Type "+ self.questionId[self.currentQuestionNumIndex]+" does not exist, can not save")
                return False
        
        
        #QBQ SAVE LOGIC
        #For QBQ, we load the current data based on the previous page each save.
        elif self.testPresentationOption=="QBQ":
        
            #find if there is a next question, make this locale friendly
            #self.nextQuestionNum = utils.parse.extractOnce(self.lastPage, "title=\"Next Question\" onclick=\"navigate\('question_num_", "[0-9]+", "'\);")     
            if self.lastPage.count('lang="es-ES')>0:
            
                self.nextQuestionNum = utils.parse.extractOnce(self.lastPage, "title=\"Siguiente pregunta\" onclick=\"navigate\('question_num_", "[0-9]+", "'\);", False)
            if  self.lastPage.count('lang="en-US')>0:
                self.nextQuestionNum = utils.parse.extractOnce(self.lastPage, "title=\"Next Question\" onclick=\"navigate\('question_num_", "[0-9]+", "'\);")  
            
            
            #If there is a next question, we save the current question. 
            #Otherwise we are on the last question and should just move to the submit instead. 
            if self.nextQuestionNum !="":
                
                #Need to load the data on each page load for QBQ
                #Extract the parameters from the page and if we don't find anything just return
                if self.extractFormParameterDataFromLastPage() == False:
                    self.info("Assessment.saveAssessmentLogic(): no assessment data found on previous page or question type does not exist, skipping save...")
                    #If the question doesn't exist, we still want to advance forward otherwise it gets stuck on one question. 
                    return True
            
                #Save the question, save sequence is always one since it's the first save of the page
                self.info("Assessment.saveAssessmentLogic():Saving "+self.testPresentationOption+"  Question # "+self.currentQuestionNum+" of "+self.numOfQuestions)
                return True

            else:
                self.info("Assessment.saveAssessmentLogic():No next question found on page, skipping...")
                return False
    def saveAssessment(self):
        
        if  self.testPresentationOption=="AAO":
            self.POST(self.postUrl, self.parameters)
            #First we check for response UNANSWERED,121. 
            #If we find this response, it means we opened the assessment at the same time as another grinder thread
            #and that the other grinder thread "won" and submitted the assessment before this thread. 
            #Not a problem with the application, just that grinder is not thread safe for this use case
            if self.lastPage.count("UNANSWERED")>0:
                self.info("Assessment.saveAssessment(): Assessment Save Successful. However, the test was already submitted by another concurrent grinder thread. Live long and prosper...")
            
            #If we don't find that, check that the results that come back look like this, logs the original message if there's an error
            #COMPLETED,0cd6a603-bfaf-4dc4-93aa-dafe0cc88cc4,166
            else:
                utils.error.checkForPatternAndFailTest(self.lastPage,"COMPLETED","Assessment.saveAssessment(): Assessment Save Attempt Not Successful",True)
        elif self.testPresentationOption=="QBQ":
            self.POST(self.postUrl+'?saveSequence=1&takePageId='+self.takePageId, self.parameters)
        
            #Load the Next question
            self.GET('/webapps/assessment/take/take.jsp?course_assessment_id=_'+self.astPk+'_1&course_id=_'+self.coursePk+'_1&content_id=_'+self.asmtContentPk+'_1&question_num_'+self.nextQuestionNum+'.x=0&toggle_state=qShow&step=null')
            
    
###################################################################################################
# Function to submit a Multiple Choice assessment based on Test Presentation Type(i.e. All at Once(AAO) or One at a Time(QBQ))
# self.testPresentationOption: Takes a string of either "QBQ" or "AAO" for One at a Time or All at Once test.  By default, it goes to AAO. 
# 

    def submitAssessmentLogic(self,count):
        #Checks the count, makes sure that it's an integer then sets it to be the current question number
        if ( isinstance(count,int) is True):
            self.currentQuestionNum=count
            self.currentQuestionNumIndex=count-1
        else:
            self.info("Assessment.submitAssessmentLogic(): Count is not a valid integer")
            return False
            
        #AAO SUBMIT LOGIC
        #For AAO, No need to add all of the previous data as we already have it in the list. Just change the method and submit to true
        if self.testPresentationOption=="AAO":
            
            #In case the self.parameters hasn't been loaded yet, load the data from the previous page. 
            if not self.parameters:
                #Extract the parameters from the page and if we don't find anything just return
                if self.extractFormParameterDataFromLastPage(True) == False:
                    self.info("Assessment.submitAssessment(): no assessment data found on previous page, skipping submissions...")
                    return False
            
            #Update the save method to submit the test
            utils.parse.smartUpdateNVPairs(self.parameters,"save_and_submit",'true')
            utils.parse.smartUpdateNVPairs(self.parameters,"method",'notajax')

            self.info("Assessment.submitAssessment():Submitting "+self.testPresentationOption+" Test: Question # "+str(self.currentQuestionNum)+" with pk "+ self.questionId[self.currentQuestionNumIndex])

            return True
            
        
        #QBQ SUBMIT LOGIC
        elif self.testPresentationOption=="QBQ":
            
            #Need to load the data each time for QBQ
            if self.extractFormParameterDataFromLastPage(True) == False:
                self.info("Assessment.submitAssessment(): no assessment data found on previous page, skipping submissions...")
                return  False
            #Update the save method to submit the test
            utils.parse.smartUpdateNVPairs(self.parameters,"save_and_submit",'true')
            
            self.info("Assessment.submitAssessment():Submitting "+self.testPresentationOption+" Test: QuestionQuestion # "+self.currentQuestionNum+" of "+self.numOfQuestions)
            

            return True

    def submitAssessment(self):
        if self.testPresentationOption=="AAO":
            self.result=self.POST(self.postUrl, self.parameters)
        elif self.testPresentationOption=="QBQ":
            self.result=self.POST(self.postUrl+'?saveSequence=1&takePageId='+self.takePageId, self.parameters)
            
    def submitAssessmentCheck(self):
        #Perform the redirect after the submission of the page
        if ( self.result.getStatusCode() == 302 and str(self.result.toString()).count("assessment/take/submitted.jsp") >= 0 ):
            return True
        else:
            return False

    def openAssessmentSubmitted(self):
        redirectUrl = '/webapps/assessment/take/submitted.jsp?course_assessment_id=_'+self.astPk+'_1&course_id=_'+self.coursePk+'_1&content_id=_'+self.asmtContentPk+'_1&step=null'
        self.info("Assessment.submitAssessment(): redirectUrl = " + redirectUrl)
        self.GET(redirectUrl)
###################################################################################################
# Function to look for the review.jsp page after the submission to determine if the test was successful. 
# If not found, the test will fail. If found, the page is loaded
###################################################################################################            

    def reviewAssessment(self):

        #this transaction will fail if the submission failed.
        grinder.statistics.delayReports = 1
        
        #Find the receipt and print that out
        #<div id="bbNG.receiptTag.content" tabindex="0">Test saved and submitted.<br><br><strong>Student:</strong>  first000000001  last000000001<br><strong>Test:</strong> 10Q-FIBP-AAO<br><strong>Course:</strong> Medium Course 000000001 (medium_1)<br><strong>Started:</strong> 2/23/15 1:32 PM <br><strong>Submitted:</strong> 2/23/15 1:32 PM <br><strong>Time Used:</strong> 0 minute <br><br>Click <strong>OK</strong> to review results.</div><p><span class="receiptDate">Monday, February 23, 2015 1:32:26 PM EST</span></p>
        receipt=utils.parse.extractOnce(self.lastPage,'<div id="bbNG.receiptTag.content" tabindex="0"','[^|]+','</span></p>', False)
        multipleAttempt=utils.parse.extractOnce(self.lastPage,'<div class="multipleAttempt">','.+?','<p> </p>', False)
        
        #If the test was already taken, we might just have two concurrent grinder threads with the same user and submitting the same test at the same
        #Just log, no need to fail the test
        if len(multipleAttempt)>0:
            grinder.logger.error("Assessment.reviewAssessment(): This Test was already submitted by a different concurrent grinder thread.")
            grinder.logger.error("Assessment.reviewAssessment(): Test receipt:" + multipleAttempt)
            return
            
        #Otherwise check for the review page and error out if not found.

        #Find review page link, if not found error out the test
        utils.error.checkForPatternAndFailTest(self.lastPage,"/webapps/assessment/review/review.jsp","Assessment.reviewAssessment(): Assessment submission failed, review page not found",True)
        
        #If there are the review page is found, then we look for the receipt and print that out 
        reviewUrl=utils.parse.extractOnce(self.lastPage,'href="','[A-Z0-9a-z.\/:]+/assessment/review/review.jsp[^"]+?','"', False)
        self.info("Assessment.reviewAssessment(): Test receipt:" + receipt)
        
        #If we get all the way here, then load the review page
        self.GET(reviewUrl)
            
###################################################################################################
# Helper Function to extract the form parameter data from the last page based on Test Presentation Type(i.e. All at Once(AAO) or One at a Time(QBQ))
# self.testPresentationOption: Takes a string of either "QBQ" or "AAO" for One at a Time or All at Once test.  By default, it goes to AAO. 
# For a AAO test, this data will only be loaded once
# For a QBQ test, this data will be loaded each save
# Assumes that the self.lastPage rendered a successful page by loading the assessment page
# Supports Multiple Choice(MC), Fill in the Blank(FIB), and Essay question types when QBQ test presentation is used. Only Multiple Choice is supported for AAO test presentation currently.
###################################################################################################            

    def extractFormParameterDataFromLastPage(self,isSubmission = False):
        
        #GLOBAL Data
        #Pulls out submission form
        self.form=utils.parse.extractOnce(self.lastPage,'name="saveAttemptForm"', ".+", '</form>' , False)
        #Pulls the URL from the form
        self.postUrl= utils.parse.extractOnce(self.form, 'action="','[^"]+','"', False)
        
        #Extracts all parameters and puts them into an NVpair
        self.parameters =utils.parse.extractNVPairsFromForm(self.form)
        
        #Extract the Page ID
        self.takePageId=utils.parse.extractOnce(self.lastPage, 'assessment.takePageId = ', '[0-9]+', ';', False)
       
        #check to ensure that we have a form, if not return false so that the test can skip this question
        if self.form =="":
            self.info("Assessment.extractFormParameterDataFromLastPage(): No form found, returning False")
            return False
            
        #AAO EXTRACT LOGIC
        if self.testPresentationOption=="AAO":
        
            #Adds additional post data that is not part of the form and handled through javascript
            #Uses a smart add/update to update the values in the list of self.parameters
            utils.parse.smartUpdateNVPairs(self.parameters,'top_Save All Answers', 'Save All Answers')
            utils.parse.smartUpdateNVPairs(self.parameters,'top_Save and Submit', 'Save and Submit')
            utils.parse.smartUpdateNVPairs(self.parameters,'bottom_Save All Answers', 'Save All Answers')
            utils.parse.smartUpdateNVPairs(self.parameters,'saveonequestion', 'true')
            utils.parse.smartUpdateNVPairs(self.parameters,"method",'saveQuestion')

            #if this is a submission, we don't really care if the question type exist or not, we just want to return true
            if isSubmission:
            #    # we should still check the test type in case the last question is a question that we can answer, but we don't care if the question type doesn't exist
                self.checkIfQuestionTypeExist(self.currentQuestionNumIndex)
                return True
            
            else:
                #Check for the various question types and upate the questions accordingly
                return self.checkIfQuestionTypeExist(self.currentQuestionNumIndex)

            
        #QBQ EXTRACT LOGIC
        elif self.testPresentationOption=="QBQ":
        
            #Grab the current question number and the current questionID. These are unique to QBQ since we need to know what question number we're currently on
            self.currentQuestionNum = utils.parse.extractOnce(self.lastPage, 'name="current_question" id="current_question" value="', '[0-9]+', '"', False)
         
            #Find all Multiple Course or  Fill in the Blank Questions Ids
            #Check_Answer({ref_label:"2",name:"fitb-ans-_35733528_1"}));
            self.questionId=utils.parse.extractAll(self.lastPage,'Check_Answer[^.]+name:"','[a-z0-9_-]+', '"}',10, False)

            #Uses a smart add/update to update the values for the self.parameters
            if self.nextQuestionNum !="":
                utils.parse.smartUpdateNVPairs(self.parameters,'navigationTarget', 'question_num_' + self.nextQuestionNum)
            else:
                utils.parse.smartUpdateNVPairs(self.parameters,'navigationTarget', '')
            utils.parse.smartUpdateNVPairs(self.parameters,'current_question', self.currentQuestionNum)
            utils.parse.smartUpdateNVPairs(self.parameters,'method', 'notajax')
       
            if len(self.questionId) >0:
                #if this is a submission, we don't really care if the question type exist or not, we just want to return true
                if isSubmission:
                    # we should still check the test type in case the last question is a question that we can answer, but we don't care if the question type doesn't exist
                    self.checkIfQuestionTypeExist(0)
                    return True
                else:
                    #Check for the various question types and upate the questions accordingly
                    return self.checkIfQuestionTypeExist(0)
                
            else:
                self.info("Assessment.extractFormParameterDataFromLastPage(): No questions ids found, returning False")
                #If we don't find anything we return False so that the test keeps going
                return False
    
    #Helper method to see if the question matches the question types that we support
    def checkIfQuestionTypeExist(self,questionIdIndex):
    
        
        exist = False
        #Check for the various question types and upate the questions accordingly
        #if we get a hit, then we return true
        if(self.checkIfQuestionTypeMC(questionIdIndex)):
            exist = True
        elif(self.checkIfQuestionTypeMultipleAnswer(questionIdIndex)):
            exist = True
        elif(self.checkIfQuestionTypeEssay(questionIdIndex)):
            exist = True
        elif(self.checkIfQuestionTypeFillInTheBlank(questionIdIndex)):
            exist = True
        elif(self.checkIfQuestionTypeTrueFalse(questionIdIndex)):
            exist = True
        elif(self.checkIfQuestionTypeFillInTheBlankPlusVariable(questionIdIndex)):
            exist = True
        elif(self.checkIfQuestionTypeJumbledSentence(questionIdIndex)):
            exist = True
        elif(self.checkIfQuestionTypeCalculatedNumeric(questionIdIndex)):
            exist = True
        if exist == False:
            self.info("Assessment.checkIfQuestionTypeExist(): Question #"+str(questionIdIndex)+" of type " +self.questionId[questionIdIndex]+ " DOES NOT EXIST, skipping...")
            #utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], "")
            #exist = True
        return exist
        
    def checkIfQuestionTypeEssay(self,questionIdIndex):
    
        #Check to see if this is an Essay Test, if so update the parameters with the ESSAY Answer
        #textboxPrefix=utils.parse.extractOnce(self.lastPage,'id=\'textbox_prefix\' value="','[^"]+', '"/>')
 
        #QuestionId will be in the following format = essay-ans-_2391_1text, so we can just search for "essay" to figure out if it's an essay.
        #ESSAY ANSWERS(ESS)
        if self.questionId[questionIdIndex].count("essay-ans")>0:
            self.info("Assessment.checkIfQuestionTypeEssay(): ESSAY Question, saving a essay answer")
            
            # For ESS blank, there's no way for us to know what the possible answers are so we just use some random string
            #utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], "<p>This Grinder User does not agree with the question</p>")
            utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], "<p>"+utils.baconLoremIpsum.getBaconParagraph()+"</p>")
            return True
        else:
            return False
            
    def checkIfQuestionTypeMC(self,questionIdIndex):            


        #Multiple Choice Answers(MC)
        #Check to see if the current question is a multiple choice question, if so we update it. 
        if self.questionId[questionIdIndex].count("mc-ans-")>0:
            
            #First time around we load the answers into a variable. 
            #Check to see if there are radio button answers available, if so this is a Multiple Choice Test
            #Check the original page to get the questions
            if self.testPresentationOption=="AAO":
                numberOfMCAnswers=utils.parse.extractAll(self.orginalAAOPageLoad,'type="radio" value="','[0-9]+', '" name="'+self.questionId[questionIdIndex]+'"',10, False)        
            if self.testPresentationOption=="QBQ":
                numberOfMCAnswers=utils.parse.extractAll(self.lastPage,'type="radio" value="','[0-9]+', '" name="'+self.questionId[questionIdIndex]+'"',10, False)        
            if len(numberOfMCAnswers) >0:
                #Randomly select an answer from the available answers, used for later during the saves
    
                self.info("Assessment.checkIfQuestionTypeMC(): MULTIPLE CHOICE Question, saving a MC answer")
    
                # The question ID will always be the first position in the list
                utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], utils.random.randomlySelectValueFromList(numberOfMCAnswers))  
                
                return True
        else:
            return False
    def checkIfQuestionTypeMultipleAnswer(self,questionIdIndex):            


        #Multiple Choice Answers(MC)
        #Check to see if the current question is a multiple choice question, if so we update it. 
        if self.questionId[questionIdIndex].count("ma-ans-")>0:
            
            #First time around we load the answers into a variable. 
            #Check to see if there are radio button answers available, if so this is a Multiple Choice Test
            #Check the original page to get the questions
            if self.testPresentationOption=="AAO":
                numberOfMCAnswers=utils.parse.extractAll(self.orginalAAOPageLoad,'type="checkbox" value="','[0-9]+', '" name="'+self.questionId[questionIdIndex]+'"', 10,False)        
            if self.testPresentationOption=="QBQ":
                numberOfMCAnswers=utils.parse.extractAll(self.lastPage,'type="checkbox" value="','[0-9]+', '" name="'+self.questionId[questionIdIndex]+'"',10, False)        
            if len(numberOfMCAnswers) >0:
                #Randomly select an answer from the available answers, used for later during the saves
    
                self.info("Assessment.checkIfQuestionTypeMultipleAnswer(): MULTIPLE ANSWER Question, saving a MA answer")
    
                # The question ID will always be the first position in the list
                utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], utils.random.randomlySelectValueFromList(numberOfMCAnswers))  
                
                return True
        else:
            return False    
    def checkIfQuestionTypeFillInTheBlank(self,questionIdIndex):
        #QuestionId will be in the following format = fitb-ans-_244236316_1", so we can just search for "fitb-ans" to figure out if it's an fill in the blank.
        #Fill in the Blank(fitb)
        if self.questionId[questionIdIndex].count("fitb-ans")>0:
            self.info("Assessment.checkIfQuestionTypeFillInTheBlank(): FILL IN THE BLANK Question, saving a FIB answer")
            # For Fill in the blank, there's no way for us to know what the possible answers are so we just use some random string
            #utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], "This is a Grinder FIB answer")
            utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], utils.baconLoremIpsum.getBaconParagraph())
            return True
        else:
            return False
    def checkIfQuestionTypeFillInTheBlankPlusVariable(self,questionIdIndex):
        #QuestionId will be in the following format = fib_plus-variable-b-id_74850304_1, so we can just search for "fitb-ans" to figure out if it's an fill in the blank.
        #Fill in the Blank(fitb)
        if self.questionId[questionIdIndex].count("fib_plus-variable")>0:
            self.info("Assessment.checkIfQuestionTypeFillInTheBlankPlusVariable(): FILL IN THE BLANK PLUS VARIABLE Question, saving a FIB PLUS VARIABLE answer")
            # For Fill in the blank, there's no way for us to know what the possible answers are so we just use some random string
            #utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], "This is a Grinder FIB answer")
            utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], utils.baconLoremIpsum.getBaconTitle())
            return True
        else:
            return False
    def checkIfQuestionTypeTrueFalse(self,questionIdIndex):
        #QuestionId will be in the following format = tf-ans-_73306725_1_1", so we can just search for "tf-ans" to figure out if its true or false
        #True/False
        if self.questionId[questionIdIndex].count("tf-ans")>0:
            self.info("Assessment.checkIfQuestionTypeTrueFalse(): TRUE/FALSE Question, saving a TF answer")
            # For TF, we always select true
            utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], "true")
            return True
        else:
            return False
    def checkIfQuestionTypeCalculatedNumeric(self,questionIdIndex):
        #QuestionId will be in the following format = num-ans-_75775583_1", so we can just search for "num-ans-" to figure out if its true or false
        #True/False
        if self.questionId[questionIdIndex].count("num-ans-")>0 or self.questionId[questionIdIndex].count("calc-ans-")>0:
            self.info("Assessment.checkIfQuestionTypeCalculatedNumeric(): Calculated Numberic Question, saving a CN answer")
            # For TF, we always select true
            utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex], str(utils.random.randomlySelectInt()))
            return True
        else:
            return False
    def checkIfQuestionTypeJumbledSentence(self,questionIdIndex):
        #QuestionId will be in the following format = jumbled_sentence-ans-a-_52125912_1", so we can just search for "jumbled_sentence-ans" to figure out if it's an fill in the blank.
        #Fill in the Blank(fitb)
        if self.questionId[questionIdIndex].count("jumbled_sentence-ans")>0:
            self.info("Assessment.checkIfQuestionTypeJumbledSentence(): JUMBLED SENTENCE Question, saving a JUMBLED SENTENCE answer")
            # For Fill in the blank, there's no way for us to know what the possible answers are so we just use some random string
            if self.testPresentationOption=="AAO":
                numberOfJSAnswers=utils.parse.extractAll(self.orginalAAOPageLoad,'name="'+self.questionId[questionIdIndex]+'"','.+?', '</select>',10, False)        
            if self.testPresentationOption=="QBQ":
                numberOfJSAnswers=utils.parse.extractAll(self.lastPage,'name="'+self.questionId[questionIdIndex]+'"','.+?', '</select>', 10, False)
            
            self.info("Assessment.checkIfQuestionTypeMC(): Found "+str(len(numberOfJSAnswers))+ " jumbled sentence questions. ")
            if len(numberOfJSAnswers) >0:
                #Randomly select an answer from the available answers, used for later during the saves
                JSAnswers=utils.parse.extractAll(numberOfJSAnswers[0],'value="','[a-z0-9]+?', '">', 10, False)
                self.info("Assessment.checkIfQuestionTypeMC(): Found "+str(len(JSAnswers))+ " jumbled sentence answers. ")
                if len(JSAnswers)>0:
                    # The question ID will always be the first position in the list
                    utils.parse.smartUpdateNVPairs(self.parameters,self.questionId[questionIdIndex],utils.random.randomlySelectValueFromList(JSAnswers))
                
                    return True
                else:
                    return False
        else:
            return False