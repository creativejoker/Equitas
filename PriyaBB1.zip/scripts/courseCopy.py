# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.plugin.http import HTTPRequest
from net.grinder.plugin.http import HTTPPluginControl
from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
from HTTPClient import Codecs
from jarray import zeros
import scripts
import utils.parse
import utils.random
import config.settings
from utils.parameters import ListParameter
from utils.parameters import RangeParameter

class InstructorCourseCopy(scripts.base.Base):

    def __init__(self, request,bblearn):
        scripts.base.Base.__init__(self, request)

        self.bblearn=bblearn

        self.coursePk = ""



    def isInstructorEnrolledInCourse(self):
        #Check to make sure that we're enrolled in a course before proceeding
        if len(self.bblearn.coursePk)==0:
            self.info("InstructorCourseCopy.isInstructorEnrolledInCourse(): User is not an instructor in any classes, skipping course copy...")
            return False
        
        self.coursePk = self.bblearn.coursePk
        return True
        
    def openCoursePackagesAndUtilities(self):
        #We assume that all instructors have access to this page
        self.GET('/webapps/blackboard/landingPage.jsp?navItem=cp_package_utillities&course_id=_'+self.coursePk+'_1&filterForCourse=true')

    def isCourseCopyAvailable(self):
    
        #self.info(self.lastPage)
        # href="/webapps/blackboard/execute/cp_copy_content?navItem=cp_copy_course&course_id=_1646615_1&target=no"
        self.courseCopyEntryUrl = utils.parse.extractOnce(self.lastPage,'href="','/webapps/blackboard/execute/cp_copy_content\?navItem=cp_copy_course[^"]+?','"', False)
        if self.courseCopyEntryUrl !="":
            return True
        else:
            self.info("InstructorCourseCopy.isCourseCopyAvailable(): Course Copy is not available for this user")
            return False
    
    def openCourseCopy(self):
        self.GET('/webapps/blackboard/execute/cp_copy_content?navItem=cp_copy_course&course_id=_'+self.coursePk+'_1&target=no')
        
    def selectCourseCopy(self):
        #<input type="hidden" name="sourceCourseId" value="xlarge_000000020" />
        self.sourceCourseId=utils.parse.extractOnce(self.lastPage,'name="sourceCourseId" id="sourceCourseId" value="','[^"]+','"', False)
        
        #<form  id="selectCourse" name="selectCourse" action="/webapps/blackboard/execute/cp_copy_content?action=cp_copy_course&target=yes&course_id=_684897_1" method="post" onsubmit="return course_copy.submitPage()">
        #<input type='hidden' name='blackboard.platform.security.NonceUtil.nonce' value='1ca075f5-581b-4a4a-a23c-1c839d8202aa'>
        submitCopyForm=utils.parse.extractOnce(self.lastPage,'<form  method="post" name="selectCourse"', ".+", '</form>', False)
        self.nonce=utils.parse.extractOnce(submitCopyForm,"name='blackboard.platform.security.NonceUtil.nonce' value='","[^']+", "'", False)
        self.courseTocParameters=utils.parse.extractAll(self.lastPage,"formCheckList\.addElement\( new RadioCheckBox\( \{ name:'","[^']+","'", 30, False)
        if len(self.courseTocParameters)==0:
            self.info("InstructorCourseCopy.selectCourseCopy(): Select Course Copy: no table of content menu items to copy")
        self.GET('/webapps/blackboard/taglib/cp_search_course_popup.jsp?useDomains=true&courseType=course&user_id=&search_input=&text_field=window.opener.document.selectCourse.destinationCourseId')
        pks=utils.parse.extractAll(self.lastPage,'type="radio" name="ckbox" value="','[^"]+','" id="listContainer', 30, False)
        
        if len(pks)==0:
            self.info("InstructorCourseCopy.selectCourseCopy(): no courses to copy")
            return  False# Don't bother
        chooser=ListParameter('param', 'each', 'random', pks)
        self.info("InstructorCourseCopy.selectCourseCopy():There are " + str(len(pks)) + " courses to copy")
        self.destinationCourseId=''
        
        #If there is only 1 course, then it's the source course and should not be copied
        if(len(pks)>1):
            self.destinationCourseId=chooser.getValue()
        else:
            self.info("InstructorCourseCopy.selectCourseCopy(): Only one course, the source Course ID cannot match the destination Course ID , skipping...")
            return False
        #Ensure that the chooser doesn't pick the source course from the list of available courses
        while(self.destinationCourseId==self.sourceCourseId):
            self.destinationCourseId=chooser.getValue()
            
            if(self.destinationCourseId==''):
                self.info("InstructorCourseCopy.selectCourseCopy(): There are no courses to copy, skipping...")
                return False
        return True
    def submitCourseCopy(self):	
        
            
        if(self.destinationCourseId==self.sourceCourseId or self.destinationCourseId==''):
            self.info("InstructorCourseCopy.submitCourseCopy():There are no courses to copy, skipping...")
            return
        
        data = [
            NVPair('blackboard.platform.security.NonceUtil.nonce',self.nonce),
            NVPair('copyType','O'),
            NVPair('destinationCourseId',self.destinationCourseId),
            NVPair('importCSItems','true'),
            NVPair('importECSItems','true'),
            NVPair('bottom_Submit','Submit'),
            NVPair('sourceCourseId',self.sourceCourseId),
        ]
        
        for parameter in self.courseTocParameters:
            # Always select the first answer
            data.append(NVPair(parameter, 'on'))
        
            
        self.POST('/webapps/blackboard/execute/cp_copy_content?action=cp_copy_course&target=yes&course_id=_'+self.coursePk+'_1',data)
        
        
        errors=utils.parse.extractOnce(self.lastPage,'<span tabindex="-1" id="badMsg1">','[^"]+','</span>', False)
   
        if errors!='':
            grinder.statistics.forCurrentTest.setSuccess(0)
            self.error("InstructorCourseCopy.submitCourseCopy():Course Copy submission failed: "+errors)
        else:
            self.info("InstructorCourseCopy.submitCourseCopy(): Course Copy Successful: Copied " +self.sourceCourseId + " to "+self.destinationCourseId)
