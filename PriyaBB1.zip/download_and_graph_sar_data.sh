#!/bin/bash
#Based on a lot from http://aionica.computerlink.ro/2011/02/visualize-sar-reports-with-awk-and-gnuplot/




COMMMONCONF="common_autoq.sh"

#Include common environment
if [ -f "$COMMMONCONF" ]; then
  source $COMMMONCONF
else
  echo "Before running $0, please ensure you have created and configured ${COMMMONCONF}' using the '${COMMMONCONF}.example' template provided."
  exit 1
fi

SARGRAPHOFFTIMEZONEOFFSET=`cat $CLIENTINFO | mawk 'BEGIN { FS="\t" } { if ($1 == "SARGRAPHOFFTIMEZONEOFFSET") { print $2 }}'`

DATETIMETESTSTART="$1"
REPORTDIR="$2"
SARDIR="sar"
REPORTDIR=$REPORTDIR/$SARDIR
#Tried to get the timezone for the target server to be passed from the client.info file. However, had a hard time getting the timezone to line up properly. For now, just using a hack of how many hours ago from the main bbperf server. 
#Need to flip the +/- for the date command
#echo "BEFORE: $DATETIMETESTSTART"
#if [[ $TIMEZONEOFFSET == "-"* ]]; then
#    TIMEZONEOFFSET=${TIMEZONEOFFSET/-/+}
#elif [[ $TIMEZONEOFFSET == "+"* ]]; then
#    TIMEZONEOFFSET=${TIMEZONEOFFSET/-/+}
#fi 

#echo -e "TZ=\"UTC$TIMEZONEOFFSET\" date -d \"$DATETIMETESTSTART 5 minutes ago\" +\"%Y%m%d %H:%M\""
#Convert the date to the timezone of the application/database server
#date --date='TZ="UTC+3" 2016-08-22 10:37:44' "+%Y-%m-%d %H:%M:%S"
#DATETIMETESTSTART=$( date --date="TZ=\"UTC\" $DATETIMETESTSTART 5 minutes ago" +%Y%m%d\ %H:%M)
#DATETIMETESTEND=$( date --date="TZ=\"UTC$UTCTIMEZONEOFFSET\" now" +%Y%m%d\ %H:%M)


if [ ! -d "$REPORTDIR" ]; then
    mkdir -p "$REPORTDIR"
fi 

DATETIMETESTSTART=$(date -d "$DATETIMETESTSTART $SARGRAPHOFFTIMEZONEOFFSET" +"%Y%m%d %H:%M")
DATETIMETESTEND=$(date -d "now $SARGRAPHOFFTIMEZONEOFFSET" +"%Y%m%d %H:%M")

#Remove any previous sar data from the location
rm -frv $REPORTDIR/sar_*


#Download the SAR data for the database server
retrieve_sar_data  "$DATETIMETESTSTART" "$DATETIMETESTEND" "$SERVERS_DB" "$REPORTDIR" "DB"

#Graph the SAR data for the database server
gnuplotSARData "$REPORTDIR"  "DB"

#Download the SAR Data from the load generator servers
REMOTE_AGENT_SERVERS=$REMOTE_AGENT_SERVERS" "`hostname -f`
echo $REMOTE_AGENT_SERVERS
for SERVER in $REMOTE_AGENT_SERVERS;
    do
        retrieve_sar_data  "$DATETIMETESTSTART" "$DATETIMETESTEND" "$SERVER" "$REPORTDIR" "LG"
    done

#Graph the SAR data for the app server
gnuplotSARData "$REPORTDIR" "LG"



#Gather SAR data for all app servers
#SERVERS="fgtemp-100211-cr708756-app001.mhint fgtemp-100211-cr708756-app001.mhint"
for SERVER in $SERVERS;
    do
        retrieve_sar_data  "$DATETIMETESTSTART" "$DATETIMETESTEND" "$SERVER" "$REPORTDIR" "APP"
    done

#Graph the SAR data for the app server
gnuplotSARData "$REPORTDIR" "APP"

#gzip the sar data files
find  $REPORTDIR/sar_*_gnuplot | parallel --gnu  --eta --verbose --progress  gzip