#!/bin/bash

#
# Edited by marcus.uy@blackboard.com
#

source common_autoq.sh $*

#Get jobs
JOBS="$(find $CONF_QUEUE -maxdepth 1 -type f | sort)"

for JOB in $JOBS
do
  parse_config $JOB

	echo "Job::$JOB::$CONFSTATUS"

  if [ "$CONFSTATUS" == "OK" ]
  then
    #Formula: ramp up = (duration / student threads) => (1800000 ms / 90 threads) = 20000
    RAMPUP=$(echo "scale=0; $DURATION_MS / $THREADS_STUDENT" | bc)

    echo "Current Setting:     $GRINDER_RAMPUP"
    echo "Recommended Setting: Rampup(1,$RAMPUP) <-- For gradual ramp up"
    echo ""
  fi
done

exit 0
