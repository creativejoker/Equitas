#!/bin/bash

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
#
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#########################################################################
# Edited by marcus.uy@blackboard.com

# Edit the following path to ensure cron jobs function as expected
#version 1.0 - Initial Draft
#version 2.0 - Added Support for multiple load generator servers - DCHOW
##################################################################
#cd /home/bbperf/performance/mainline
#export PATH=/usr/local/bin:$PATH
##################################################################

COMMMONCONF="common_autoq.sh"

#Include common environment
if [ -f "$COMMMONCONF" ]; then
  source $COMMMONCONF $*
else
  echo "Before running $0, please ensure you have created and configured ${COMMMONCONF}' using the '${COMMMONCONF}.example' template provided."
  exit 1
fi

#Check if we are already running
if [ -f "$PIDFILE" ]; then
  echo "$0 is already running on this system. Running multiple instances may have unexpected consequences. If you think this is an error (e.g. left over from an aborted run) you may re-run $0 after deleting $PIDFILE (e.g. check the PID in $PIDFILE against 'ps -All' and 'rm $PIDFILE' if there's no match)."
  exit 2
fi

#USING TRAP
#Now when you kill the script it will delete the lock file too. Notice that
#we explicitly exit from the script at the end of trap command, otherwise
#the script will resume from the point that the signal was received.
trap "rm -v -f $PIDFILE; exit 1" INT TERM EXIT
#If we aren't running, store my PID
echo -n "$$" > "$PIDFILE"

#Store default Max User Processes
MAXUSERPROC_SYSTEM="$(ulimit -u)"

#Initial time and date
TIMEDATESTAMP="$(date '+%Y-%m-%d %r')"

#Check for mutt, if not we don't send email
if which mutt > /dev/null; then
    #Send Email to start the test
    if [ -n "$EMAIL_RECIPIENTS_NOTIFICATION" ]; then
    echo "Testing Started from $HOSTNAME at $TIMEDATESTAMP"
    echo ""
    mutt -s "Testing Started from $HOSTNAME at $TIMEDATESTAMP"  -- $EMAIL_RECIPIENTS_NOTIFICATION \ < /dev/null
    
    #Quick pause to allow email to get through first before next step
    sleep $MAILPAUSE
    fi
else
    echo "Mutt is not installed on this system"
fi


while true; do
  #Reset Job console buffer
  echo -n "" | tee $LOGGING/$LOGGING_CONSOLE_FILE

  #Get next job (don't forget to export or batch.sh will not see this variable)
  #--> Needed for some email and clean up controls
  export JOB="$(find $CONF_QUEUE -maxdepth 1 -type f | sort | head -q -n 1)"

  #Check if we have run out of jobs
  if [ "$JOB" == "" ]
  then
    #Update time and date
    TIMEDATESTAMP="$(date '+%Y-%m-%d %r')"
    #Check for mutt, if not we don't send email
    if which mutt > /dev/null; then
        #Send email to end the test
        if [ -n "$EMAIL_RECIPIENTS_NOTIFICATION" ]; then
        echo "Testing Finished from $HOSTNAME at $TIMEDATESTAMP"
        echo ""
        mutt -s "Testing Finished from $HOSTNAME at $TIMEDATESTAMP"  -- $EMAIL_RECIPIENTS_NOTIFICATION \ < /dev/null
    
        #Quick pause to allow email to get through first before next step
        sleep $MAILPAUSE
        fi
    else
        echo "Mutt is not installed on this system"
    fi
    #Quit running the queue processing loop and exit
    break
  else
    parse_config $JOB

    #Output Visual Pad
    echo ""
    echo "**********************************************************************"
    echo "**********************************************************************"
    echo "**********************************************************************"
    echo ""
    echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Job::$JOB::$CONFSTATUS" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

    if [ "$CONFSTATUS" == "OK" ]
    then
      #Check if we have enough process limit for the job, adjust if not
      export MAXUSERPROC_CURRENT="$(ulimit -u)"
      export MAXUSERPROC_ESTIMATE=$(echo "scale=0; (($PROCESSES_STUDENT * $THREADS_STUDENT) + ($PROCESSES_INSTRUCTOR * $THREADS_INSTRUCTOR)) * $MAXUSERPROC_FACTOR" | bc)
      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: ESTIMATING PROCESS REQUIREMENTS" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: $MAXUSERPROC_CURRENT (Available) / $MAXUSERPROC_ESTIMATE (Required)" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Safety factor: $MAXUSERPROC_FACTOR" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      if [ "$MAXUSERPROC_ESTIMATE" -gt "$MAXUSERPROC_CURRENT" ]; then
        ulimit -u $MAXUSERPROC_ESTIMATE
        echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Increasing Max User Processes to $MAXUSERPROC_ESTIMATE" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
        echo "" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      fi

      #Date stamp for output directories
      DATESTAMP="$(date +%Y-%m-%d_%H%M)"

      #Update time and date
      TIMEDATESTAMP="$(date '+%Y-%m-%d %r')"

      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Starting $JOB at $TIMEDATESTAMP" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

      if [ "$PERF_USE_MONITOR" == "YES" ]; then
        #APP: Deploy remote monitoring script
        ./remote_controller.sh REMOTEDEPLOY remote_monitor.sh | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

        #APP: START Monitoring
        ./remote_controller.sh START_REMOTE_MONITORING | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

        #DB: Deploy remote monitoring script
        ./remote_controller_db.sh REMOTEDEPLOY remote_monitor_db.sh | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

        #DB: START Monitoring
        ./remote_controller_db.sh START_REMOTE_MONITORING | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      fi

      #Reset Threads/Processes
      sed -i "s/grinder.processes=[[:digit:]]*/grinder.processes=$PROCESSES_STUDENT/g" $PERF_HOME/student.properties | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      sed -i "s/grinder.threads=[[:digit:]]*/grinder.threads=$THREADS_STUDENT/g" $PERF_HOME/student.properties | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      sed -i "s/grinder.processes=[[:digit:]]*/grinder.processes=$PROCESSES_INSTRUCTOR/g" $PERF_HOME/instructor.properties | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      sed -i "s/grinder.threads=[[:digit:]]*/grinder.threads=$THREADS_INSTRUCTOR/g" $PERF_HOME/instructor.properties | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

      #Reset Times
      sed -i "s/grinder.duration=[[:digit:]]*/grinder.duration=$DURATION_MS/g" $PERF_HOME/*.properties | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

      #Reset the Target APP
      sed -i "s/targetURL=[[:alnum:]]*/targetURL=$TARGETURL/g" $PERF_HOME/config/settings.py | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      sed -i "s/debug=[[:digit:]]*/debug=$GRINDER_DEBUG/g" $PERF_HOME/config/settings.py | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      sed -i "s/rampup=Rampup([[:digit:]]*,[[:digit:]]*)/rampup=$GRINDER_RAMPUP/g" $PERF_HOME/config/settings.py | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

      #Execute the Grinder batch/generate scripts in bash subshells
      #This is needed because the testing framework runs in a pecuilar
      #environment set up that assumes we execute from the executable
      #directory -- all paths are RELATIVE to the execution directory.
      PERF_HOME_RESULTS_JOB="$PERF_HOME_RESULTS/${DATESTAMP}_${TESTTYPE}_$(($PROCESSES_STUDENT * $THREADS_STUDENT))x$(($PROCESSES_INSTRUCTOR * $THREADS_INSTRUCTOR))_${DURATION}min_${TESTNAME}"
      PERF_HOME_REPORTS_JOB="$PERF_HOME_REPORTS/${DATESTAMP}_${TESTTYPE}_$(($PROCESSES_STUDENT * $THREADS_STUDENT))x$(($PROCESSES_INSTRUCTOR * $THREADS_INSTRUCTOR))_${DURATION}min_${TESTNAME}"

      #check to make sure that the temp directory exist, otherwise we create it so that further down we don't run into an issue. 
      if [ ! -d $PERF_HOME/tmp/ ]; then
            mkdir -p $PERF_HOME/tmp/
      fi

      #Generate Long Text -- need to use perl it's more flexible in the long run
      cat $JOB | perl -0777 -ne 'print "$1" if /###OBJECTIVE BEGIN###(.*)###OBJECTIVE END###/ms' > $PERF_HOME/tmp/text_objective.txt
      cat $JOB | perl -0777 -ne 'print "$1" if /###TARGET BEGIN###(.*)###TARGET END###/ms' > $PERF_HOME/tmp/text_target.txt
      cat $JOB | perl -0777 -ne 'print "$1" if /###ACCESSMETHOD BEGIN###(.*)###ACCESSMETHOD END###/ms' > $PERF_HOME/tmp/text_accessmethod.txt
      cat $JOB | perl -0777 -ne 'print "$1" if /###VOLUMEOFTRAFFIC BEGIN###(.*)###VOLUMEOFTRAFFIC END###/ms' > $PERF_HOME/tmp/text_volumeoftraffic.txt

      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME:  Running::batch.sh $PERF_HOME_RESULTS_JOB $TESTTARGET" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      

    ### SORT and Cleanup the course_data.db ###
    if [ -f course_data.db ]; then
        echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Sorting course_data.db" 
        
        mawk -F"|" -f course_data_filter.awk course_data.db > course_data.db.temp
        mv course_data.db.temp course_data.db
        
        
        #sed -i '/^\// !d' course_data.db
        sort -u  course_data.db -o course_data.db
        
        
        
      fi

      ### REMOTE AGENT START ###
      if [ "$REMOTE_AGENT" == "YES" ]; then
      
        #Update the perf home directory on the remote agent so it knows what directory it's in
        echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Updating remote Agent batch with new home directory $REMOTE_AGENT_PERF_HOME" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
        #had to do sed this way to get around the double quotes and bash variable expansion
        sed -i 's,REMOTE_AGENT_PERF_HOME="[^"]*",'REMOTE_AGENT_PERF_HOME=\""$REMOTE_AGENT_PERF_HOME"\"',' batch_remote_agent.sh
       
        #Deploy perf home directory to remote agents
        echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Remote Agent Detected, rsyncing home directory to remote agents" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
        deploy_rsync_all_apps $PERF_HOME/ $REMOTE_AGENT_PERF_HOME| tee -a $LOGGING/$LOGGING_CONSOLE_FILE
        
        
        #Start load test on all remote agents
        #TODO Check to ensure that grinder isn't already running on remote server
        #TODO RUN THIS IN SCREEN
        
        #Stops Grinder on other servers
        execute_ssh_all_apps "pkill -f grinder"   | tee -a
        sleep 5
        
        #Cleans out the logs on the other servers
        execute_ssh_all_apps "rm -vfr ${REMOTE_AGENT_PERF_HOME}/administrator/*.log*"   | tee -a
        execute_ssh_all_apps "rm -vfr ${REMOTE_AGENT_PERF_HOME}/student/*.log*"   | tee -a
        execute_ssh_all_apps "rm -vfr ${REMOTE_AGENT_PERF_HOME}/instructor/*.log*"  | tee -a
        execute_ssh_all_apps "rm -vfr ${REMOTE_AGENT_PERF_HOME}/restapi/*.log*"  | tee -a
        
        #Starts Grinder on all other load generator servers
        execute_ssh_all_apps "${REMOTE_AGENT_PERF_HOME}/batch_remote_agent.sh" $PERF_HOME_RESULTS_JOB $TESTTARGET  | tee -a $LOGGING/$LOGGING_CONSOLE_FILE &
      fi
      ### REMOTE AGENT END ###
      
      
      
      #batch.sh needs to run in a subshell to allow the updated ulimit -u value to take effect
      (./batch.sh $PERF_HOME_RESULTS_JOB $TESTTARGET) | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

      if [ "$PERF_USE_MONITOR" == "YES" ]; then
        #APP: STOP Monitoring
        ./remote_controller.sh STOP_REMOTE_MONITORING | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

        #APP: Get remote logs
        ./download_logs.sh $PERF_LOG_MONITOR $PERF_HOME_REPORTS_JOB | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

        #DB: STOP Monitoring
        ./remote_controller_db.sh STOP_REMOTE_MONITORING | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

        #DB: Get remote logs
        ./download_logs_db.sh $PERF_LOG_MONITOR $PERF_HOME_REPORTS_JOB | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
      fi

      #INITIAL MAPPING
        if [ "$INITIAL_MAPPING" == "TRUE" ]; then
            #we grab the last 20 logins, taking the first one in the list
            lastUserLogin=$(zcat $PERF_HOME_RESULTS_JOB/student/out*.gz |grep "Authenticate.loginSubmit(): RDBMS: Logging in" |cut -d'"' -f 2|tail -n 25|head -n 1)
            echo "Last User Logged in was" $lastUserLogin | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
            
            #backup the live_student_users.db
            cp live_student_users.db live_student_users.db.initialmapping.`date  "+%Y-%m-%d-%H-%M"`
            
            #Remove all users up to that last user
            sed -i "1,/$lastUserLogin/d" live_student_users.db
            
            #NOTE, once 
        
        fi 
        if [ "$INITIAL_MAPPING" == "FALSE" ]; then
            #We should check to see if there was an initial mapping live_student_users file found and if so, move it backup
            lastStudentLiveDBFile=$(ls live_student_users.db.*| xargs -n 1 basename|sort |head -n 1)
            if [ -f "$lastStudentLiveDBFile" ]; then
                mv $lastStudentLiveDBFile live_student_users.db
            fi
        fi

      
      #ZIP up reports
      if zip -rj "$PERF_HOME_REPORTS_JOB.zip" "$PERF_HOME_REPORTS_JOB"; then
        if [ -n "$EMAIL_RECIPIENTS_RESULTS" ]; then
          #Update time and date
          TIMEDATESTAMP="$(date '+%Y-%m-%d %r')"

          #Send job report via email
          echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: JOB REPORT: Sending to $EMAIL_RECIPIENTS_RESULTS at $TIMEDATESTAMP"
          echo ""
          mutt -a "$PERF_HOME_REPORTS_JOB.zip" -s "JOB REPORT: $JOB :: $TIMEDATESTAMP"  -- $EMAIL_RECIPIENTS_RESULTS \ < /dev/null

          #Quick pause to allow email to get through first before next step
          sleep $MAILPAUSE
        fi
      fi
      #Clean up after yourself
      if [ -f "$PERF_HOME_REPORTS_JOB.zip" ]; then rm -v -f "$PERF_HOME_REPORTS_JOB.zip"; fi

      #Update time and date
      TIMEDATESTAMP="$(date '+%Y-%m-%d %r')"

      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Finishing $JOB at $TIMEDATESTAMP" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    else
      echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: ERROR: Misconfigured job" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    fi

    #Copy console.log, client.info and queue/job file into the results directory
    cp -fv "$JOB" "$PERF_HOME_RESULTS_JOB/" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    cp -fv "$JOB" "$PERF_HOME_RESULTS_JOB/" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    cp -fv client.info "$PERF_HOME_RESULTS_JOB/" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    cp -fv "$LOGGING/$LOGGING_CONSOLE_FILE" "$PERF_HOME_RESULTS_JOB/" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    
    
    #Once the configuration has been picked up, we can move it to the completed folder
    mv "$JOB" "$CONF_QUEUE_COMPLETE"
    


    #Output Visual Pad
    echo ""
    echo "**********************************************************************"
    echo "**********************************************************************"
    echo "**********************************************************************"
    echo ""
  fi

  #Quick pause to allow Job Report email to get through first before next job
  echo ""
  echo " _  _     _____    __    _  _____    __ __      ___ __ _____ __"
  echo "|_)|_|| |(_  | |\|/__   |_)|_  | | ||_ |_ |\|    | |_ (_  | (_ "
  echo "|  | ||_|__)_|_| |\_|   |_)|__ | |^||__|__| |    | |____) | __)"
  echo ""
  sleep $TESTPAUSE
done


#Remove Console Log
rm -v -f "$LOGGING/$LOGGING_CONSOLE_FILE"

#Remove PID file
rm -v -f "$PIDFILE"

#Restore default Max User Processes
ulimit -u $MAXUSERPROC_SYSTEM

#Clear the trap (see above)
trap - INT TERM EXIT

exit 0
