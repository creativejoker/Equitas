# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

import config.settings
import actions.base
from scripts.authenticate import Authenticate
from scripts.portal import Portal
import utils.random

class PortalAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn ):
        actions.base.Base.__init__(self, request, offset)
        self.portal = Portal(self.request, bblearn)
        self.addTest('Portal: Open Portal Tab: NAV',self.portal)
        self.addTest('Portal: Load Portal Modules: NAV',self.portal)
        self.addTest('Portal: Load Course Memberships: NAV',self.portal)
        self.addTest('Portal: Open Portal Announcements: NAV',self.portal)
        self.addTest('Portal: Open Portal My Grade: NAV', self.portal )
        self.addTest('Portal: Open Portal Calendar: NAV', self.portal )
        for target in config.settings.portalTopTabTargets:
            self.addTest('Portal: Open Top Portal Tab: '+target+' : NAV',self.portal)
        for target in config.settings.portalSubTabTargets:
            self.addTest('Portal: Open Sub Portal Tab: '+target+' : NAV',self.portal)
        for target in config.settings.portalToolPanelTargets:
            self.addTest('Portal: Open Tool Panel: '+target+' : NAV',self.portal)

        #self.addTest('Portal: Submit Portal Calendar: TXN', self.portal )
        #
        ##ULTRA USE CASES
        #self.addTest('Portal: Open Ultra Activity Stream: NAV',self.portal)

    def __call__(self):

        #if self.portal.bblearn.isUltra:
        #    self.getTest('Portal: Open Ultra Activity Stream: NAV').openUltraActivityStream()
        #else:
        if config.settings.initialCourseMapping and config.settings.initialPortalNamesMapping==False:
            self.getTest('Portal: Load Course Memberships: NAV').loadCourseMemberships()
            return 
        
        
        ########################################################################
        #Opening Main portal tab
        self.info("PortalAction(): Opening default portal tab")
        self.getTest('Portal: Open Portal Tab: NAV').openTab()
        self.portal.loadPortalTabCheck()
        self.portal.extractPortalObjects(True)
        
        if  len(self.portal.portalModuleParameters)>0:
            self.getTest('Portal: Load Portal Modules: NAV').loadTabModules()
            self.sleep("navigational")
        
        
        #if we're just mapping the portal names, then we shoudl return at this point
                
        if config.settings.initialPortalNamesMapping:
            return 
        
        #Randomly select a tool Panel target on that page
        self.info("PortalAction(): Randomly Opening Tool Panels "+str(self.distributionPercentage("PortalAction.OpenToolPanelPercentage"))+"% of the time:")
        if len(self.portal.toolPanelURLs) > 0:
            if utils.random.randomlySelectPercentOfTime(self.distributionPercentage("PortalAction.OpenToolPanelPercentage")):
                self.info("PortalAction(): Opening Tool panel targets underneath main portal tab")
                for target in config.settings.portalToolPanelTargets:
                    if self.portal.doesPortalObjectExist(target,self.portal.toolPanelURLs):
                        self.getTest('Portal: Open Tool Panel: '+target+' : NAV').openPortalObject("Tool Panel",target,self.portal.toolPanelURLs)
        else:
             self.info("PortalAction(): No Tool panel targets underneath main portal tab")
             
        ########################################################################    
        #Randomly selecting another top portal tab to open
        if len(self.portal.topPortalTabURLs) > 0:
            self.info("PortalAction(): Randomly Opening Top Portal Tabs "+str(self.distributionPercentage("PortalAction.OpenTopTabPercentage"))+"% of the time:")
            for target in config.settings.portalTopTabTargets:
                if self.portal.doesPortalObjectExist(target,self.portal.topPortalTabURLs):
                    if utils.random.randomlySelectPercentOfTime(self.distributionPercentage("PortalAction.OpenTopTabPercentage")):
                        self.info("PortalAction():                                                                                  ")
                        self.getTest('Portal: Open Top Portal Tab: '+target+' : NAV').openPortalObject("Top Frame",target,self.portal.topPortalTabURLs)        
                        self.portal.loadPortalTabCheck()
                        #we should check to see what sort of portal objects are on this pages
                        self.portal.extractPortalObjects()
                        
                        self.info("PortalAction(): Opening Portal Modules underneath Top Tab \""+target+"\"")
                        #Load all the portal modules on this tab
                        if  len(self.portal.portalModuleParameters)>0:
                            self.getTest('Portal: Load Portal Modules: NAV').loadTabModules()
                            self.sleep("navigational")
                        
                        self.info("PortalAction(): Randomly Opening Sub Portal Tabs underneath \""+target+"\" " +str(self.distributionPercentage("PortalAction.OpenSubTabPercentage"))+"% of the time:")
                        #We should randomly open sub Portal Tabs
                        if len(self.portal.subPortalTabURLs)>0 and utils.random.randomlySelectPercentOfTime(self.distributionPercentage("PortalAction.OpenSubTabPercentage")):
                            for target in config.settings.portalSubTabTargets:
                                self.info("PortalAction():                                                                                  ")
                                #Check to see if it exist first
                                if self.portal.doesPortalObjectExist(target,self.portal.subPortalTabURLs):
                                    self.getTest('Portal: Open Sub Portal Tab: '+target+' : NAV').openPortalObject("Sub Tabs",target,self.portal.subPortalTabURLs)
        else:
            self.info("PortalAction(): No Other Top Portal Tabs found, skipping...")
            
            
