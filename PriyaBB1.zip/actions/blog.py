# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from scripts.blog import Blog
import actions.base
from net.grinder.script.Grinder import grinder
import utils.random

class BlogAction(actions.base.Base):

    def __init__(self, request,offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.blog = Blog(self.request, bblearn)
        self.courseAction = actions.course.CourseAction(request, 25, bblearn)
        self.addTest('Course: Open TOC: Blogs : NAV', self.blog)
        self.addTest('Blog: Open Blog: NAV', self.blog)
        self.addTest('Blog: Open Create Entry: NAV', self.blog)
        self.addTest('Blog: Submit Create Entry: TXN', self.blog)
        self.addTest('Blog: Save Draft Entry: TXN', self.blog)
        self.addTest('Blog: View Draft Entry: NAV', self.blog)
        self.addTest('Blog: Comment Entry: NAV', self.blog)
    
    def __call__(self):
        
        #If ULTRA, do nothing for now
        if self.blog.bblearn.isUltra:
            #Nothing for now as Blogs are not supported in Ultra
            self.info("BlogAction(): Blogs are not supported in Ultra")
            return
        
        #Else if CLASSIC  
        
    
        #Randomly decides to re-open the course tab and course. Delegates the open course tab and opening of the course to the course class.
        #If it opens the course again, it will randomly select a course to open from the list of courses available.
        #By default, it opens the course tab 5% of the time and the course 10% of the time. This is on top of the initial course load after logging into the application
        self.courseAction.openCourseTab()
        self.courseAction.openCourse()
        
       #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.blog.bblearn.coursePks)==0:
            self.info("BlogAction(): User is not enrolled in any courses, skipping...")
            return
        
        #If ULTRA, do nothing
        if self.blog.bblearn.isUltra:
            #Nothing for now as assessments are not supported in Ultra
            self.info("BlogsAction(): Blogs are not supported in Ultra")
            return
            
        if not self.blog.blogCourseTOCExist():
            self.info("BlogAction(): No Blog Table of Content Link found in course, skipping...")
            return
            
        
        #Open Blog TOC, only if available
        self.getTest('Course: Open TOC: Blogs : NAV').openBlogsCourseTOC()
        self.blog.openBlogsCourseTOCCheck()
        self.sleep("navigational")
        
        #Check to ensure that the user has blogs in courses before proceeding
        if len(self.blog.bblearn.blogUrls)==0:
            self.info("BlogAction(): User does not have any blogs, skipping...")
            return
        
        
        
        #if this is the first blog entry then we need to create a new blog entry first
        if self.blog.bblearn.blogUrls[0].count("editBlogEntry")>0:
            self.info("BlogAction(): Found Create Blog Link and no blogs, creating blog entry...")
            if self.blog.openCreateBlogEntryLogic(self.blog.bblearn.blogUrls[0]):
                self.getTest('Blog: Open Create Entry: NAV').openCreateBlogEntry()
                self.extractCurrentBlogPk()
                self.sleep("navigational")
            self.blog.submitCreateBlogEntryLogic()
            self.getTest('Blog: Submit Create Entry: TXN').submitCreateBlogEntry()
            self.blog.removeTempFile()
            self.sleep("navigational")
            
        #Otherwise we can just open up the first blog we see
        self.blog.openBlogLogic()
        self.getTest('Blog: Open Blog: NAV').openBlog()
        self.sleep("navigational")
        
        if self.blog.lastPage.count('href="/webapps/blogs-journals/execute/editBlogEntry')==0:
            #If we don't have an editBlogEntry URL then we move on cause there's nothing to submit
            self.info("BlogAction(): No Create Blog Entry entry URL found")
            return    
        #Random percentage selector, returns true 20% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("BlogAction.OpenCreateBlogPercentage")):
            self.blog.openCreateBlogEntryLogic()
            self.getTest('Blog: Open Create Entry: NAV').openCreateBlogEntry()
            self.sleep("navigational")
            

            #20% of the time we submit a draft
            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("BlogAction.SubmitBlogDraftPercentage")):
                self.info("BlogAction(): Creating New Blog draft 20% of the time")
                self.blog.submitCreateBlogEntryLogic("draft")
                self.getTest('Blog: Save Draft Entry: TXN').submitCreateBlogEntry()
                self.sleep("navigational")
            
            #Otherwise we just submit the usual blog entry
            else:
                self.blog.submitCreateBlogEntryLogic()
                self.getTest('Blog: Submit Create Entry: TXN').submitCreateBlogEntry()
                self.blog.removeTempFile()
                self.sleep("navigational")
        
        
        #To view Blog Drafts, first open the blog
        self.blog.openBlogLogic()
        self.getTest('Blog: Open Blog: NAV').openBlog()
        self.sleep("navigational")
        if self.blog.viewBlogDraftEntryLogic():
            self.getTest('Blog: View Draft Entry: NAV').viewBlogDraftEntry()
            self.sleep("navigational")
        #self.getTest('Blog: Comment Entry: NAV').commentBlogEntry()
        #self.sleep("navigational")
    
        #Cleanup - Not sure if necessary, but what the hell
        self.blog.reset()