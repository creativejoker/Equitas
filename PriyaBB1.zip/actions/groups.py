# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard course navigation


from scripts.course import Course
from scripts.groups import Groups
from scripts.portal import Portal
import actions.base

class GroupAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.course = Course(self.request, bblearn)
        self.groups = Groups(self.request, self.course, bblearn)
        self.portal = Portal(self.request, bblearn)
        self.addTest('Open Courses Tab',self.course)
        self.addTest('Load Courses Tab Modules',self.course)
        self.addTest('Open Course',self.course)
        self.addTest('Load Course Modules',self.course)
        self.addTest('Open Groups', self.groups)
        self.addTest('Open Group Page', self.groups)      
        self.addTest('Subscribe Group', self.groups)

    def __call__(self):

        self.getTest('Open Courses Tab').openCoursesTab()
        self.getTest('Load Courses Tab Modules').loadCoursesTabModules()
        self.sleep("navigational")
        self.getTest('Open Course').openCourse()
        self.getTest('Load Course Modules').loadCourseModules()
        self.sleep("navigational")
        self.getTest('Open Groups').openGroups()
        self.sleep("navigational")
        self.getTest('Open Group Page').openGroupPage()
        self.sleep("navigational")
        self.getTest('Subscribe Group').subscribeGroup()

