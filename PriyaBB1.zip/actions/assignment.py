# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from scripts.assignment import Assignment
import actions.base
import utils.random 


class AssignmentAction(actions.base.Base):
    
    def __init__(self, request,offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.courseAction = actions.course.CourseAction(request, 25, bblearn)
        self.ast = Assignment(self.request, bblearn)
        self.addTest('Course: Open TOC: Assignments : NAV', self.ast)
        self.addTest('Assignment: Open: NAV', self.ast)   
        self.addTest('Assignment: Open Attempt: NAV', self.ast)    
        self.addTest('Assignment: Open New Attempt: NAV', self.ast)        
        self.addTest('Assignment: Submit: TXN', self.ast)
        self.addTest('Assignment: Review: NAV', self.ast)

        #ULTRA SUPPORT
        self.addTest('Assignment: Open Ultra: NAV', self.ast)   
        self.addTest('Assignment: Start Ultra: NAV', self.ast)   
        self.addTest('Assignment: Submit Ultra: NAV', self.ast) 
    def __call__(self):

        

        #Randomly decides to re-open the course tab and course. Delegates the open course tab and opening of the course to the course class.
        #If it opens the course again, it will randomly select a course to open from the list of courses available.
        #By default, it opens the course tab 5% of the time and the course 10% of the time. This is on top of the initial course load after logging into the application
        self.courseAction.openCourseTab()
        self.courseAction.openCourse()
    
        #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.ast.bblearn.coursePks)==0:
            self.info("AssignmentAction(): User is not enrolled in any courses, skipping...")
            return
            
        #If ULTRA
        #if self.ast.bblearn.isUltra:
        #    #Nothing for now as assessments are not supported in Ultra
        #    self.getTest('Assignment: Open Ultra: NAV').openUltraAssignments()
        #    self.getTest('Assignment: Start Ultra: NAV').startUltraAssignments()
        #    self.getTest('Assignment: Submit Ultra: NAV').submitUltraAssignments()
        #    return
            
        #Open the Assignment Course Table of contents, if this returns false then we don't need to go further as there are no assignments available
        if not self.ast.assignmentsCourseTOCExist():
            self.info("AssignmentsAction(): No Assignments Table of Content Link found in course, skipping...")
            return
        
        self.getTest('Course: Open TOC: Assignments : NAV').openAssignmentsCourseTOC()
            
        #If we're in legacy mode, we need to extract the values here
        if self.ast.bblearn.courseTOCModeIsLegacy:
            self.ast.bblearn.extractAssignmentUrls(self.ast.lastPage)
        
        self.sleep("other")
        
        #Check to ensure that the user has assignment urls before proceeding
        if len(self.ast.bblearn.assignmentUrls)==0:
            self.info("Assignment.openAssignment(): No assignments found in this course:"+self.ast.bblearn.coursePk+", skipping")
            return
            
        #Control the number of iterations by changing the value of the range. 
        #Need to ensure that there is a assignment opened before we move to submission

        for x in range(self.distributionPercentage("AssignmentAction.OpenIterations")):
            self.ast.openAssignmentLogic()
            self.getTest('Assignment: Open: NAV').openAssignment()
            self.ast.openAssignmentCheck()
            self.sleep("navigational")
            
            #If this is a new assignment that doesn't have any attempts, then we just go ahead and submit the page
            if self.ast.submitAssignmentLogic():
            
                #CONCURRENT ASSIGNMENT SUBMISSION - OPTIONAL
                #Checks for the "SUBMITTEST" file in the grinder home directory. If it IS FOUND, then the test waits for 3 minutes. Otherwise, it continues..
                #Use for concurrent testing
                utils.rampup.waitForFile("SUBMITASSIGNMENT",180000)
                self.getTest('Assignment: Submit: TXN').submitAssignment()
            
                self.ast.removeTempFile()
                self.sleep("navigational")
                self.getTest('Assignment: Review: NAV').reviewAssignment()
                
            #Check to see if there are attempts, otherwise we break out of the for loop
            if len(self.ast.assignmentAttemptUrls)==0:
                self.info("AssignmentAction(): No assignment attempt pages found, skipping..")
                break
                
            #If there are available attempts, then we try to open an attempt
            for x in range(self.distributionPercentage("AssignmentAction.NumOfOpens")):
                self.ast.openAssignmentAttemptLogic()
                self.getTest('Assignment: Open Attempt: NAV').openAssignmentAttempt()
                self.sleep("navigational")
            
                
        if self.ast.hasAssignmentAttempts and utils.random.randomlySelectPercentOfTime(self.distributionPercentage("AssignmentAction.SubmitAssignmentPercentage")):
            if self.ast.openNewAssignmentAttemptLogic():
                self.getTest('Assignment: Open New Attempt: NAV').openNewAssignmentAttempt()
            
            if self.ast.submitAssignmentLogic():
            
                #CONCURRENT ASSIGNMENT SUBMISSION - OPTIONAL
                #Checks for the "SUBMITTEST" file in the grinder home directory. If it IS FOUND, then the test waits for 3 minutes. Otherwise, it continues..
                #Use for concurrent testing
                utils.rampup.waitForFile("SUBMITASSIGNMENT",180000)
                self.getTest('Assignment: Submit: TXN').submitAssignment()
            
                self.ast.removeTempFile()
                self.sleep("navigational")
                self.getTest('Assignment: Review: NAV').reviewAssignment()
        else:
            self.info("AssignmentAction(): User did not have any assignments to submit or was not randomly selected, skipping...")
            
        #Cleanup - Not sure if necessary, but what the hell
        self.ast.reset()