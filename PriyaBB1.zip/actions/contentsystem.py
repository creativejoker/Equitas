# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard course navigation
#from net.grinder.script.Grinder import grinder
from scripts.contentsystem import ContentSystem
import actions.base
import utils.random
import config.settings


class ContentSystemAction(actions.base.Base):
    
    def __init__(self, request, offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.cs = ContentSystem(self.request,bblearn)
        self.addTest('CS: Open User Collection: NAV',self.cs)
        self.addTest('CS: Open Add to User Collection: NAV',self.cs)
        self.addTest('CS: Submit Add to User Collection: TXN',self.cs)
        self.addTest('CS: Open Institution Collection: NAV',self.cs)
        self.addTest('CS: Open Institution Folder: NAV',self.cs)
        self.addTest('CS: Open Institution Item: CNT',self.cs)
        for target in config.settings.contentCollectionFolders:
            self.addTest('CS: Open '+str.capitalize(target)+' Collection: NAV',self.cs)
            self.addTest('CS: Open '+str.capitalize(target)+' Folder: NAV',self.cs)
            self.addTest('CS: Open '+str.capitalize(target)+' Files: CNT',self.cs)
        self.addTest('CS: Open Basic Search: NAV',self.cs)
        self.addTest('CS: Submit Basic Search: TXN',self.cs)
        
    def __call__(self):
    
        #Check to ensure the course content tab is enabled before proceeding
        if(self.cs.bblearn.contentSystemTabPk) =="":
            self.info("ContentSystemAction(): Content System Portal Tab not found, skipping content system use cases...")
            return
            
        self.getTest('CS: Open User Collection: NAV').openUserCollection()
        self.sleep("navigational")
        
        #Random percentage selector, returns true 20% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("ContentSystemAction.SubmitContentUploadPercentage")):
            self.getTest('CS: Open Add to User Collection: NAV').openSingleFileUploadForm()
            self.sleep("navigational")
            self.getTest('CS: Submit Add to User Collection: TXN').submitSingleFileUploadForm()
            self.sleep("navigational")
        
        
        #Randomly select a contentCollection Folder Type
        contentCollectionFolderTarget = utils.random.randomlySelectValueFromList(config.settings.contentCollectionFolders)
        #TODO: Add the logic in the action class, so that we capture the unique sub folder loads and the content load
        #Check to see if the user has acces to this folder
        if self.getTest('CS: Open '+str.capitalize(contentCollectionFolderTarget)+' Collection: NAV').openCollection(contentCollectionFolderTarget):
            self.sleep("navigational")
            #Control the number of iterations by changing the value of the range. 
            for x in range(self.distributionPercentage("ContentSystemAction.OpenIterations")):
                #Check to see if there are files or folders underneath the main folder
                self.cs.openFileLogic()
                #If there are no files, then we try to open a folder
                if len(self.cs.folders) != 0 and len(self.cs.files)==0:
                    while len(self.cs.files) == 0:
                        self.cs.openCSFoldersLogic()
                        if self.cs.folderUrl != "":
                            self.getTest('CS: Open '+str.capitalize(contentCollectionFolderTarget)+' Folder: NAV').openCSFolder()
                            self.cs.openCSFolderCheck()
                        #if there's no more folders, then we break out of the loop
                        if len(self.cs.folders) == 0:
                            #Set the result set to the previous level
                            self.cs.openCSFolderCheck()
                            break
                            
                self.cs.openFileLogic()
                if len(self.cs.fileUrl) != 0:
                    self.getTest('CS: Open '+str.capitalize(contentCollectionFolderTarget)+' Files: CNT').openCSFile()
                    self.sleep("navigational")
        #Basic Search
        
        self.info("ContentSystemAction(): Opening Basic Search "+str(self.distributionPercentage("ContentSystemAction.openBasicSearchPercentage"))+ " percent of the time...")
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("ContentSystemAction.openBasicSearchPercentage")):
            self.getTest('CS: Open Basic Search: NAV').openBasicSearch()
            self.sleep("navigational")
            if self.cs.openBasicSearchLogic():
                self.getTest('CS: Submit Basic Search: TXN').submitBasicSearch()
                self.sleep("transactional")
                if self.cs.openBasicSearchFileLogic():
                    if len(self.cs.fileUrl) != 0:
                        self.getTest('CS: Open User Files: CNT').openCSFile()
                        self.sleep("other")


class InstructorContentUploadAction(actions.base.Base):
    
    def __init__(self, request, offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.cs = ContentSystem(self.request,bblearn)
        self.courseAction = actions.course.CourseAction(request, 25, bblearn)
        self.addTest('CS: Open Course Collection: NAV',self.cs)
        self.addTest('CS: Open Add to Course Collection: NAV',self.cs)
        self.addTest('CS: Submit Add to Course Collection: TXN',self.cs)

    def __call__(self):

        #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.cs.bblearn.coursePks)==0:
            self.info("InstructorContentUploadAction(): User is not enrolled in any courses, skipping...")
            return
        #Should just do a load of the course and check to see if they have a url
        #Check to ensure that the user has a course content collection link in courses before proceeding
        if len(self.cs.bblearn.courseContentCollectionURL)==0:
            self.info("InstructorContentUploadAction(): User does not have a course file collection, skipping...")
            return

        if self.getTest('CS: Open Course Collection: NAV').openCourseCollection() == True:
            return
            
        self.sleep("navigational")
        
        #Random percentage selector, returns true 50% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("InstructorContentUploadAction.SubmitContentUploadPercentage")):
            self.getTest('CS: Open Add to Course Collection: NAV').openSingleFileUploadForm()
            self.sleep("navigational")
            self.getTest('CS: Submit Add to Course Collection: TXN').submitSingleFileUploadForm()
            self.sleep("navigational")
