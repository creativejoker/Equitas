# Standard course navigation

import config.settings
import scenarios.base
from scripts.courseCopy import InstructorCourseCopy
import actions.base
import utils.random

class CourseCopyAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.course = InstructorCourseCopy(self.request, bblearn)

        self.addTest('Course: Open Course: NAV',self.course)
        self.addTest('Course: Load Course Modules: NAV',self.course)
        self.addTest('Course: Open TOC: Packages and Utilities: NAV', self.course)
        self.addTest('Course: Open Course Copy: NAV', self.course)
        self.addTest('Course: Select Course to Copy: NAV', self.course)
        self.addTest('Course: Submit Course Copy: TXN', self.course)

    def __call__(self):


        self.info("CourseCopyAction(): Opening Course Copy "+str(self.distributionPercentage("CourseCopyAction.openCourseCopyPercentage"))+ " percent of the time...")
        
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("CourseCopyAction.openCourseCopyPercentage")):
           
            #to slow things down so this is not too active, adding some sleeps for 60 seconds
            self.sleep("view_grades")
           
           #Check to ensure that the user is enrolled in courses before proceeding
            if len(self.course.bblearn.coursePks)==0:
                self.info("InstructorContentUploadAction(): User is not enrolled in any courses, skipping...")
                return
            
            if self.course.isInstructorEnrolledInCourse():
                self.getTest('Course: Open TOC: Packages and Utilities: NAV').openCoursePackagesAndUtilities()
                self.sleep("navigational")
                
                if self.course.isCourseCopyAvailable():
                    self.getTest('Course: Open Course Copy: NAV').openCourseCopy()
                    self.sleep("navigational")
            
                    if self.getTest('Course: Select Course to Copy: NAV').selectCourseCopy():
                        self.sleep("navigational")
            
                        self.getTest('Course: Submit Course Copy: TXN').submitCourseCopy()
                        self.sleep("transactional")

        

