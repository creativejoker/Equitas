# Standard course navigation

import config.settings
import scenarios.base
from scripts.sectionMerge import InstructorSectionMerge
import actions.base
import utils.random

class SectionMergeAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.course = InstructorSectionMerge(self.request, bblearn)

        self.addTest('SectionMerge: Open Managed Merged Courses: NAV',self.course)
        self.addTest('SectionMerge: Open Setup New Merged Course: NAV',self.course)
        self.addTest('SectionMerge: Open Merged Course Memberships: NAV', self.course)
        self.addTest('SectionMerge: Open Merged Course Modify: NAV', self.course)
        self.addTest('SectionMerge: Disassociate Merged Course: TXN', self.course)
        self.addTest('SectionMerge: Submit Select Courses to Merge: TXN', self.course)
        self.addTest('SectionMerge: Submit Select From Existing Course: TXN', self.course)

    def __call__(self):


        self.info("SectionMergeAction(): Opening Section Merge "+str(self.distributionPercentage("SectionMergeAction.openSectionMergePercentage"))+ " percent of the time...")
        
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("SectionMergeAction.openSectionMergePercentage")):
          
           #to slow things down so this is not too active, adding some sleeps for 60 seconds
           #self.sleep("view_grades")
          
           if self.course.isSectionMergeToolAvailable():
           
               
                self.getTest('SectionMerge: Open Managed Merged Courses: NAV').openManagedMergedCourses()
                self.sleep("navigational")
               
                self.info("SectionMergeAction(): Select/Submitting Course to  Merge "+str(self.distributionPercentage("SectionMergeAction.submitNewSectionMergesPercentage"))+ " percent of the time...")
        
                if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("SectionMergeAction.submitNewSectionMergesPercentage")):
                    #Check to see if the new merge course button is available
                    if self.course.openManagedMergedCoursesLogic():
                
                        self.getTest('SectionMerge: Open Setup New Merged Course: NAV').openSetupNewMergeCourse()
                
                        if self.course.selectCoursesToMergeLogic():
                            self.getTest('SectionMerge: Submit Select Courses to Merge: TXN').submitSelectCoursesToMerge()
                            self.course.selectMergeCourseCreationLogic()
                        
                        #Existing Course
                            if len(self.course.existingCoursePKs)>0:
                                self.getTest('SectionMerge: Submit Select From Existing Course: TXN').submitSelectFromExistingCourse()
                        ##Chose whether to merge into new or existing
                        #elif self.course.openMergeCourseIntoNewCourseURL !="":
                        #    self.getTest('Course: Open Course Copy: NAV').openCreateANewMergedCourse()
                        #    if self.course.openCreateANewMergedCourseLogic():
                        #        self.getTest('Course: Open Course Copy: NAV').submitCreateANewMergedCourse()
                    #Randomly Open up a course membership
                if len(self.course.openMergedCourseMembershipsUrls)>0:
                    self.getTest('SectionMerge: Open Merged Course Memberships: NAV').openMergedCourseMemberships()
                    
                #Randomly opeup up the course modify
                if len(self.course.openMergedCourseModifyUrls)>0:
                    self.getTest('SectionMerge: Open Merged Course Modify: NAV').openMergedCourseModify()
                    
                    self.info("SectionMergeAction(): Select/Submitting Course to  Disassociate "+str(self.distributionPercentage("SectionMergeAction.submitDisassociateSectionMergesPercentage"))+ " percent of the time...")
        
                    if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("SectionMergeAction.submitDisassociateSectionMergesPercentage")):
                        if self.course.disassociateMergedCourseLogic():
                            self.getTest('SectionMerge: Disassociate Merged Course: TXN').submitDisassociateMergedCourse()