# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

import config.settings
import actions.base
from scripts.authenticate import Authenticate
from scripts.portal import Portal

class LoginAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn, usernameParam = config.settings.username ):
        actions.base.Base.__init__(self, request, offset)
        self.auth = Authenticate(self.request, bblearn, usernameParam)
        self.addTest('Authentication: Open Login Page: NAV',self.auth)
        self.addTest('Authentication: Submit Login: TXN',self.auth)
        self.addTest('Authentication: Submit Force Change Password: TXN',self.auth)
        self.addTest('Portal: Open Portal Tab: NAV',self.auth)
        self.addTest('Portal: Load Portal Modules: NAV',self.auth)
        self.addTest('Portal: Server HealthCheck: NAV',self.auth)
    
    def __call__(self):
        # Make sure to select a new user each time.
        self.auth.reset()
        self.getTest('Authentication: Open Login Page: NAV').loginPage()
        self.sleep("navigational")
        self.auth.redirectPageLogic()
        
        if self.auth.redirectUrl !="" and self.auth.redirectUrl !="/webapps/login/":
            self.getTest('Portal: Open Portal Tab: NAV').openPortalTab()
            
            if  len(self.auth.portal.portalModuleParameters)>0:
                self.getTest('Portal: Load Portal Modules: NAV').openPortalTabModules()
                self.sleep("navigational")
                
                
            #Check to see if the login module is there, if not then we need to go to the login page
            #<div id="loginBoxFull">

            
            if self.auth.lastPage.count('loginBoxFull')==0 and self.auth.lastPage.count('/webapps/login/?action=relogin')>0 :
                self.info("AuthenticationAction(): Login module not found on portal page, opening the login page link")
                self.getTest('Authentication: Open Login Page: NAV').loginPage('/webapps/login/?action=relogin')
        
        #if direct portal is turned off and we get a redirect, we need to open that loginpage
        #<html><head><meta http-equiv="refresh" content="0; url=/webapps/login/" /></head></html>
        if self.auth.redirectUrl =="/webapps/login/":
            self.info("AuthenticationAction(): Redirect to login page found, opening login page.")
            self.getTest('Authentication: Open Login Page: NAV').loginPage(self.auth.redirectUrl)

            #it's possible that the user gets redirected back to the portal page with a guest sessions after hitting the login page, so we need to recheck to see if they have a login module or relogin page so that we can hit the /webapps/login to get the security nonce before posting the login. This was the case in SENA's login
            if self.auth.lastPage.count('loginBoxFull')==0 and self.auth.lastPage.count('/webapps/login/?action=relogin')>0 :
                self.info("AuthenticationAction(): Login module not found on portal page, opening the login page link")
                self.getTest('Authentication: Open Login Page: NAV').loginPage('/webapps/login/?action=relogin')
        ########################################################################
        #BBLEARN Extracts
        #Helper method to extract the Images/JS/CSS from the results and place it into the bblearn object
        self.auth.bblearn.extractBbLearnImagesJSCSS(self.auth.lastPage)
        #Helper method to extract the BbLearn Version and VI from the results and place it into the bblearn object
        self.auth.bblearn.extractBbLearnVersion(self.auth.lastPage)    
        
        
        self.auth.loginSubmitLogic()
        loginStatus = self.getTest('Authentication: Submit Login: TXN').loginSubmit()
        self.sleep("navigational")
        
        
        #MD5: "password1" = AA3401400BC76CFA20F4DF5DBC6AAA16
        #MD5: "password" = B081DBE85E1EC3FFC3D4E7D0227400CD
        #Base64 for LDAP:  "password1"  = cGFzc3dvcmQx
        #Base64 for LDAP:  "password"  = cGFzc3dvcmQ= 
        if self.auth.lastPage.find("BbGS-PasswordChange") > 0 and loginStatus:
        
            #Change password to "password1"
            self.getTest('Authentication: Submit Force Change Password: TXN').changePasswordSubmit("cGFzc3dvcmQx")
            #Then change it back to "password"
            self.getTest('Authentication: Submit Force Change Password: TXN').changePasswordSubmit("cGFzc3dvcmQ=")
            self.sleep("navigational")


        
        #put in a check to see what server the user landed on
        self.getTest('Portal: Server HealthCheck: NAV').checkServerHostname()
        #Return status to the scenarios class so that if the user fails to log in, the rest of the use cases are not executed
        return loginStatus



class autoSignonAction(actions.base.Base):
    def __init__(self, request, offset, bblearn, usernameParam = config.settings.username ):
        actions.base.Base.__init__(self, request, offset)
        self.auth = Authenticate(self.request, bblearn, usernameParam)
        self.addTest('Authentication: Submit AutoSignon Login: TXN',self.auth)


    def __call__(self):
        # Make sure to select a new user each time.
        self.auth.reset()
        #Stop further progress in this iteration of the thread due to failed login
        loginStatus = self.getTest('Authentication: Submit AutoSignon Login: TXN').autosignon()
        # Longer sleep on failure
        self.sleep("authentication")
        
        #Return status
        return loginStatus


class CASLoginAction(actions.base.Base):
    def __init__(self, request, offset, bblearn,usernameParam = config.settings.username ):
        actions.base.Base.__init__(self, request, offset)
        self.auth = Authenticate(self.request, bblearn, usernameParam)
        self.portal = Portal(self.request,bblearn)
        self.addTest('Authentication: Submit CAS Login: TXN',self.auth)


    def __call__(self):
        # Make sure to select a new user each time.
        self.auth.reset()
        self.getTest('Authentication: Submit CAS Login: TXN').CASlogin()
        self.sleep("navigational")

class ShibLoginAction(actions.base.Base):
    def __init__(self, request, offset, bblearn,usernameParam = config.settings.username ):
        actions.base.Base.__init__(self, request, offset)
        self.auth = Authenticate(self.request, bblearn, usernameParam)
        self.portal = Portal(self.request,bblearn)
        self.addTest('Authentication: Submit Shib Login: TXN',self.auth)


    def __call__(self):
        # Make sure to select a new user each time.
        self.auth.reset()
        self.getTest('Authentication: Submit Shib Login: TXN').ShibLogin("?returnUrl=https%3A%2F%2Fblverf.lms.it.ubc.ca%2Fwebapps%2Fportal%2Fframeset.jsp&authProviderId=_162_1")
        self.sleep("navigational")

class LogoutAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.auth = Authenticate(self.request,bblearn)
        self.addTest('Authentication: Logout: NAV',self.auth)

    def __call__(self):
        self.getTest('Authentication: Logout: NAV').logout()
        self.sleep("navigational")
