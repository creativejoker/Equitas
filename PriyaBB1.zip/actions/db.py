# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard course navigation

from scripts.course import Course
from scripts.db import Db
import actions.base
import utils.random

class DbAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.courseAction = actions.course.CourseAction(request, 25, bblearn)
        self.db = Db(self.request,bblearn)
        self.addTest('Course: Open TOC: Discussions : NAV', self.db)
        self.addTest('Discussions: Open Forum: NAV', self.db)
        self.addTest('Discussions: Open Forum Message Tree: NAV', self.db)
        self.addTest('Discussions: Open Forum Message: NAV', self.db)
        self.addTest('Discussions: Open Forum Reply: NAV', self.db)
        self.addTest('Discussions: Submit Forum Reply: TXN', self.db)
        self.addTest('Discussions: Open Create Thread: NAV', self.db)
        self.addTest('Discussions: Submit Create Thread: TXN', self.db)
        
        #ULTRA USE CASES
        self.addTest('Discussions: Submit Create Thread: TXN', self.db)
    def __call__(self):


        
        #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.db.bblearn.coursePks)==0:
            self.info("DbAction(): User is not enrolled in any courses, skipping...")
            return
        
        #If ULTRA
        #if self.db.bblearn.isUltra == True:
        #    #Nothing for now as assessments are not supported in Ultra
        #    self.getTest('Discussions: Submit Create Thread: TXN').openUltraDiscussion()
        #    self.getTest('Discussions: Submit Create Thread: TXN').startUltraAssignments()
        #    self.getTest('Discussions: Submit Create Thread: TXN').submitUltraAssignments()
        #    return
            
        #TODO - Test to see if the Discussion board link exist
        if not self.db.dbCourseTOCExist():
            self.info("DbAction(): No Discussion Board Table of Content Link found in course, skipping...")
            return

        #Only move on if we  find a discussion board 
        self.getTest('Course: Open TOC: Discussions : NAV').openDbCourseTOC()
        self.db.openDbCourseTOCCheck()
        self.sleep("navigational")
            
        #Check to ensure that the user has dbs in courses before proceeding
        if len(self.db.bblearn.dbForumUrls)==0:
            self.info("DbAction(): No available discussion board forums found in this course:"+self.db.bblearn.coursePk+", skipping")
            return
        
                        # ULTRA SUPPORT
        #if self.db.bblearn.isUltra:
        #    self.getTest('Discussions: Open Forum: NAV').openUltraDiscussionForum()
        #    self.getTest('Discussions: Open Forum: NAV').openUltraMessage()
        #    self.getTest('Discussions: Open Forum: NAV').openUltraMessageReplies()
        #    self.getTest('Discussions: Open Forum: NAV').submitUltraReply()
        #    return
        
        self.db.openDbForumLogic()
        self.getTest('Discussions: Open Forum: NAV').openDbForum()
        self.sleep("navigational")
        
        #Perform the db extracts here instead of in the openMessage method
        self.db.extractDBinfo()
            

        #Control the number of iterations by changing the value of the range. 
        for x in range(self.distributionPercentage("DbAction.OpenMessageIteration")):
        
            self.db.openMessageLogic()
            if self.db.initialLoad:
                self.getTest('Discussions: Open Forum Message Tree: NAV').openMessageTree()
            self.getTest('Discussions: Open Forum Message: NAV').openMessage()
            self.sleep("navigational")
            
            #If there is no messages available, and the student is allowed to create a thread, we create the thread
            if len(self.db.createThreadUrl)>0 and len(self.db.msgPks)==0:
                self.info("DbAction(): no messages found. Student is allowed to create a new thread, creating thread...") 
                self.getTest('Discussions: Open Create Thread: NAV').openCreateThread()
                self.sleep("navigational")
                
                #only perform the reply the logic section ended correctly
                if self.db.isSubmitReply:
                    self.getTest('Discussions: Submit Create Thread: TXN').submitCreateThread()
                    self.sleep("navigational")
                    
        #Random percentage selector, returns true 5% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("DbAction.OpenCreateForumPercentage")) and len(self.db.createThreadUrl)>0:
            self.getTest('Discussions: Open Create Thread: NAV').openCreateThread()
            self.sleep("navigational")
            self.db.submitReplyLogic("thread")
            
            #only perform the reply the logic section ended correctly
            if self.db.isSubmitReply:
                self.getTest('Discussions: Submit Create Thread: TXN').submitReply()
                self.db.extractMsgPk()
                self.sleep("navigational")  
                
        #Random percentage selector, returns true 20% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("DbAction.SubmitForumReplyPercentage")):
            if self.db.currentMessagePk !="":
                self.getTest('Discussions: Open Forum Reply: NAV').openReply()
                self.sleep("navigational")
                self.db.submitReplyLogic("reply")
                if self.db.isSubmitReply:
                    self.getTest('Discussions: Submit Forum Reply: TXN').submitReply()
                    self.sleep("navigational")
            else:
                self.info("DbAction(): User does not have any discussionboard messages nothing to reply to, skipping...")
        
        #Cleanup - Not sure if necessary, but what the hell
        self.db.reset()