# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from scripts.course import Course
import actions.base
import utils.random 
import config.settings
import utils.baconLoremIpsum
import utils.uploadFiles



numSubFolderLevelsToMap = config.settings.numSubFolderLevelsToMap

class CourseAction(actions.base.Base):
    
    def __init__(self, request,offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.course = Course(self.request, bblearn)
        self.addTest('Portal: Open Courses Tab: NAV',self.course)
        self.addTest('Portal: Load Courses Tab Modules: NAV',self.course)
        self.addTest('Course: Open Course: NAV',self.course)
        self.addTest('Course: Load Course Modules: NAV',self.course)
        self.addTest('Course: Map Tools TOC Menu Items: NAV',self.course)
        self.addTest('Course: Map Contents TOC Menu Items: NAV',self.course)
        self.addTest('Course: Map Contents TOC Sub Folders: NAV',self.course)
        
        #ULTRA USE CASES
        self.addTest('Course: Open Ultra Course Stream: NAV',self.course)
        self.addTest('Course: Open Ultra Course: NAV',self.course)
    def __call__(self,mapCourseTOCFlag,mapCourseTOCOverride=False):
    
        #For initial mapping, we should iterate through each course and 
        if config.settings.initialCourseMapping:
            for coursePk in self.course.bblearn.coursePks:
                self.info("CourseAction(): Mapping course pk: " + coursePk)
                self.openCourse(100,mapCourseTOCFlag,mapCourseTOCOverride,coursePk)
            return
        #ULTRA USE CASES
        if self.course.bblearn.isUltra:
            self.getTest('Course: Open Ultra Course Stream: NAV').openUltraCourseStream()
            self.getTest('Course: Open Ultra Course: NAV').openCourse()
        else:
            #From here we should open the course tab 25% of the time and course 100% of the time
            self.openCourseTab(25)
            #Check to ensure that the user is enrolled in courses before proceeding
            if len(self.course.bblearn.coursePks)==0:
                self.info("CourseAction(): Did not find any enrolled in any courses on the portal page, checking the course tab...")
                self.openCourseTab(100)
            
            self.openCourse(100,mapCourseTOCFlag,mapCourseTOCOverride)

    def openCourseTab(self,percentage=5):
        #Check to ensure that the course tab exist, otherwise we just move on. 
        if self.course.bblearn.courseTabPk=="":
            self.info("CourseAction(): Course Tab not found, skipping...")
            return 
        
        #ULTRA Support, currently we don't do anything special for ULTRA so we just return here
        if self.course.bblearn.isUltra:
            return
        #Random percentage selector, returns true 10% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(percentage):

            self.getTest('Portal: Open Courses Tab: NAV').openCoursesTab()
            self.getTest('Portal: Load Courses Tab Modules: NAV').loadCoursesTabModules()
            self.sleep("navigational")

    
    def openCourse(self,percentage=10,mapCourseTOCFlag=False,mapCourseTOCOverride=False,coursePk = ""):
    

        #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.course.bblearn.coursePks)==0:
            self.info("CourseAction(): User is not enrolled in any courses, skipping the rest of the use cases...")
            return
        
        #ULTRA Support, currently we don't do anything special for ULTRA so we just return here
        if self.course.bblearn.isUltra == True:
            return    
        #Random percentage selector, returns true 10% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(percentage):

            #For initial mapping, no need to open the course if it's already been mapped 
            if config.settings.initialCourseMapping:
                #If we can load the course contents from a previous run, no need to re-map
                if self.course.bblearn.loadBbLearnCourseObjectFromCoursePk(coursePk):
                    self.info("CourseAction(): Course Pk1: "+ coursePk + " is already mapped, skipping...")
                    return
                    
            #otherwise we just open the course
            if(self.getTest('Course: Open Course: NAV').openCourse(coursePk)!=False):
                #set the course TOC mapping mode, override if sent in
                self.course.bblearn.setCourseTocMode(mapCourseTOCOverride)
                
                self.getTest('Course: Load Course Modules: NAV').loadCourseModules()
                self.sleep("navigational")
                
                #If we can load the course contents from a previous run, no need to re-map
                if self.course.bblearn.loadBbLearnCourseObjectFromCoursePk(self.course.bblearn.coursePk):
                    return
                    

                #we only need to map the course toc for students, should be set to False for Instructors
                if mapCourseTOCFlag == True and self.course.bblearn.courseTOCModeIsMap:
                
                    if self.course.bblearn.isUserInstructorInCurrentCourse:
                        self.info("CourseAction(): User is an instructor, not mapping the course, skipping...")
                        return
                    #Iterate through the course content table of content urls
                    for index in range(len(self.course.bblearn.courseContentTOCUrls)):
                        #Map the Course Content
                        self.info("CourseAction.openCourse(): Mapping the course CONTENT table of content")
                        
                        self.getTest('Course: Map Contents TOC Menu Items: NAV').mapCourseTOC("content",index)
                        self.sleep("navigational")

                        count = 1
                        #Check to see if there were subfolders
                        while len(self.course.currentLevelFolders)>0:
                            
                            self.info("CourseAction.openCourse(): Searching " + str(count)+ " levels down..")
                            #Initialize the variable to hold a list of folders the next level down
                            self.course.foldersoneleveldown = []
                            for index in range(len(self.course.currentLevelFolders)):
                                self.getTest('Course: Map Contents TOC Sub Folders: NAV').mapSubFolder(index)
                                self.sleep("navigational")

                            #If we found subfolders in the subfolders, we want to set those to be the new subfolders so that the loop keeps going
                            self.course.setSubFolder()
                            
                            #Determines how many levels down we search, otherwise we break out of the loop
                            if count == numSubFolderLevelsToMap:
                                self.info("CourseAction.openCourse(): Reached the "+ str(count)+" sub folder search level down, breaking out of loop...")
                                break
                            
                            count+=1
                    

                    for index in range(len(self.course.bblearn.courseToolsTOCUrls)):
                        #Map the Course Tools
                        self.info("CourseAction.openCourse(): Mapping the course TOOLs table of content")
                    
                        self.getTest('Course: Map Tools TOC Menu Items: NAV').mapCourseTOC("tool",index)
                        self.sleep("navigational") 
                        
                    #Then we save the mapped data
                    self.course.bblearn.saveBbLearnCourseObject()
                else:
                    
                    self.info("CourseAction.openCourse(): CourseTOCMode: " +config.settings.courseTOCMode +". Not mapping the course toc. ")
        else:
            self.debug("CourseAction.openCourse(): Randomly not selected to open the course")

class CourseNavigationAction(actions.base.Base):
    
    def __init__(self, request, offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.course = Course(self.request,bblearn)
        for target in config.settings.courseToolTOCTargets:
            self.addTest('Course: Open TOC: '+target+' : NAV',self.course)
        
        
    
    def __call__(self):


        #Check to ensure that the user is enrolled in courses before proceeding 
        if len(self.course.bblearn.coursePks)==0:
            self.info("CourseAction(): User is not enrolled in any courses, skipping...")
            return
       
        #Then we randomly decide to select 50% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("CourseNavigationAction.OpenNavigationTargetPercentage")):
            
            #We open up the course navigation 3 times by default, this can be tweaked
            for x in range(self.distributionPercentage("CourseNavigationAction.OpenNavigationTargetIterations")):
                
                
                #Randomly select an available target from the list
                target = utils.random.randomlySelectValueFromList(config.settings.courseToolTOCTargets)
                
                self.info("CourseNavigationAction(): The current course navigation target is \""+target+"\"")
                if self.course.courseTOCTargetExist(target):
                    #Open the target
                    self.getTest('Course: Open TOC: '+target+' : NAV').courseTOCMenuItems(target)
                    self.sleep("navigational")

    



