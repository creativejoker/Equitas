# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Random JavaScript traffic. This accounts for a good deal of the overall traffic
import actions.base
from net.grinder.plugin.http import HTTPRequest
from utils.parameters import ListParameter
import utils.random

class StaticContentAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        # No test. This is just background noise
        self.bblearn = bblearn
      
        self.addTest('Static Content: Java Script: STC', self)
        self.addTest('Static Content: CSS: STC', self)
        self.addTest('Static Content: Images: STC', self)

    def __call__(self):

        #Control the number of iterations by changing the value of the range. 
        #By default it loops through 20 times
        for x in range(self.distributionPercentage("StaticContentAction.Iterations")):
            if utils.random.randomlySelectPercentOfTime(self.distributionPercentage("StaticContentAction.JSPercentage")):
            
                jsTargetUrl = utils.random.randomlySelectValueFromList(self.bblearn.js)
                
                if self.request.isTargetValid(jsTargetUrl):
                    self.getTest('Static Content: Java Script: STC').getContent(jsTargetUrl)
            elif utils.random.randomlySelectPercentOfTime(self.distributionPercentage("StaticContentAction.CSSPercentage")):

                cssTargetUrl=utils.random.randomlySelectValueFromList(self.bblearn.css)
                
                if self.request.isTargetValid(cssTargetUrl):
                    self.getTest('Static Content: CSS: STC').getContent(cssTargetUrl)
            else:
            
                imgTargetUrl=utils.random.randomlySelectValueFromList(self.bblearn.img)
                
                if self.request.isTargetValid(imgTargetUrl):
                    self.getTest('Static Content: Images: STC').getContent(imgTargetUrl)
                
                
            self.sleep("staticcontent")
        self.sleep("navigational")


    # Also bypass the current (logging) GET method to avoid
    # cluttering the logs
    def getContent(self, target):
        HTTPRequest.GET(self.request, target)
    


