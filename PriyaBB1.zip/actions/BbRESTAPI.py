# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard wiki navigation
from net.grinder.script.Grinder import grinder
from scripts.BbRESTAPI import BbRESTAPIService
import actions.base
import utils.random
import config.settings

class BbRESTAPIAction(actions.base.Base):
    
    def __init__(self, request, offset,userList,initialOAuth2BearerToken):
        actions.base.Base.__init__(self, request, offset)
        self.bbRESTAPIService = BbRESTAPIService(self.request,userList,initialOAuth2BearerToken)
        self.addTest('Bb RESTAPI: OAuth2AccessToken(): NAV', self.bbRESTAPIService)
        self.addTest('Bb RESTAPI: GetAnnouncements(): NAV', self.bbRESTAPIService)
        self.addTest('Bb RESTAPI: GetCourseMembershipsByUser(): NAV', self.bbRESTAPIService)
        self.addTest('Bb RESTAPI: GetGradesByUser(): NAV', self.bbRESTAPIService)
        self.addTest('Bb RESTAPI: GetGradebookColumnsByCourse(): NAV', self.bbRESTAPIService)
        self.addTest('Bb RESTAPI: GetGradebookColumnsByCourse(): NAV', self.bbRESTAPIService)
        self.addTest('Bb RESTAPI: getGradebookColumnAttemptsByCourseAndColumnId(): NAV', self.bbRESTAPIService)
        
    def __call__(self):
        
        #Check to see if we've reached the rate limit previously, if so we fail the current test since there's nothing to do
        if self.bbRESTAPIService.rateLimitReached:
            self.info("BbRESTAPIAction(): Rate Limit Reached, skipping")
            return
            
        #First step is to get the OAuth2 Token
        if self.bbRESTAPIService.isOAuth2AccessTokenValid()==False:
            if self.getTest('Bb RESTAPI: OAuth2AccessToken(): NAV').GetOAuth2AccessToken()==False:
                return #No valid sessionId found, we can't continue
       
        #Next we load the course enrollments for that user
        if self.getTest('Bb RESTAPI: GetCourseMembershipsByUser(): NAV').getUserCourseEnrollments()== False:
            if self.bbRESTAPIService.rateLimitReached:
                self.info("BbRESTAPIAction(): Rate Limit Reached, skipping")
            elif len(self.bbRESTAPIService.coursePks)==0:
                self.info("BbRESTAPIAction(): User does not have any courses, skipping")
            return
        #Load the gradebook for that user, we also load by the course   
        self.getTest('Bb RESTAPI: GetGradesByUser(): NAV').getGradeByUserId()
        self.getTest('Bb RESTAPI: GetGradebookColumnsByCourse(): NAV').getGradebookColumnByCourse()
        self.bbRESTAPIService.getGradebookColumnByCourseLogic()
        
        if len(self.bbRESTAPIService.gradebookColumnPks)==0:
            self.info("BbRESTAPIAction(): Course does not have any gradebook columns, skipping")
            return
        #for id in self.bbRESTAPIService.gradebookColumnPks:
        #    self.getTest('Bb RESTAPI: getGradebookColumnAttemptsByCourseAndColumnId(): NAV').getGradebookColumnAttemptsByCourseAndColumnId(id)
        