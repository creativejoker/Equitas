# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from scripts.announcement import Announcement
import actions.base
import utils.random 


class AnnouncementAction(actions.base.Base):
    
    def __init__(self, request,offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.courseAction = actions.course.CourseAction(request, 25, bblearn)
        self.ast = Announcement(self.request, bblearn)
        self.addTest('Course: Open Announcement TOC: NAV', self.ast)
        self.addTest('Announcement: Open: NAV', self.ast)   
        self.addTest('Announcement: Open Create: NAV', self.ast) 
        self.addTest('Announcement: Submit: TXN', self.ast) 
    def __call__(self):

        

        #Randomly decides to re-open the course tab and course. Delegates the open course tab and opening of the course to the course class.
        #If it opens the course again, it will randomly select a course to open from the list of courses available.
        #By default, it opens the course tab 5% of the time and the course 10% of the time. This is on top of the initial course load after logging into the application
        self.courseAction.openCourseTab()
        self.courseAction.openCourse()
    
        #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.ast.bblearn.coursePks)==0:
            self.info("AnnouncementAction(): User is not enrolled in any courses, skipping...")
            return
            

        #Open the Assignment Course Table of contents, if this returns false then we don't need to go further as there are no Announcement available
        
        self.getTest('Announcement: Open: NAV').openAnnouncementsCourseTOC()
        
        self.getTest('Announcement: Open Create: NAV').openAnnouncementCreate()
            
        if self.ast.submitAnnouncementLogic():
            self.getTest('Announcement: Submit: TXN').submitAnnouncement()

            
