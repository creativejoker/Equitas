# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard course content navigation

from scripts.course import Course
from scripts.assessment import Assessment
import actions.base

class ContentAction(actions.base.Base):
    
    def __init__(self, request,offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.course = Course(self.request, bblearn)
        self.courseAction = actions.course.CourseAction(request, 25, bblearn)
        self.addTest('Course: Open TOC: Content : NAV', self.course)
        self.addTest('Content: Open Content Subfolder: NAV', self.course)
        self.addTest('Content: Open Document: CNT', self.course)

    def __call__(self):

        #Randomly decides to re-open the course tab and course. Delegates the open course tab and opening of the course to the course class.
        #If it opens the course again, it will randomly select a course to open from the list of courses available.
        #By default, it opens the course tab 5% of the time and the course 10% of the time. This is on top of the initial course load after logging into the application
        self.courseAction.openCourseTab()
        self.courseAction.openCourse()
        
        #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.course.bblearn.coursePks)==0:
            self.info("ContentAction(): User is not enrolled in any courses, skipping...")
            return
        #Check to ensure that the user has course content in courses before proceeding
        if len(self.course.bblearn.courseContentTOCUrls)==0:
            self.info("Course.openCourseContentTOCItem(): No course content table of contents found in this course:"+self.course.bblearn.coursePk+", skipping")
            return
            
        if(self.getTest('Course: Open TOC: Content : NAV').openCourseContentTOCItem()!=False):
            self.sleep("navigational")
            
            #Perform the course folder/content extraction here
            self.course.currentLevelFolders = self.course.bblearn.extractBbLearnCourseContentFromTOC(self.course.lastPage)
            
            #Open a Sub folder, if available
            if len(self.course.currentLevelFolders)>0:
                self.getTest('Content: Open Content Subfolder: NAV').openSubfolder()
                self.sleep("navigational")
            else:
                self.info("Course.openSubfolder(): No sub folders found on this page...skipping")
            
            #OPEN A FILE if available
            if len(self.course.bblearn.fileUrls)>0:
                self.getTest('Content: Open Document: CNT').openDocument()
                self.sleep("navigational")
            else:
                self.info("Course.openDocument(): No content items found in  this course: "+self.course.bblearn.coursePk+", skipping")