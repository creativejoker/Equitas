# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard wiki navigation
from net.grinder.script.Grinder import grinder
from scripts.wiki import Wiki
import actions.base
import utils.random

class WikiAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.courseAction = actions.course.CourseAction(request, 25, bblearn)
        self.wiki = Wiki(self.request, bblearn)
        self.addTest('Course: Open TOC: Wikis : NAV', self.wiki)
        self.addTest('Wiki: Open: NAV', self.wiki) 
        self.addTest('Wiki: Open Page: NAV', self.wiki)      
        self.addTest('Wiki: Open Create Page: NAV', self.wiki)
        self.addTest('Wiki: Submit Create Page: TXN', self.wiki)
        self.addTest('Wiki: Open Edit Page: NAV', self.wiki)
        self.addTest('Wiki: Submit Edit Page: TXN', self.wiki)
        self.addTest('Wiki: Comment Page: NAV', self.wiki)


    def __call__(self):

        
        #Else if CLASSIC  
        
        #Randomly decides to re-open the course tab and course. Delegates the open course tab and opening of the course to the course class.
        #If it opens the course again, it will randomly select a course to open from the list of courses available.
        #By default, it opens the course tab 5% of the time and the course 10% of the time. This is on top of the initial course load after logging into the application
        self.courseAction.openCourseTab()
        self.courseAction.openCourse()
        
        #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.wiki.bblearn.coursePks)==0:
            self.info("WikiAction(): User is not enrolled in any courses, skipping...")
            return
        
        #If ULTRA, do nothing
        if self.wiki.bblearn.isUltra:
            #Nothing for now as assessments are not supported in Ultra
            self.info("WikiAction(): Wikis are not supported in Ultra")
            return
            
        #Check to see if we have a wiki course TOC before proceeding
        if not self.wiki.wikiCourseTOCExist():
            self.info("WikiAction(): No Wiki Table of Content Link found in course, skipping...")
            return
        
        #Open Wiki Table of contents
        self.getTest('Course: Open TOC: Wikis : NAV').openWikisCourseTOC()
        self.wiki.openWikisCourseTOCCheck()
        self.sleep("navigational")
        
        #Check to ensure that the user has wikis pages before proceeding
        if len(self.wiki.bblearn.wikiPageUrls)==0:
            self.info("WikiAction(): User does not have any wiki pages in the wiki list, skipping...")
            return
        
        #Open the Wiki
        self.wiki.openWikiLogic()
        self.getTest('Wiki: Open: NAV').openWiki()
        self.wiki.openWikiCheck()
        self.sleep("navigational")
        
        #If No Pages exist for this Wiki, create the home page
        if self.wiki.createHomePage:
            if self.wiki.submitWikiPageLogic("false"):
                self.getTest('Wiki: Submit Create Page: TXN').submitWikiPage()
            
            self.wiki.openWikiLogic()
            self.getTest('Wiki: Open: NAV').openWiki()
            self.wiki.openWikiCheck()
        
        #Open the wiki pages is tweakable
        for x in range(self.distributionPercentage("WikiAction.OpenWikiIterations")):
            if self.wiki.openWikiPageLogic():
                self.getTest('Wiki: Open Page: NAV').openWikiPage()
                self.sleep("navigational")
        
        #Random percentage selector, returns true 10% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("WikiAction.SubmitWikiPercentage")):
            self.info("WikiAction(): Opening create wiki page.")
            self.getTest('Wiki: Open Create Page: NAV').openCreateWikiPage()
            self.sleep("navigational")
            self.wiki.submitWikiPageLogic("false")
            self.getTest('Wiki: Submit Create Page: TXN').submitWikiPage()
            self.sleep("navigational")
            
        #Random percentage selector, returns true 5% of the time. 
        #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("WikiAction.SubmitEditWikiPercentage")):
            if self.wiki.openEditWikiPageExist():
                self.getTest('Wiki: Open Edit Page: NAV').openEditWikiPage()
                self.sleep("navigational")
            
                if self.wiki.submitWikiPageLogic("true"):
                    self.getTest('Wiki: Submit Edit Page: TXN').submitWikiPage()
                    self.sleep("navigational")
        
        #Cleanup - Not sure if necessary, but what the hell
        self.wiki.reset()
        