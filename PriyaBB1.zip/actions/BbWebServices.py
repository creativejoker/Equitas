# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard wiki navigation
from net.grinder.script.Grinder import grinder
from scripts.BbSoapWebServices import BbSoapWebServices
import actions.base
import utils.random

class BbSoapWebServicesAction(actions.base.Base):
    
    def __init__(self, request, offset):
        actions.base.Base.__init__(self, request, offset)
        self.bbSoapWebService = BbSoapWebServices(self.request)
        self.addTest('Bb WS: Context.initialize(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: Context.loginTool(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: Context.extendSessionLife(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: User.getUser(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: Context.getMemberships(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: Course.getCourse(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: Announcement.getCourseAnnouncements(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: Content.getFilteredContent(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: Content.getContentFiles(): NAV', self.bbSoapWebService)
        self.addTest('Bb WS: Gradebook.getGradebookColumns(): NAV', self.bbSoapWebService)

        
    def __call__(self):

        #First step is to initialize the web service
        if self.getTest('Bb WS: Context.initialize(): NAV').initialize() == False:
            return #No valid sessionId found, we can't continue
       
        #Then we login the tool 
        if self.getTest('Bb WS: Context.loginTool(): NAV').loginTool()== False:
            return#Tool Login not successful, we can't continue
        self.getTest('Bb WS: Context.extendSessionLife(): NAV').extendSessionLife()
        
        #Load User, course, and memberships based on a randomly selected userid from our test bed
        if self.getTest('Bb WS: User.getUser(): NAV').getUser() == False:
            return # user not found
        
        if self.getTest('Bb WS: Context.getMemberships(): NAV').getMemberships() == False:
            return #no course memberships found
        self.getTest('Bb WS: Course.getCourse(): NAV').getCourse()
        self.sleep("navigational")
        
        #Get Announcements
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("BbSoapWebServicesAction.OpenAnnouncementPercentage")):
            self.getTest('Bb WS: Announcement.getCourseAnnouncements(): NAV').getCourseAnnouncements()
        self.sleep("navigational")
        
        #Get Content
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("BbSoapWebServicesAction.OpenContentPercentage")):
            for x in range(self.distributionPercentage("BbSoapWebServicesAction.OpenContentIterations")):
                self.getTest('Bb WS: Content.getFilteredContent(): NAV').getFilteredContent(self.bbSoapWebService.contentPk)
            self.getTest('Bb WS: Content.getContentFiles(): NAV').getContentFiles()
        self.sleep("navigational")
        
        #Get Gradebook
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("BbSoapWebServicesAction.OpenGradePercentage")):
            self.getTest('Bb WS: Gradebook.getGradebookColumns(): NAV').getGradebookColumns()
            
        self.sleep("navigational")