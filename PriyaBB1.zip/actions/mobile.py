# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard course navigation

from scripts.mobile import Bbmobile
import actions.base
from net.grinder.script.Grinder import grinder
import utils

class mobileAction(actions.base.Base):

    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.mobile=Bbmobile(self.request, bblearn)
        self.addTest('Bb Mobile: Ping: MOB',self.mobile)
        self.addTest('Bb Mobile: SSL User Login: MOB',self.mobile)
        self.addTest('Bb Mobile: Load Enrolled Courses: MOB',self.mobile)
        self.addTest('Bb Mobile: Load Enrolled Orgs: MOB',self.mobile)
        self.addTest('Bb Mobile: Get Settings: MOB',self.mobile)
        self.addTest('Bb Mobile: Load Course Info: MOB',self.mobile)
        self.addTest('Bb Mobile: Load Whats New: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Announcements: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Assignment Item: MOB',self.mobile)
        self.addTest('Bb Mobile: Submit Assignment Item: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Content Item: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Content Folder: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Assessment: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Blogs: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Discussion Board: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Discussion Board Thread: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Discussion Board Post: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Discussion Board Post Reply: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Journals: MOB',self.mobile)
        self.addTest('Bb Mobile: Open Tasks: MOB',self.mobile)
        self.addTest('Bb Mobile: Open My Grades: MOB',self.mobile)

    def __call__(self):

        #self.getTest('Bb Mobile: SSL User Login: MOB').sslUserLogin()
        
        #If this is the first time around, this shouldn't matter but subsequent launches should be avoided
        if self.mobile.isMobileDisabled:
            self.info("MobileAction(): Mobile B2 is not enabled, skipping...")
            return
        #Load the enrolled courses for the user
        self.getTest('Bb Mobile: Load Enrolled Courses: MOB').loadCourseEnrollments()
        self.coursePks = self.mobile.loadCoursesExtract()
        
        self.info("MobileAction(): User enrolled in " + str(len(self.coursePks)) + " Mobile courses")
        
        if self.mobile.isMobileDisabled:
            self.info("MobileAction(): Mobile B2 is not enabled, skipping...")
            return
            
        self.sleep("navigational")
        #so 50% of the time we're going to pretend that we're the Bb student append
        
        # Performing a ping
        self.getTest('Bb Mobile: Ping: MOB').mobilePing()
        
        #TODO - This is currently not implemented, will need to look at this further
        #self.mobile.isBbStudentApp = utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.IsStudentAppPercentage"))
        
        
        #Check to see if have anything before moving on. 
        if len(self.coursePks)==0:
            self.info("MobileAction(): User is not enrolled in any mobile courses or orgs...skipping")
            return
            
        #For each course, we load what's new
        for coursePk in self.coursePks:
            self.getTest('Bb Mobile: Load Whats New: MOB').loadWhatsNew(coursePk)
        

        #############################
        #Open Course        
        # Randomly select a course to enter
        coursePk=utils.random.randomlySelectValueFromList(self.coursePks)

        # Make Bb Mobile Settings Request- DCHOW 10/29/2018 - as of 3400 and Bb Student version 3.10.0 this doesn't appear to be used anymore
        #self.getTest('Bb Mobile: Get Settings: MOB').getSettings()
        #self.sleep("navigational")

        # Make various requests against randomly selected course
        self.getTest('Bb Mobile: Load Course Info: MOB').loadCourseInfo(coursePk)
        self.mobile.loadCourseExtract()
        self.sleep("navigational")

        
        
        #############################
        #Announcement
        #DCHOW 10/29/2018 - in 3.10.0 there doesn't appear to be an actual call when announcement button gets clicked. 
        self.getTest('Bb Mobile: Open Announcements: MOB').openAnnouncements(coursePk)
        self.sleep("navigational")
        
        #############################
        #Content
        
        #If there are content folders, we should pick a folder to randomly open. 
        if len(self.mobile.contentFolderIds)>0:
            self.info("BbMobileAction(): Randomly Opening Content Folders "+str(self.distributionPercentage("mobileAction.OpenContentFolderPercentage"))+"% of the time:")
            for contentFolderId in self.mobile.contentFolderIds:
                self.info("CONTENT FOLDER ID:" + contentFolderId)
                if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.OpenContentFolderPercentage")):
                    self.getTest('Bb Mobile: Open Content Folder: MOB').openContentFolder(coursePk)
                    self.sleep("navigational")
                
                #Once we open that folder, we should then check to see if there's any content items underneath it that should be opened. 
                if len(self.mobile.contentItemIds)>0:
                    self.info("BbMobileAction(): Randomly Opening Content Items "+str(self.distributionPercentage("mobileAction.OpenContentPercentage"))+"% of the time:")
                    for contentItemId in self.mobile.contentItemIds:
                        
                        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.OpenContentPercentage")):
                            self.getTest('Bb Mobile: Open Content Item: MOB').openContentItem(coursePk, contentItemId)
                            self.sleep("navigational")
        else:
            self.info("BbMobileAction(): No content folders found in "+coursePk+", skipping use cases...")
            
#        #############################
#        #Assignments

#        if len(self.mobile.assignmentURLs)>0:
#            self.info("BbMobileAction(): Randomly Assignments "+str(self.distributionPercentage("mobileAction.OpenAssignmentPercentage"))+"% of the time:")
#             
#             for assignmentURL in self.mobile.assignmentURLs:
#                    self.info("Assignment URL:" + assignmentURL)
#                    self.getTest('Bb Mobile: Open Assignment Item: MOB').openAssignment(coursePk, assignmentURL)
#                
#                #self.getTest('Bb Mobile: Submit Assignment Item: MOB').submitAssignment(coursePk)
                
        #############################
        #Assessments
        if len(self.mobile.assessmentIdsXML)>0:
            self.info("BbMobileAction(): Randomly Opening Assessments "+str(self.distributionPercentage("mobileAction.OpenAssessmentPercentage"))+"% of the time:")
            for assessmentIdXML in self.mobile.assessmentIdsXML:
                if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.OpenAssessmentPercentage")):
                    contentId = utils.parse.extractOnce(assessmentIdXML, 'content_id=_', '[0-9]+', '_1',False)
                    assessmentId = utils.parse.extractOnce(assessmentIdXML, 'linktarget="_', '[0-9]+', '_1',False)
                    
                    if contentId != "" and assessmentId !="":
                        self.getTest('Bb Mobile: Open Assessment: MOB').openAssessment(coursePk,contentId,assessmentId)
                        self.sleep("navigational")
                    else:
                        self.info("MobileAction(): ContentId and/or AssessmentId not found in XML:" + assessmentIdXML)
        else:
            self.info("BbMobileAction(): No assessment found in "+coursePk+", skipping use cases...")
        ##############################
        #Discussion Board
        self.getTest('Bb Mobile: Open Discussion Board: MOB').openDiscBoard(coursePk)
        self.sleep("navigational")
        if len(self.mobile.dbForumIds)>0:
            self.info("BbMobileAction(): Randomly Opening Discussion Board Forums "+str(self.distributionPercentage("mobileAction.OpenDBPercentage"))+"% of the time:")
            for forumId in self.mobile.dbForumIds:
                if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.OpenDBPercentage")):
                    self.getTest('Bb Mobile: Open Discussion Board Thread: MOB').openDiscThread(coursePk, forumId)
                    self.mobile.openDiscThreadExtract()
                    self.sleep("navigational")

                    #if there are mobile threads, then we open one of them up, and post a reply
                    if len(self.mobile.dbThreadIds)>0:
                        self.info("BbMobileAction(): Randomly Opening Discussion Board Post "+str(self.distributionPercentage("mobileAction.SubmitDBPercentage"))+"% of the time:")
                        for threadId in self.mobile.dbThreadIds:
                            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.SubmitDBPercentage")):
                                self.getTest('Bb Mobile: Open Discussion Board Post: MOB').openDiscPost(coursePk, threadId)
                                self.sleep("navigational")
                                self.getTest('Bb Mobile: Open Discussion Board Post Reply: MOB').openDiscPostReply(coursePk ,forumId ,threadId)
                                self.sleep("navigational")
        else:
            self.info("BbMobileAction(): No Discussion Board found in "+coursePk+", skipping use cases...")
        ##############################
        #Blogs
        if(len(self.mobile.blogURLs) > 0):
            self.info("BbMobileAction(): Randomly Opening Blogs "+str(self.distributionPercentage("mobileAction.OpenBlogsPercentage"))+"% of the time:")
            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.OpenBlogsPercentage")):
                
                self.getTest('Bb Mobile: Open Blogs: MOB').openBlogs(coursePk)
                self.sleep("navigational")
        else:
            self.info("BbMobileAction(): No Blogs found in coursePk: "+coursePk+", skipping use cases...") 
        
        ##############################
        #Journals
        if(len(self.mobile.journalURLs) > 0):
            self.info("BbMobileAction(): Randomly Opening Journals "+str(self.distributionPercentage("mobileAction.OpenJournalsPercentage"))+"% of the time:")
            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.OpenJournalsPercentage")):                        
                self.getTest('Bb Mobile: Open Journals: MOB').openJournals(coursePk)
                self.sleep("navigational")
        else:
            self.info("BbMobileAction(): No Journals found in coursePk: "+coursePk+", skipping use cases...") 
            
        ##############################
        #Tasks 

        if(len(self.mobile.taskURLs) > 0):
            self.info("BbMobileAction(): Randomly Opening Tasks "+str(self.distributionPercentage("mobileAction.OpenTasksPercentage"))+"% of the time:")        
            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.OpenTasksPercentage")):
                self.getTest('Bb Mobile: Open Tasks: MOB').openTasks(coursePk)
                self.sleep("navigational")
        else:
            self.info("BbMobileAction(): No Tasks found in coursePk: "+coursePk+", skipping use cases...")     
        
        ##############################
        #MyGrades

        self.info("BbMobileAction(): Randomly Opening MyGrades "+str(self.distributionPercentage("mobileAction.OpenJournalsPercentage"))+"% of the time:")        
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("mobileAction.OpenMyGradesPercentage")):
            self.getTest('Bb Mobile: Open My Grades: MOB').openMyGrades(coursePk)
            self.sleep("navigational")
