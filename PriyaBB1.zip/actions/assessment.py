# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

# Standard assessment navigation



from scripts.assessment import Assessment
from net.grinder.script.Grinder import grinder
from java.lang import String
import actions.base
import utils.rampup
import utils.random


class AssessmentAction(actions.base.Base):
    
    def __init__(self, request,offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.courseAction = actions.course.CourseAction(request, 25, bblearn)
        self.ast = Assessment(self.request, bblearn)
        self.addTest('Course: Open TOC: Assessments : NAV', self.ast)
        self.addTest('Assessment: Open: NAV', self.ast)
        self.addTest('Assessment: Launch: NAV', self.ast)
        self.addTest('Assessment: Launch New Attempt: NAV', self.ast) 
        self.addTest('Assessment: Launch with Password: NAV', self.ast)         
        self.addTest('Assessment: Save: TXN', self.ast)
        self.addTest('Assessment: Submit: TXN', self.ast)
        self.addTest('Assessment: Open Submitted Redirect: NAV',self.ast)
        self.addTest('Assessment: Review: NAV', self.ast)
    def __call__(self):


            
        #Randomly decides to re-open the course tab and course. Delegates the open course tab and opening of the course to the course class.
        #If it opens the course again, it will randomly select a course to open from the list of courses available.
        #By default, it opens the course tab 5% of the time and the course 10% of the time. This is on top of the initial course load after logging into the application
        self.courseAction.openCourseTab()
        self.courseAction.openCourse()
        
        #If ULTRA, do nothing
        if self.ast.bblearn.isUltra:
            #Nothing for now as assessments are not supported in Ultra
            self.info("AssessmentAction(): Assessments are not supported in Ultra")
            return
            
        #Check to ensure that the user is enrolled in courses before proceeding
        if len(self.ast.bblearn.coursePks)==0:
            self.info("AssessmentAction(): User is not enrolled in any courses, skipping...")
            return
    
            
        ################################################################################################### 
        # CONCURRENT TESTING
        # 
        # All grinder threads will pause if the specified file exist. Threads will resume once the file has been removed. 
        # By default, it only waits if the file EXIST. Therefore, this is backwards compatible with the existing scripts.
        # FILE: String of name of the file to check for. 
        # TIME: Amount of time in milliseconds to waitutils.rampup.waitForFile() takes two arguments. The name of the file to check for in order to pause the next test and the amount of time to wait(in milliseconds) till it checks again. 
        # 
        # USAGE Example:
        #       utils.rampup.waitForFile("STARTTEST",180000)
        # 
        # Checks for the existence of a file named "STARTTEST" in the grinder home directory. 
        # If the "STARTTEST" file IS found, all grinder threads will wait till that file is deleted to actually start the test. Otherwise if no file is found, the test will continue
        # To create the file/concurrent wait, execute the command "touch STARTTEST" in the home directory. This will cause the threads to queue up and wait
        # To remove the file/concurrent start the test, execute the command "rm STARTTEST" in the home directory. This will cause the threads to submit the test
        ###################################################################################################            
        
        #CONCURRENT TESTING - OPTIONAL
        #Checks for the "STARTTEST" file in the grinder home directory. If it IS FOUND, then the test waits 3 minutes. Otherwise, it continues..
        #Use for concurrent testing
        #utils.rampup.waitForFile("STARTTEST",180000)
        
    
        if not self.ast.astCourseTOCExist():
            self.info("AssessmentAction(): No Assessment Table of Content Link found in course, skipping...")
            return
            
        #Only proceed if there are assessments available
        self.getTest('Course: Open TOC: Assessments : NAV').openAssessmentCourseTOC()
        self.ast.openAssessmentCourseTOCCheck()
        self.sleep("navigational")
        
        #Check to ensure that the user has assessment in courses before proceeding
        if len(self.ast.bblearn.assessmentUrls)==0:
            self.info("AssessmentAction(): No assessments found in this course:"+self.ast.bblearn.coursePk+", skipping")
            return
        
        #Open Assessment
        self.ast.openAssessmentLogic()
        self.getTest('Assessment: Open: NAV').openAssessment()
        self.sleep("navigational")
            
            
        #Launch Assessment
        self.ast.launchAssessmentLogic()
        if self.ast.assessmentLaunchUrl =="":
            self.info("AssessmentAction(): No assessments URL found in this assessment:"+self.ast.bblearn.coursePk+", skipping")
            return
            
        self.getTest('Assessment: Launch: NAV').launchAssessment()
        self.ast.launchAssessmentCheck()
        if self.ast.isNewAttempt:
            self.getTest('Assessment: Launch New Attempt: NAV').launchAssessmentNewAttempt()
            self.ast.launchAssessmentCheck()
        if self.ast.isPasswordProtected:
            self.getTest('Assessment: Launch with Password: NAV').launchAssessmentWithPassword()
        self.ast.launchAssessmentExtract()
        self.sleep("navigational")
            
         
        #Check to see the number of assessments and then save all of the questions 
        count=self.ast.getCurrentQuestionNumber()
        #Get the total number of questions per assessment
        questions=self.ast.getTotalNumberofQuestions()
    
        #Check to see if there are attempts and a count available, if not there are no more attempts to take. 
        if questions==0 and self.ast.takeAgain =="":
            self.info("AssessmentAction(): No assessment attempts to take,skipping...")
            return
        if count is None:
            self.info("AssessmentAction(): Count is not available,skipping...")
            return
            
        while(count<=questions):
            self.info("AssessmentAction(): count: "+str(count) + " of "+str(questions)+" question")
            #Remove the following to save every questions.  Adjust to save a percentage of questions
            if utils.random.randomlySelectPercentOfTime(self.distributionPercentage("AssessmentAction.SaveAAOPercentage")) and self.ast.testPresentationOption=="AAO":
                if self.ast.saveAssessmentLogic(count):
                    self.getTest('Assessment: Save: TXN').saveAssessment()
                
            #We save each question in a QBQ since the assumption is that a student will answer each question.
            elif self.ast.testPresentationOption=="QBQ":
                if self.ast.saveAssessmentLogic(count):
                    self.getTest('Assessment: Save: TXN').saveAssessment()
                
            self.sleep("navigational") 
            count+=1
        
        self.info("AssessmentAction(): Breaking save while loop, submitting the test")
        
        #CONCURRENT TESTING - OPTIONAL
        #Checks for the "SUBMITTEST" file in the grinder home directory. If it IS FOUND, then the test waits for 3 minutes. Otherwise, it continues..
        #Use for concurrent testing
        #utils.rampup.waitForFile("SUBMITTEST",180000)
        
        #only perform the submit if the logic section ended correctly, subtract one from the count
        if self.ast.submitAssessmentLogic(count-1):
            self.getTest('Assessment: Submit: TXN').submitAssessment()
            if self.ast.submitAssessmentCheck():
                self.getTest('Assessment: Open Submitted Redirect: NAV').openAssessmentSubmitted()
        self.sleep("navigational")
        self.getTest('Assessment: Review: NAV').reviewAssessment()
        self.sleep("navigational")
        
        #Cleanup - Not sure if necessary, but what the hell
        self.ast.reset()