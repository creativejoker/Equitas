# Standard Admin

import config.settings
import scenarios.base
from scripts.admin import UserSearch
import utils.parse
import utils.random
from scripts.admin import CourseSearch
import actions.base

class CourseSearchAction(actions.base.Base):
    
    def __init__(self, request, offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.adminCourseSearch = CourseSearch(self.request,bblearn)
        self.addTest('Admin: Open Course Search',self.adminCourseSearch)
        self.addTest('Admin: Submit Course Search',self.adminCourseSearch)
        
        
    def __call__(self):

    
        #to slow things down so this is not too active, adding some sleeps for 60 seconds
        self.info("AdminCourseSearchAction(): Opening Course Search "+str(self.distributionPercentage("AdminCourseSearchAction.openCourseSearchPercentage"))+ " percent of the time...")
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("AdminCourseSearchAction.openCourseSearchPercentage")):
            #to slow things down so this is not too active, adding some sleeps for 60 seconds
            #self.sleep("view_grades")  
            
            self.getTest('Admin: Open Course Search').openCourseSearch()
            self.sleep("navigational")

            self.info("AdminCourseSearchAction(): Submitting Course Search "+str(self.distributionPercentage("AdminCourseSearchAction.submitCourseSearchPercentage"))+ " percent of the time...")
            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("AdminCourseSearchAction.submitCourseSearchPercentage")):
                self.adminCourseSearch.openCourseSearchLogic()
                self.getTest('Admin: Submit Course Search').submitCourseSearch()
                self.sleep("transactional")
                
              
class UserSearchAction(actions.base.Base):
    
    def __init__(self, request, offset,bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.adminUserSearch = UserSearch(self.request,bblearn)
        self.addTest('Admin: Open User Search',self.adminUserSearch)
        self.addTest('Admin: Submit User Search',self.adminUserSearch)
        
        
    def __call__(self):


        #to slow things down so this is not too active, adding some sleeps for 60 seconds
        #self.sleep("view_grades")  
        self.info("AdminUserSearchAction(): Opening User Search "+str(self.distributionPercentage("UserSearchAction.openUserSearchPercentage"))+ " percent of the time...")
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("UserSearchAction.openUserSearchPercentage")):
            #to slow things down so this is not too active, adding some sleeps for 60 seconds
            #self.sleep("view_grades")  
            
            self.getTest('Admin: Open User Search').openUserSearch()
            self.sleep("navigational")

            self.info("UserSearchAction(): Submitting User Search "+str(self.distributionPercentage("UserSearchAction.submitUserSearchPercentage"))+ " percent of the time...")
            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("UserSearchAction.submitUserSearchPercentage")):
                self.adminUserSearch.openUserSearchLogic()
                self.getTest('Admin: Submit User Search').submitUserSearch()
                self.sleep("transactional")