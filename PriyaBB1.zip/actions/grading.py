# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from scripts.grade import StudentGrade
from scripts.grade import InstructorGrade
from net.grinder.script.Grinder import grinder
import actions.base
import utils.random

class InstructorGradingAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.grade = InstructorGrade(self.request,bblearn)
        self.addTest('Grade Center: Open: NAV', self.grade )
        self.addTest('Grade Center: Open Grade: NAV', self.grade )
        self.addTest('Grade Center: Submit Grade: TXN', self.grade )
        self.addTest('Grade Center: Open Download Gradebook: NAV', self.grade )
        self.addTest('Grade Center: Submit Download Gradebook: TXN', self.grade )
        self.addTest('Grade Center: Download Gradebook: CNT', self.grade )
        self.addTest('Grade Center: Open Box Assignment Grade Details : NAV', self.grade )
        self.addTest('Grade Center: Open Grade Box Assignment : NAV', self.grade )
        self.addTest('Grade Center: Spell Checker: TXN', self.grade )
        self.addTest('Grade Center: Submit Grade Box Assignment: TXN', self.grade )
        
    def __call__(self):
    
        #Only proceed if the user is enrolled in a course
        if len(self.grade.bblearn.coursePk)==0:
            self.info("InstructorGradingAction(): User is not enrolled in any courses, no gradebooks to open, skipping")
            return
            
        ##Only proceed if the user is enrolled in a course
        if self.grade.chooseInstructorGradeCenter():
            self.getTest('Grade Center: Open: NAV').openInstructorGradeCenter()
            self.sleep("navigational")
            
            #Only proceed if there are gradebook items
            if self.grade.chooseGradebookItem():
                self.getTest('Grade Center: Open Grade: NAV').openGradebookItem()
                self.sleep("navigational")
                #Random percentage selector, returns true 20% of the time. 
                #You can tweak the percentages for calibration. It takes an integer 1-100 for 1-100% of the time
                if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("InstructorGradingAction.gradeSubmissionPercentage")):
                    self.grade.chooseSubmitGradebookItem()
                    self.getTest('Grade Center: Submit Grade: TXN').submitGradebookItem()
                    self.sleep("navigational")
            
            #Grade BOX assignments
            #if we have assignment gradebook items we can proceeed
            if len(self.grade.assignmentGbItems)>0:
            
                #Randomly select the percentage of times that this use cases will execute
                self.info("InstructorGradingAction(): Opening BOX assignment for grading "+str(self.distributionPercentage("InstructorGradingAction.openBoxAssignmentPercentage"))+ " percent of the time...")
                if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("InstructorGradingAction.openBoxAssignmentPercentage")):
                    
                    #Open the gradebook item page for the assignment
                    self.getTest('Grade Center: Open Box Assignment Grade Details : NAV').openGradebookItem(self.grade.assignmentGbItems)
                    
                    #If there is an assignment attempt available that we can grade, we try to open that box assignment for grading. 
                    if self.grade.openBoxAssignmentForGradingCheck():
                        self.getTest('Grade Center: Open Grade Box Assignment : NAV').openBoxAssignmentForGrading()
                        
                        #Check to see if there is an assignment form, if we don't have one we should just return as the previous page was not an assignment page or didn't provide us a form. 
                        if self.grade.submitAssignmentGradeForm =="":
                            self.info("Grade.submitBoxAssignmentGradeLogic(): no assignment grade form found, skipping" )
                            return
                            
                        #Then we do some spell check request as these would be sent when the text is typed into the vtbe
                        for x in  range(self.distributionPercentage("InstructorGradingAction.spellCheckIterations")):
                            self.getTest('Grade Center: Spell Checker: TXN').spellChecker()
                            
                        #Finally we submit the assignment
                        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("InstructorGradingAction.submitBoxAssignmentPercentage")):
                            self.getTest('Grade Center: Submit Grade Box Assignment: TXN').submitBoxAssignmentGrade()
            
                #self.getTest('Grade Center: Open Box Assignment: NAV').openBoxAssignmentForGrading()
            #Gradebook Download
            self.info("InstructorGradingAction(): Downloading gradebook "+str(self.distributionPercentage("InstructorGradingAction.downloadGradebookPercentage"))+ " percent of the time...")
            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("InstructorGradingAction.downloadGradebookPercentage")):
                self.getTest('Grade Center: Open Download Gradebook: NAV').openGradebookDownload()
                if self.grade.submitGradebookDownloadLogic():
                    self.getTest('Grade Center: Submit Download Gradebook: TXN').submitGradebookDownload()
                    
                    if self.grade.downloadGradebookDownloadLogic():
                        self.getTest('Grade Center: Download Gradebook: CNT').downloadGradebookDownload() 
                        
            
class StudentGradeAction(actions.base.Base):
    
    def __init__(self, request, offset, bblearn):
        actions.base.Base.__init__(self, request, offset)
        self.grade = StudentGrade(self.request,bblearn)
        self.addTest('Course: Open Course My Grade: NAV', self.grade )
        self.addTest('Course: Review My Grade Item: NAV', self.grade )
        
    def __call__(self):
        
        #Only proceed if the user is enrolled in a course
        if len(self.grade.bblearn.coursePk)==0:
            self.info("StudentGradeAction(): User is not enrolled in any courses, no gradebooks to open, skipping")
            return
            
            
        #Only proceed if the user is enrolled in a course
        #We execute this use case 25% of the time
        if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("StudentGradeAction.openCourseGradePercentage")):
            self.getTest('Course: Open Course My Grade: NAV').openCourseMyGrades()
            self.sleep("navigational")
            
            #If they successfully open the my courses page, then we randomly decide to review grade items
            if  utils.random.randomlySelectPercentOfTime(self.distributionPercentage("StudentGradeAction.openReviewGradePercentage")):
                for x in range(self.distributionPercentage("StudentGradeAction.openReviewGradeIteration")):
                    self.grade.reviewGradeItemLogic()
                    
                    #Check to ensure that there are gradeable items before proceeding
                    if self.grade.isGradeItemAvailable:
                        self.getTest('Course: Review My Grade Item: NAV').reviewGradeItem()
                        self.sleep("navigational")
        
        self.grade.reset()
