# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

import config.settings
from net.grinder.script.Grinder import grinder
from net.grinder.script import Test
import utils.logging


class Base:
    def __init__(self, request, offset):
        self.request  = request
        self.tests={}
        self.testOffset=offset
        
        # A shorter alias for the grinder.logger.info() method.
        self.info = utils.logging.info
        self.debug = utils.logging.checkDebugAndLog
        self.warn = utils.logging.warn
        self.error = utils.logging.error
        self.infoAndError=utils.logging.infoAndError
        #self.courseTOCMode = config.settings.courseTOCMode
        
    def sleep(self, type):
        grinder.sleep(config.settings.thinkTime[type])
    
    def distributionPercentage(self, type):
        return config.settings.distributionPercentages[type]
        
    def addTest(self, name, object):
        #testCount=len(config.settings.tests)
        #config.settings.tests[name]= Test(testCount, name).wrap(object)
        self.tests[name]= Test(self.testOffset, name).wrap(object)
        self.testOffset = self.testOffset + 1
        
    def getTest(self, name):
        #return config.settings.tests[name]
        return self.tests[name]
    
    def getTestCount(self, name):
        #return config.settings.tests[name]
        return len(self.tests)
    

    # Make sure to define this for the test to run
    # def __call__(self):
