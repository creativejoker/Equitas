#!/bin/bash

#
# Edited by marcus.uy@blackboard.com
#

source common_autoq.sh $*

#Get jobs
JOBS="$(find $CONF_QUEUE -maxdepth 1 -type f | sort)"

for JOB in $JOBS
do
  parse_config $JOB

	echo "Job::$JOB::$CONFSTATUS"

  if [ "$CONFSTATUS" == "OK" ]
  then
    MAXUSERPROC_CURRENT="$(ulimit -u)"
    MAXUSERPROC_ESTIMATE=$(echo "scale=0; (($PROCESSES_STUDENT * $THREADS_STUDENT) + ($PROCESSES_INSTRUCTOR * $THREADS_INSTRUCTOR)) * $MAXUSERPROC_FACTOR" | bc)

    if [ "$MAXUSERPROC_CURRENT" -gt "$MAXUSERPROC_ESTIMATE" ]; then
      echo "You are likely to be within process limits: $MAXUSERPROC_CURRENT (Available) / $MAXUSERPROC_ESTIMATE (Required)"
      echo "Safety factor: $MAXUSERPROC_FACTOR"
      echo ""
    else
      echo "You MAY EXCEED process limits if you proceed: $MAXUSERPROC_CURRENT (Available) / $MAXUSERPROC_ESTIMATE (Required)"
      echo "Safety factor: $MAXUSERPROC_FACTOR"
      echo ""
    fi
  fi
done

exit 0
