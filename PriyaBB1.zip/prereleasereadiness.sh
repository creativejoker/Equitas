#!/bin/bash
#Quick script to prep the release readiness directory to execute the test

cd /home/bbperf/clients/release_readiness/

#Copy over the queue files
cp -r queue/release_readiness/* queue/

#Update the settings.py to use the environments that we want to use
#3000.1.6-rel.258+e3b6890
sed -i "s/'https:\/\/app00.example.com'/'https:\/\/csub2integrationqa11.blackboard.com'/g" config/settings.py
#3100.0.6-rel.3+cd2a24d 
sed -i "s/'https:\/\/app01.example.com'/'https:\/\/csub2integrationqa8.blackboard.com'/g" config/settings.py
#3200.0.5-rel.6+3dd6b56 
sed -i "s/'https:\/\/app02.example.com'/'https:\/\/csub2integrationqa16.blackboard.com'/g" config/settings.py
#3300.0.1-rel.37+c07f12a
sed -i "s/'https:\/\/app03.example.com'/'https:\/\/csub2integrationqa15.blackboard.com'/g" config/settings.py
#3400.0.4-rel.68+a1c490e
sed -i "s/'https:\/\/app04.example.com'/'https:\/\/csub2integrationqa13.blackboard.com'/g" config/settings.py

#set the instructor and user to just use the first user and to remove the trailing zeros
sed -i "s/\"instructor%09lu\", 1, 240)/\"perfinstructor%09lu\", 1, 10)/g" config/settings.py
sed -i "s/\"user%09lu\", 1, 7000)/\"perfuser%09lu\", 1, 10)/g" config/settings.py



#add the correct directory for autoq
sed -i "s/#cd \/home\/bbperf\/performance\/mainline/cd \/home\/bbperf\/clients\/release_readiness/g" autoq.sh

#Set the email to be dchow for everything
sed -i "s/root\@localhost/dchow\@blackboard.com/g" *.sh

perl prepEnvironment.pl