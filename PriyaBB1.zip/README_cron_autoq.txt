Instructions for scheduling autoq.sh to run under crontab.
Edit user and paths as appropriate.

edit crontab with crontab -e (as bbperf)

<mm> <hh> <dd> <MM> <day of week> cd /home/bbperf/performance/mainline && ./autoq.sh >> /home/bbperf/performance/mainline/cronjob.log 2>&1

cron a small job, and check cronjob.log for errors

in autoq.sh add the following at the top of the script if $PATH is not set the same in cron as in your shell (likely)
export PATH=<additions>:$PATH