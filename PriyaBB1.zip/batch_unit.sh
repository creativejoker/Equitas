#!/bin/sh

# Keep 1 previous log file in case we forget to grab it before replay analysis
if [ -f course_data.db ]; then
  echo "Sorting course_contents" 
#  sort -u  course_data.db -o course_data.db
fi
#Cleans everything out
rm -fr */*.class
rm -fr */*.out
#Reset Threads/Processes
sed -i "s/grinder.processes=[[:digit:]]*/grinder.processes=1/g" *.properties 
sed -i "s/grinder.threads=[[:digit:]]*/grinder.threads=1/g" *.properties 
sed -i "s/grinder.duration=[[:digit:]]*/grinder.duration=300000/g" *.properties
sed -i "s/grinder.runs=[[:digit:]]*/grinder.runs=1/g" *.properties

export GRINDER_HOME=./grinder-3.10
export JAVA_HOME=/usr/local/java

#java -cp "$(pwd):$GRINDER_HOME/lib/grinder.jar" net.grinder.Grinder instructor.properties
java -cp "$(pwd):$GRINDER_HOME/lib/grinder.jar" net.grinder.Grinder student.properties

#java -cp "$(pwd):$GRINDER_HOME/lib/grinder.jar" net.grinder.Grinder webservices.properties

#Set it back afterwards so that we don't forget
sed -i "s/grinder.runs=[[:digit:]]*/grinder.runs=0/g" *.properties