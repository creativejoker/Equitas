# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from java.io import File
import config.settings
import utils.logging
import utils.random
from java.lang import Runtime
from java.util import UUID



#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = grinder.logger.info
error = grinder.logger.error
debug = utils.logging.checkDebugAndLog

#specify the file and tmp directory location
absoluteFilesFolderPath = File(config.settings.filesPath)
absoluteFilesTmpFolderPath = File(config.settings.filesPath+"/tmp/")

#Config setting flags to randomize files and the mode
randomizeFiles = config.settings.randomizeUploadFiles
mode = config.settings.randomizeUploadFilesCreationMethod

#Method to remove the file after creating it or during batch tmp folder cleanup
def removeFile(file="",firstTime = False):

    #If randomize is turned on, then we need to remove the file
    if randomizeFiles == True:
    
        #IF we're in batch mode, then we don't do anything, except on the first time around if this is a bacth cleanup
        #TODO: Create a switch to remove it from the list so it can't be used again.
        
        if mode == "BATCH" and firstTime != True:
            return 
            #info("UploadFiles.removeFile(): BATCH Mode, removing the "+file+ " from the list of available tmp files.")
            #tmpFileNames.remove(file)
        
        #If the file is specified, then we want to delete that file
        if file!="":
            command = "rm -f " + file
        
        #Otherwise, we want to try to remove the whole tmp directory 
        else:
            #only if the abolute files tmp folder exist
            if len(absoluteFilesTmpFolderPath.getAbsolutePath())>0:
                command = "rm -f " + absoluteFilesTmpFolderPath.getAbsolutePath() +"/test_*"
        
        #Log and execute the command
        debug("UploadFiles.removeFile(): Executing the following command: " + command )
        Runtime.getRuntime().exec(command)
        
    #Otherwise, if we're not randomizing the files, then we don't want to remove the original files
    else:
        info("UploadFiles.removeFile(): config.settings.randomizeUploadFiles = False not deleting the file")

#Helper method to clean up the temp directory at the start of the test
def cleanTempDir():

    #If the temp directory exist and has files
    if absoluteFilesTmpFolderPath.isDirectory() and len(absoluteFilesTmpFolderPath.listFiles())>0:
        info("UploadFiles.cleanTempDir(): Cleaning the tmp directory ")
        #removeFile()
        
        #Iterate through all remove all of the files. We have to do it this way since rm -fr files/tmp/test_* isn't working for some reason
        for f in absoluteFilesTmpFolderPath.listFiles():
            removeFile(f.getAbsolutePath(),True)
        
#Helper method to load files from the config paths
#This should execute once for each grinder process
#Load the folder, we use java to do this since it's easier
def loadFilesFromConfigPath(folder = ""):
    files = []
    
       
    #If the tmp directory doesn't exist, we create it
    if absoluteFilesTmpFolderPath.isDirectory() == False:
        absoluteFilesTmpFolderPath.mkdirs() 
    
    #If this is in batch mode, then we need to wait here till the "BATCH" file is cleared. 
    # This ensures that the files have been created in the first grinder process before we try to load them
    if mode == "BATCH" and folder == absoluteFilesTmpFolderPath:
        #Added a max tries to so in case things to too long, we just keep going
        utils.rampup.waitForFile("BATCH",500, 100)
    
    #Loading the filesPath
    info("UploadFiles.loadFilesFromConfigPath(): Loading the files from the dir: \"" + folder.getAbsolutePath()+ "\"")
    
    #Check to make sure this is a directory
    if folder.isDirectory():
    
        #Check to ensure that there are files in the directory
        if len(folder.listFiles())>0:
            #Iterate through all of the files in the folder 
            for f in folder.listFiles():
            
                #Determine the file size
                floatFileSize = float(f.length())/1024/1024
                
                #If the file is a file and it's less than max size specified in the config.settings.maxFile, then we log and add it to the list
                if f.isFile() and  floatFileSize < config.settings.maxFileSize :
                    info("UploadFiles.loadFilesFromConfigPath(): File: \"" + str(f.getAbsolutePath()) + "\" Size: " + str(round(floatFileSize,2)) + " MB")
                    
                    #Append the file name, we don't want the absolute path since we have to build that later
                    files.append(f.getName())
        else:
            error("UploadFiles.loadFilesFromConfigPath(): Directory \"" + folder.getAbsolutePath()+ "\" is empty, no files to load.")
    else:
        error("UploadFiles.loadFilesFromConfigPath(): Directory \"" + folder.getAbsolutePath()+ "\" does not exist, can not load files.")
    
    info("UploadFiles.loadFilesFromConfigPath(): Loaded "+str(len(files))+" files from the dir: \"" + folder.getAbsolutePath()+ "\"")
    #Return the files to be used later
    return files
    

# Method Purpose: Returns the Absolute File Path for the files specified in the config.settings.filesPath that are less than the config.settings.maxFileSize
# Example: how to use in the code to grab file paths from the directory:
#       file = utils.uploadFiles.getRandomFile()
#       if len(file)==0:
#           self.info("Assignment.submitAssignment(): Random file is not available, skipping file upload" )
#           return
#           
#       self.info("Assignment.submitAssignment(): Selected file is: " +file)
#       files = ( NVPair("newFile_LocalFile0", file), )
#       
# Be a good citizen and call the cleanup of the file after you're done using it. Especially if this is a JIT, we need to clean up the files      
#       #Remove Random Temp file
#       utils.uploadFiles.removeFile(file)

def getRandomFile( batchCreate = False):

    
    #If the mode is "JIT" OR this is a the batch create call, we want to create random files
    if (randomizeFiles == True and mode == "JIT") or (randomizeFiles == True and batchCreate == True):
        
        #Check to see if we got any original files back. If there's nothing in the files/ directory, then we have nothing to randomize
        if len(fileNames)==0:
            info("UploadFiles.getRandomFile(): No Files to randomize, skipping..." )
            return
        
        #if we do have files, then let's randomly select one
        file=utils.random.randomlySelectValueFromList(fileNames)
        
        #Check to see if the file is valid to be randomized
        if file.find(".pdf") >0:
            #Then let's return the randomized temp file
            return randomizeFile(file)
        else:
            info("UploadFiles.getRandomFile(): "+file+" File type is not supported to be randomized. Currently only PDF is supported.")
            return absoluteFilesFolderPath.getAbsolutePath()+"/"+file
            
    #If the mode is "BATCH", then we just return from the list of the available batch tmp files
    elif randomizeFiles == True and mode == "BATCH":
        file = utils.random.randomlySelectValueFromList(tmpFileNames)
        if len(file) ==0:
            info("UploadFiles.getRandomFile(): No File available.")
            return False
        return absoluteFilesTmpFolderPath.getAbsolutePath()+"/"+file
    
    #If we're not randomizing the files, then we just return the original files underneath /files directory
    elif randomizeFiles == False:
        file = utils.random.randomlySelectValueFromList(fileNames)
        if len(file) ==0:
            info("UploadFiles.getRandomFile(): No File available.")
            return False
        return absoluteFilesFolderPath.getAbsolutePath()+"/"+file

        
#Helper method to randomize the files
def randomizeFile(file):

    # run file through exiftool to update Title and make unique to md5sum
    # Generate a random  alphanumeric string (uppercase)
    rand= str.upper(UUID.randomUUID().toString())

    # Original file
    absoluteCurrentFileName = absoluteFilesFolderPath.getAbsolutePath()+"/"+file
    # Target random tmp file to be created
    absoluteRandomizedFileName = absoluteFilesTmpFolderPath.getAbsolutePath()+"/test_"+rand+"_"+file


    debug("UploadFiles.randomizeFile(): Selected File: " + absoluteCurrentFileName)
    debug("UploadFiles.randomizeFile(): Randomized File: " + absoluteRandomizedFileName)
    
  
    #exiftool command to create new file with new Title metadata based on $rand (random 32bit string)
    command = "exiftool/exiftool -filename="+absoluteRandomizedFileName +" -Title=\""+rand+"\" "+absoluteCurrentFileName
    debug("UploadFiles.randomizeFile(): Executing the following command: " + command )
    Runtime.getRuntime().exec(command)
    
    #Check to ensure that the file exist before we move forward
    #Note this will add overhead
    checkIfExist(absoluteRandomizedFileName)
    
    #Return the randomized file
    return absoluteRandomizedFileName

#Helper method to check to see if the file exist
#While loop that executes till the file is created
def checkIfExist(file):

    #Create file object to check
    fileToCheck = File(file)
    maxCount=20
    count=0
    #Check to see if the file exist and is a file, if not found yet, sleep for 250 milliseconds
    while fileToCheck.exists() == False and fileToCheck.isFile() == False and count<maxCount:
        info("UploadFiles.checkIfExist(): Waiting for "+file+ " to be created, sleeping 250 milliseconds.")
        grinder.sleep(250)
        count +=1
        
    if count==20:
        info("UploadFiles.checkIfExist(): Reached maximumu number of tries for "+file+ " to be created, skipping...")
#Helper method to batch create the random tmp files
def BatchCreateRandomFiles():
    #Check to see that method is batch
    if mode == "BATCH" and randomizeFiles ==True:
    
       #Check to see if we got any original files back. If there's nothing in the files/ directory, then we have nothing to randomize
        if len(fileNames)==0:
            info("UploadFiles.getRandomFile(): No Files to randomize, skipping..." )
            Runtime.getRuntime().exec("rm -f BATCH")
            return
            
        # We only batch create for the first student grinder process
        if grinder.getProcessNumber() == 0 and grinder.getProperties().getProperty("grinder.script") =="scenarios/student.py":
            #command = "cp "+absoluteFilesFolderPath.getAbsolutePath()+"/test* " +absoluteFilesTmpFolderPath.getAbsolutePath()+"/"
            #info ("UploadFiles.BatchCreateRandomFiles(): Copying all original files to the temp directory "+ command)
            #Runtime.getRuntime().exec(command)
            
            info("UploadFiles.BatchCreateRandomFiles(): Batch creating "+str(config.settings.totalNumberOfRandomFiles)+" random files for upload")
            for x in range(config.settings.totalNumberOfRandomFiles):
                getRandomFile(True)
            

            #Once we're done with creating the tmp random files,
            # We remove the "BATCH" so that the other processes can then load the list of available tmp files
            Runtime.getRuntime().exec("rm -f BATCH")
    
####################################################################################
#This is the initial load of the data that occurs at the start test for each process

#If this is batch mode, then we need to create a file called "BATCH" so that all of the grinder processes wait for this file before continuing. 
#Removed requirement for it to be on the first process and student as it doesn't really matter if all processes create a batch file, it really just matter who removes the file
#which it should be the first process on the students side. 
#which it should be the first process on the students side. 
if mode == "BATCH" and randomizeFiles ==True:
    Runtime.getRuntime().exec("touch BATCH")

#We wait so that everyone can be at the same point
grinder.sleep(1000)
#Cleaning the Temp Directory  
cleanTempDir() 
#Load the global variable from the helper class
# Load the original files to be used to create the random files if randomized is turned on          
fileNames = loadFilesFromConfigPath(absoluteFilesFolderPath)

#Batch create the files. Only the first student grinder process will execute this code
if mode == "BATCH" and randomizeFiles ==True and  grinder.getProcessNumber() == 0 and grinder.getProperties().getProperty("grinder.script") =="scenarios/student.py":
    BatchCreateRandomFiles()

if mode == "BATCH" and randomizeFiles ==True:
#   Load the random tmp files
    tmpFileNames = loadFilesFromConfigPath(absoluteFilesTmpFolderPath)

