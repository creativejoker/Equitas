from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPRequest, HTTPPluginControl, HTTPPluginConnection
from HTTPClient import Cookie, CookieModule, CookiePolicyHandler
import utils.logging

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = grinder.logger.info
debug = utils.logging.checkDebugAndLog

# Set up a cookie handler to log all cookies that are sent and received.
class MyCookiePolicyHandler(CookiePolicyHandler):
    def acceptCookie(self, cookie, request, response):
        info("accept cookie: %s" % cookie)
        return 1
 
    def sendCookie(self, cookie, request):
        info("send cookie: %s" % cookie)
        return 1
 
CookieModule.setCookiePolicyHandler(MyCookiePolicyHandler())

def discardAllCookies():
     #HTTPPluginControl.getConnectionDefaults().setUseCookies(True)
    CookieModule.discardAllCookies()

def listAllCookies():
    threadContext = HTTPPluginControl.getThreadHTTPClientContext()
    cookies = CookieModule.listAllCookies(threadContext)
    #
    for c in cookies: 
        info("retrieved cookie: %s" % c)