from net.grinder.script.Grinder import grinder
from java.util import Random
from java.lang import String
from java.lang import Integer
from java.util import HashMap
from java.util import List
from java.io import File
import utils.logging
import utils
#import os.path
#from threading import Condition

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = utils.logging.info
error = utils.logging.error
debug = utils.logging.checkDebugAndLog
randomGenerator=Random()
loadedCoursePks = {}
savedCoursePks ={}


############################
#Function to load the information from the deployed content file
###########################

def loadDeployedCourseContents(file):


    #TODO FIX HASHMAP implementation so that it loads a collection of string of users. Right now it only takes the last enrollment right now
    map = HashMap()
    for line in file.readlines():
        courseObjectHashMap = HashMap()
        tempCourseObjectHashMap = HashMap()
        contentValueList = []
        tempContentValueList = []
        
        splitString =line.split('|')
        
        #Check to ensure that the line that we have coming in is the right length and clean up the bad lines
        if len(splitString)!=3:
            error("BbLearnDB.loadDeployedCourseContents(): Ignorning Bad line :" + line+ " in file: "+ file.name)
            continue
        
        
        contentValue = splitString[0].strip()
        coursePk=splitString[1].strip()
        courseObjectType=splitString[2].strip()

        #create a temporary hashmap of course content objects
        #if this is a course TOC object, then we need to keep it as a string
        if courseObjectType.count("courseTOCLinks")>0:
            tempCourseObjectHashMap.put(courseObjectType,contentValue)
        else:
            tempContentValueList.append(contentValue)
            tempCourseObjectHashMap.put(courseObjectType,tempContentValueList)
        
        #If the map has the course object, we want to extract it out
        if map.containsKey(coursePk):
            #Load the previous hashmap based on the course pk
            courseObjectHashMap=map.get(coursePk)
            
            #If the course hashmap contains the content Type key, then we update the list
            if courseObjectHashMap.containsKey(courseObjectType):
                #Load the list for that object type
                currentCourseObjectValueList = courseObjectHashMap.get(courseObjectType)
                #Append the current list
                #if this is a course TOC object, then we need to keep it as a string
                if courseObjectType.count("courseTOCLinks")>0:
                    courseObjectHashMap.put(courseObjectType,contentValue)
                else:
                    currentCourseObjectValueList.append(contentValue)
                    #Update the course hashmap
                    courseObjectHashMap.put(courseObjectType,currentCourseObjectValueList)
            #otherwise we use the value from the temp list created above
            else:
                            #if this is a course TOC object, then we need to keep it as a string
                if courseObjectType.count("courseTOCLinks")>0:
                    courseObjectHashMap.put(courseObjectType,contentValue)
                else:
                    courseObjectHashMap.put(courseObjectType,tempContentValueList)


                
            #put it back into the original map
            map.put(coursePk,courseObjectHashMap)
        else:

            map.put(coursePk,tempCourseObjectHashMap) 
           
        if not loadedCoursePks.has_key(coursePk):
            loadedCoursePks[coursePk] = coursePk
    
    return map

def loadLiveUsers(file):

    #TODO FIX HASHMAP implementation so that it loads a collection of string of users. Right now it only takes the last enrollment right now
    liveUsers = []
    for line in file.readlines():
        
        #Check to ensure that the line that we have coming in is the right length and clean up the bad lines
        if len(line)==0:
            error("BbLearnDB.loadDeployedCourseContents(): Ignorning Bad line :" + line+ " in file: "+ file.name)
            continue
        liveUsers.append(line.strip())


    return liveUsers

#def loadPortalData():
#
#    #TODO FIX HASHMAP implementation so that it loads a collection of string of users. Right now it only takes the last enrollment right now
#    #portalData = []
#    file=open('portalobjects.db','r+')
#    for line in file.readlines():
#        unicode_string = line.decode(u'utf-8') #
#
#
#    #return liveUsers


    
    
######################################################################
#LOAD USER AND COURSE DATA GLOBALLY SO THAT'S ONLY LOADED ONCE

#LOAD USER INFORMATION FROM FILE
dbLiveStudentUserFile="live_student_users.db"
dbLiveInstructorUserFile="live_instructor_users.db"

#LOAD COURSE CONTENT INFORMATION FROM FILE
dbCourseContentFiles="course_data.db"
########################################################################


########################################################################
#Open the file and load the data
#######################################
try:
    # Use java to check for the existence of the file\
    if File(dbCourseContentFiles).exists():
        courseContentFile = open(dbCourseContentFiles,'r+')
    else:
        info("BbLearnDb(): "+ dbCourseContentFiles+" does not exist, creating..")
        courseContentFile = open(dbCourseContentFiles,'a+')
    if File(dbLiveStudentUserFile).exists():
        liveStudentUsersFile = open(dbLiveStudentUserFile,'r+')
    else:
        info("BbLearnDb(): "+ dbLiveStudentUserFile+" does not exist, creating..")
        liveStudentUsersFile = open(dbLiveStudentUserFile,'a+')
    if File(dbLiveInstructorUserFile).exists():
        liveInstructorUsersFile = open(dbLiveInstructorUserFile,'r+')
    else:
        info("BbLearnDb(): "+ dbLiveInstructorUserFile+" does not exist, creating..")
        liveInstructorUsersFile = open(dbLiveInstructorUserFile,'a+')
        dbLiveInstructorUserFile
    # Read the lines into an array
    BbLearnLiveStudentUsersList =loadLiveUsers(liveStudentUsersFile)
    BbLearnLiveInstructorUsersList =loadLiveUsers(liveInstructorUsersFile)
    #loadPortalData()
    BbLearnDeployedCourseContentsHashMap=loadDeployedCourseContents(courseContentFile)
    info("BbLearnDb(): LOADING Course content objects from "+ Integer.toString(len(BbLearnDeployedCourseContentsHashMap))+" course from " + dbCourseContentFiles +" file")
    info("BbLearnDb(): LOADING "+ Integer.toString(len(BbLearnLiveStudentUsersList))+" users from " + dbLiveStudentUserFile +" file")
    info("BbLearnDb(): LOADING "+ Integer.toString(len(BbLearnLiveInstructorUsersList))+" users from " + dbLiveInstructorUserFile +" file")
except IOError:
    info("BbLearnDb(): UNABLE TO OPEN FILES.")
else:
    #Close the filename
    courseContentFile.close()
    liveStudentUsersFile.close()
    liveInstructorUsersFile.close()

#create a global list here so that each thread uses the same list
bbLearnLiveStudentUsersSequentialListParameter = utils.parameters.ListParameter("liveStudentUsers", "each","sequential",BbLearnLiveStudentUsersList)
bbLearnLiveStudentUsersRandomListParameter = utils.parameters.ListParameter("liveStudentUsers", "each","random",BbLearnLiveStudentUsersList)
#Instructors
bbLearnLiveInstructorUsersSequentialListParameter = utils.parameters.ListParameter("liveInsturctorUsers", "each","sequential",BbLearnLiveInstructorUsersList)
bbLearnLiveInstructorUsersRandomListParameter = utils.parameters.ListParameter("liveInsturctorUsers", "each","random",BbLearnLiveInstructorUsersList)
######################################################################
#Learn DB Class
class BbLearnDb:


    def __init__(self):


        self.formatedOutput = []
        self.loadedCoursePks = loadedCoursePks
        self.BbLearnDeployedCourseContentsHashMap = BbLearnDeployedCourseContentsHashMap


    #TODO
    #def savePortalObject(self,userPk, bblearnObject,objectName):
        #We should save the portal objects(Top Tabs, Sub Tabs, Tool Panes, Modules names) for each userPk
        #this will allow us to load this on each go around and we won't have to do the extraction each time. We can then also figure out the unique 
    def saveBblearnObject(self,coursePk, bblearnObject,objectName):
        
        if not self.isCourseContentObjectPreviouslySaved(coursePk,objectName) and len(bblearnObject)>0:
            
            self.formatCourseObjectOutput(coursePk,bblearnObject,objectName)
            self.writeBbLearnFile(dbCourseContentFiles)
            if isinstance(bblearnObject,basestring):
                info("BbLearnDb.saveBblearnObject(): Saved 1 " + objectName +" objects in course pk: " + coursePk)
            else:
                info("BbLearnDb.saveBblearnObject(): Saved "+str(len(bblearnObject))+" " + objectName +" objects in course pk: " + coursePk)
                
    def isCourseContentObjectPreviouslySaved(self,coursePk,objectName):
        if savedCoursePks.has_key(coursePk) and savedCoursePks[coursePk] == objectName:
            debug("BbLearnDb.checkIfCourseRecentlySaved(): Course PK: "+coursePk+" has previously been saved or the object "+objectName + " doesn't exist, not saving...")
            return True
        else:
            savedCoursePks[coursePk] = objectName
            debug("BbLearnDb.checkIfCourseRecentlySaved(): Course Object: "+objectName + " has not been saved, saving...")
            return False

        
    def writeBbLearnFile(self,file):
 
        try:
            #We append here instead of overwrite
            file = open(file,'a+')
            if len(self.formatedOutput)>0:
                for line in self.formatedOutput:
                    file.write(line)
            else:
                debug("BbLearnDb.writeBbLearnFile(): File format output is null, nothing to save..")
        finally:
            file.close()
            
    def formatCourseObjectOutput(self,coursePk,bblearnObject,objectName):
        self.formatedOutput = []
        if isinstance(bblearnObject,basestring):
            self.formatedOutput.append(bblearnObject+"|"+coursePk+"|"+objectName+"\r\n")
        elif len(bblearnObject)>1:
            for value in bblearnObject:
                self.formatedOutput.append(value+"|"+coursePk+"|"+objectName+"\r\n")
        elif len(bblearnObject)== 1:
            self.formatedOutput.append(bblearnObject[0]+"|"+coursePk+"|"+objectName+"\r\n")

            
        return self.formatedOutput
        

