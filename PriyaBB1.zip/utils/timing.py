# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
import utils.logging

trace = grinder.logger.trace

#Use Cases
# Inline Recipt page, Check for Success, 
# if successful, we log to output, if not we log to error
# Over all page, we look for 400 & 500 errors
# Bb Access denied page/

# Main Helper function that should be called from response.py
# Checks for HTTP 400-500 errors, that checks for any Bb Error page and that there was no error's in the inline receipt. 
# Logs the error message to the error logs
# response: HTTP response from POST/GET

def checkResponseForTime(response,responseTimeThresholdMilliSeconds =5000):
    #Check the url and don't check the 
    #If one fails, no need to check the rest
    responseTimeMilliSeconds = grinder.statistics.forCurrentTest.getTime()

    #if response time is over 1 second, log response
    if (responseTimeMilliSeconds > responseTimeThresholdMilliSeconds):
    #if (responseTimeMilliSeconds > 0):
        responseString = response.getEffectiveURI().toString()
        trace("," + str(responseTimeMilliSeconds) +","+ responseString)


        



