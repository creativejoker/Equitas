# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from java.util.regex import Pattern
from net.grinder.script.Grinder import grinder
from java.lang import String
import utils
import config
import utils.logging

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = grinder.logger.info
debug = utils.logging.checkDebugAndLog

#Use Cases
# Inline Recipt page, Check for Success, 
# if successful, we log to output, if not we log to error
# Over all page, we look for 400 & 500 errors
# Bb Access denied page/

# Main Helper function that should be called from response.py
# Checks for HTTP 400-500 errors, that checks for any Bb Error page and that there was no error's in the inline receipt. 
# Logs the error message to the error logs
# response: HTTP response from POST/GET

def checkResponseForErrors(response,target,data):
    #Check the url and don't check the 
    #If one fails, no need to check the rest

    #Check to see if this is webdav content download, if it is we don't want to check the response since a response.getText() will use up too much memory
    responseString = response.getEffectiveURI().toString()
    if responseString.find("/bbcswebdav/")>0:
        URI = responseString.split("/bbcswebdav/")
        info("Error.checkResponseForErrors(): Did not check the response of " + URI[1] +" due to possible memory issues")
        return
   
   #If one fails, no need to check the rest
    if(checkRawHTTPError(response,target,data)):
        return
    elif(checkBbError(response,target,data)):
        return
    elif(checkInlineReceipt(response,target,data)):
        return
    elif(printPostData(response,target,data)):
        return

        



# Helper function that checks the response of a http response for anything over a 400 error
# Logs the error message to the error logs and fails transaction if config.settings.failTestIfError = True
# response: HTTP response from POST/GET
# Target: URL from original request
# Data: Optional data from the POST
# Returns true or false

def checkRawHTTPError(response,target,data):
    failCheck = False
    #Checks to see if response code is equal to or greater than 400
    if response.getStatusCode()>=400:
        lastPage = response.getText()
        
        errorMessage=addHeaderErrorMessages(response,target)
        #Grab debugging information from the header and page
        #Log Error message to the error log
        #Build the Error Message
        errorMessage.append("Error Type: HTTP Error") 
        errorDescription = utils.parse.extractOnce(lastPage,'<b>description</b> <u>',"[^*]+?", '</u>')
        if errorDescription =="":
            errorDescription = utils.parse.extractOnce(lastPage,'<div id="bbNG.receiptTag.content',"[^*]+?", '</p>',False)
        exception = utils.parse.extractOnce(lastPage,'<b>exception</b> <pre>',"[^*]+?", '</pre>')
        rootCause = utils.parse.extractOnce(lastPage,'<b>root cause</b> <pre>',"[^*]+?", '</pre>')
        if exception !="":
            errorMessage.append("Exception: " + exception)
        if rootCause !="":
            errorMessage.append("Root Cause: " + rootCause)
        errorMessage=buildPostDataError(errorMessage,data)
        #Finally log and fail the test
        #If this is set to true, fail the transaction if there is an error. By default this should be set to O and only log errors. 
        #Any response >300 will still be marked as a failed transaction by the framework
        if config.settings.failTestIfError == True: 
            failTestAndLogError(errorMessage)
        else:
            #Otherwise just log the error
            logToError(errorMessage)
        failCheck = True
    return failCheck

# Helper function that checks the response for a Blackboard Error Page(which is normally wrapped in a HTTP 200)
#Checks for the following div tag the page
#    <div class="container  clearfix" id="containerdiv">
#    <h2 class="hideoff">Content</h2>
#    <div id="bbNG.receiptTag.content" tabindex="0">Resource not found.</br> 
#    </div><p><span class="receiptDate">Thursday, November 8, 2012 3:28:19 PM EST</span></p>
# Logs the error message to the error logs and fails transaction if config.settings.failTestIfError = True
# Response: HTTP response text from POST/GET
# Target: URL from original request
# Data: Optional data from the POST
# Returns true or false

def checkBbError(response,target,data):

    #If it's a bb error the following DIV tag will be in the response <div id="contentPanel" class="contentPaneWide error ok">
    #Not going to log the matching, since it's added to every request. Only log once we actually find an error
    error=utils.parse.extractOnce(response.getText(),"<div id=[^']+","error", ' ok">',False)

 
    if(error==""):
        return
        
    failCheck = False
    receiptForm=utils.parse.extractOnce(response.getText(),'<div id="bbNG.receiptTag.content',"[^*]+?", '</p>',False)
    if(receiptForm==""):
        return # No Error Form
    receipt=utils.parse.extractOnce(receiptForm,'tabindex="[0-9]+">',"[^']+", '</div>')
    if(receipt==""):
        return # No Error Receipt
    #Build the Error Message
    else:
        errorMessage=addHeaderErrorMessages(response,target)
        errorMessage.append("Error Type: Bb Page Error")
        errorMessage.append("Receipt Date: "+utils.parse.extractOnce(receiptForm,'receiptDate">',"[^']+", '</span>'))
        errorMessage.append("Description: "+receipt)
        errorMessage=buildPostDataError(errorMessage,data)
        failCheck = True
        #Finally log and fail the test
        if config.settings.failTestIfError == True: 
            failTestAndLogError(errorMessage)
        else:
            logToError(errorMessage)

    return failCheck

# Helper function that checks the inline receipt a Blackboard Page(which is normally wrapped in a HTTP 200)
# Checks for the following div tag on the page
#    <div id="inlineReceipt_good" class="receipt good">
#    <h3 class="hideoff">Success</h3>
#    <span tabindex="-1" id="goodMsg1">Success: Announcement created.</span><br>
#    <a class="close" href="#" title="Close" onClick="Element.remove($('inlineReceipt_good'));return false;"><img alt="Close" src="/images/ci/ng/close_mini.gif"/></a>
#    </div>
# Following options are available as of SP8
#     inlineReceipt_info,inlineReceipt_bad, inlineReceipt_warning,inlineReceipt_good
# Logs the info, warning, and good inline receipt message to the main output
# Logs the bad inline receipt message to the error logs and fails transaction if config.settings.failTestIfError = True
# Response: HTTP response text from POST/GET
# Target: URL from original request
# Data: Optional data from the POST
# Returns true or false

def checkInlineReceipt(response,target,data):


    failCheck = False
    #Not going to log the matching, since it's added to every request. Only log once we actually find an error
    inlineReceiptForm=utils.parse.extractOnce(response.getText(),'<div id="inlineReceipt',"[^*]+?", '</div>',False)
    if(inlineReceiptForm==""):
        return # No Inline Receipt
    
    inlineReceiptType=utils.parse.extractOnce(inlineReceiptForm,'_',"[a-zA-Z]+?", '"',False)
    inlineReceipt=utils.parse.extractOnce(inlineReceiptForm,"<span [^']+>","[^']+", '</span>',False)

    if(inlineReceipt=="" or inlineReceiptType==""):
        return # if empty, we don't want to do anything
    if(inlineReceiptType=="good" or inlineReceiptType=="info" or inlineReceiptType=="warning"):
        #No need to output the inline page target since it will be in the line above
        logToOutput(inlineReceiptType + " Page Inline Receipt:"+inlineReceipt)
    elif inlineReceiptType=="bad":
        errorMessage=addHeaderErrorMessages(response,target)
        errorMessage.append("Bb Inline Page Error: " + inlineReceiptType)
        errorMessage.append("Page Inline Receipt: "+ inlineReceipt)
        errorMessage=buildPostDataError(errorMessage,data)
        failCheck = True
        if config.settings.failTestIfError == True: 
            failTestAndLogError(errorMessage)
        else:
            logToError(errorMessage)

    
    return failCheck
    
    
# Helper function that checks the inline receipt a Blackboard login error(which is normally wrapped in a HTTP 200)
# Checks for the following div tag on the page
#      <div class="clearfix loginBody">
#        <!-- login/loginErrorMessage.vm -->
#<div id="loginErrorMessage" class="receipt bad editmode">Could not login. Valid authentication credentials were not provided.</div>
#<div id="loginBox">
#         <!-- login/authenticationProviderLoginForm.vm -->
# Logs the bad inline receipt message to the error logs and fails transaction if config.settings.failTestIfError = True
# Response: HTTP response text from POST/GET
# Target: URL from original request
# Data: Optional data from the POST
# Returns true or false

def checkLoginError(response,target,data):


    loginStatus = True
    loginFail = False
    #Not going to log the matching, since it's added to every request. Only log once we actually find an error
    lastPage = response.getText()

    #If we get the login page, it's possible that we failed and there isn't a custom login error. 
    #if lastPage.find('<input type="hidden" name="action" value="login" />')>0:
    if lastPage.find('/webapps/login/?action=relogin')>0 or lastPage.find('method="POST" action="/webapps/login/" NAME="login"') > 0:
        loginErrorReceipt = "Received the Login page again, user did not login correctly."
        loginFail = True
   
   
    #Catches the normal error message if the login page hasn't been modified
    #<div id="loginErrorMessage" class="receipt bad editmode alert-box alert" role="alert" data-alert>The&#x20;username&#x20;or&#x20;password&#x20;you&#x20;typed&#x20;is&#x20;incorrect.&#x20;Please&#x20;try&#x20;again.&#x20;If&#x20;you&#x20;still&#x20;cannot&#x20;log&#x20;in,&#x20;contact&#x20;your&#x20;system&#x20;administrator.</div>
    if lastPage.find("loginErrorMessage")>0:
        loginErrorReceipt=utils.parse.extractOnce(lastPage,'<div id="loginErrorMessage".+?>', '.+?', '<\/div>',False)
        loginErrorReceipt=loginErrorReceipt.replace("&#x20;"," ")
        loginFail = True
    
    if loginFail:
        errorMessage=addHeaderErrorMessages(response,target)
        errorMessage.append("Bb Login Page Error: " )
        errorMessage.append("Login Receipt: "+ loginErrorReceipt)
        errorMessage=buildPostDataError(errorMessage,data)
        loginStatus = False
        
        #Always log and fail test
        failTestAndLogError(errorMessage)
    
    return loginStatus

def checkToolPartnerErrors(response,target):


    #<div class="errorContainer">
    #  <p class="errorDetail">
    #    Error occurred while communicating with the Partner Cloud: 500 Internal Server Error<br/>
    #    
    #      (com.blackboard.partners.service.impl.RESTServiceFailureException: An error occurred during a GET request to /v1/cp/ws/GA1/proxy/context/tools/929e3a7d69502d7caa77422e5967e4584c114717fb379fd8?userId=f800e0adabe24ac79c73ae57ce608648&role=Instructor&toolType=COURSE_TOOL&locale=en_US.)
    #      <br/>
    #    </p>
    #</div>
    
    receipt = utils.parse.extractOnce(response.getText(),'class="errorDetail">',".+?", '</p>',False)
    if len(receipt)>0:
        errorMessage=addHeaderErrorMessages(response,target)
        errorMessage.append("Bb Partner Cloud Error: " + receipt.lstrip())
        failTestAndLogError(errorMessage)
        return True
    else:
        return False


# Helper function that takes the post data and prints it to the output log for debugging
# Data: data from the POST
# ErrorMessage: Array of error message data
# Returns errorMessage
# Logs the post data to the output logs if printPostDataToOutput = True or logDebugMessages = True
def printPostData(response,target,data=[]):


    if (config.settings.printPostDataToOutput == True or config.settings.logDebugMessages == True) and len(data)>0:
        errorMessage=addHeaderErrorMessages(response,target)
        errorMessage.append("Post Data: ")
        errorMessage=buildPostDataError(errorMessage,data)
        logToOutput(buildAndFormatErrorMessageText(errorMessage))


# Helper function that takes the post data and adds it to the array of error messages
# Data: data from the POST
# ErrorMessage: Array of error message data
# Returns errorMessage
def buildPostDataError(errorMessage, data=[]):
    
    if data is not None:
        if len(data)>0:
            for d in data:
                #To handle multipart forms, need to strip out the int objects
                if(isinstance(d,int) is False):
                    errorMessage.append(str(d))
    return errorMessage

# Helper function that takes the  HTTP response and builds the default error message. 
#    Below is an example error response. Only information deemed useful is extracted and added to the error message
#    HTTP/1.1 400 Bad Request
#    Content-Type: text/html;charset=utf-8
#    Connection: close
#    X-Blackboard-appserver: apcprd-313871-226477-app02.mhint
#    Date: Fri, 09 Nov 2012 05:16:08 GMT
#    Content-Length: 971
#    Server: Apache/1.3.41 (Unix) mod_ssl/2.8.31 OpenSSL/0.9.8n mod_jk/1.2.28
#    X-Blackboard-product: Blackboard Learn &#8482; 9.1.82223.0
# Response: HTTP response text from POST/GET
# Target: URL from original request
# Returns errorMessage
def addHeaderErrorMessages(response, target):
    #Reset the error messages
    errorMessage=[]
    #By default, we should always have these headers displayed in the error message
    errorMessage.append("Blackboard Target: " +target)
    if response.getEffectiveURI() is not None:
        errorMessage.append("Effective URI: " + response.getEffectiveURI().toString())
    if response.getStatusCode() is not None:
        errorMessage.append("HTTP Response Code: " + str(response.getStatusCode()) + " " + response.getReasonLine())
    if response.getHeader("Date")is not None:
        errorMessage.append("Date: " + response.getHeader("Date"))
    appServer=response.getHeader("X-Blackboard-appserver")
    errorId=response.getHeader("X-Blackboard-errorid")
    if errorId is not None:
        errorMessage.append("Blackboard Error Id: " +errorId)
    if appServer is not None:
        errorMessage.append("Blackboard App Server: " + appServer)
    return errorMessage
    
# Helper function that takes the array of error message data and builds a string of formated text. 
# ErrorMessage: Array of error message data
# Returns errorText
def buildAndFormatErrorMessageText(errorMessage,singleLine=False):
    
        #errorMessage=custom+"\ntarget: "+target+"\n "+response.toString()+"\n Error Description: " +description+"\n Error Exception: "+exception+"\n Error Root Cause: "+rootCause
    errorText="Error \n"
    
    if singleLine == True:
        errorText = errorMessage
    else:
        # iterate through and build the error message
        for e in errorMessage:
            errorText+=e+"\n"
    #Add an extra space at the end
    errorText+="\n"
    return errorText
    
# Helper function that searches the page for a pattern and logs an error message if not found.
# Usage from within another script/*.py location
#    1. Import error handling
#        import utils.error
#    2. Call from within a test case
#        utils.error.checkForPatternAndLogError(self.lastPage,"LTI Launch information","Submit submitUserPrivacyAcknowledgement: User Privacy Acknowledgement Not Successful")
# Logs the error message to the error logs and fails transaction if config.settings.failTestIfError = True
# Text: HTTP response text from POST/GET
# Pattern: String of text to match
# ErrorMessage: Text to be logged if pattern match is successful
# Debugging: HTTP response text is printed out if debug is on

def checkForPatternAndLogError(text,pattern,errorMessage,failTest=False,debugging=False):
        
        p = Pattern.compile('.*'+pattern+'.*', Pattern.DOTALL)
        m = p.matcher(String(text))
        if debugging:
            errorMessage = errorMessage + "\nOriginal Response: "+text
        if not m.matches():
            #If this is set to true, fail the transaction if there is an error. By default this should be set to O and only log errors. 
            #Any response >300 will still be marked as a failed transaction by the framework
            if config.settings.failTestIfError == True or failTest:
                failTestAndLogError(errorMessage, True)
            else:
                logToError(errorMessage,True)
            return True
        else:
            return False
                # Helper function that searches the page for a pattern, logs an error message, and fails test if found.
# Usage from within another script/*.py location
#    1. Import error handling
#        import utils.error
#    2. Call from within a test case
#        utils.error.checkForPatternAndFailTest(self.lastPage,"LTI Launch information","Submit submitUserPrivacyAcknowledgement: User Privacy Acknowledgement Not Successful")
# Logs the error message to the error logs and fails transaction even if config.settings.failTestIfError = False
# Text: HTTP response text from POST/GET
# Pattern: UString of text to match
# ErrorMessage: Text to be logged if pattern match is successful
# Debugging: HTTP response text is printed out if debug is on
def checkForPatternAndFailTest(text,pattern,errorMessage,debugging=False):

    return checkForPatternAndLogError(text,pattern,errorMessage,True,debugging)

# Helper function that takes fails the transaction and logs the error message to the error log. 
# ErrorMessage: Array of error message data
def failTestAndLogError(errorMessage,singleLine = False):
    grinder.statistics.forCurrentTest.setSuccess(0)
    logToError(errorMessage,singleLine)

# Helper function that logs the error message to the error log. 
# ErrorMessage: Array of error message data
def logToError(errorMessage,singleLine = False):
    grinder.logger.error(buildAndFormatErrorMessageText(errorMessage, singleLine))
# Helper function that logs the message to the output log
# Text: formated text
def logToOutput(text):
    info(text)
