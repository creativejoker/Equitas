# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.


import config.settings
from net.grinder.script.Grinder import grinder
'''
#  A quick helper method to check if the status of debugging is turned on and then print to the debug log
# If set to True, sends the debugging messages to the out logs(i.e. student/out_*.log) 
# By default set to False
logDebugMessages=False
'''

def checkDebugAndLog(message, debugging = False):
    #Checks to see if debugging is turned on in config/setting.py 
    #Or if debugging variable passed in is true
    if config.settings.logDebugMessages == True or debugging == True:
        grinder.logger.info(message)
        grinder.logger.debug(message)
def infoAndError(message):
    grinder.logger.info(message)
    grinder.logger.error(message)
def info(message):
    grinder.logger.info(message)
def error(message):
    grinder.logger.error(message)
def warn(message):
    grinder.logger.warn(message)
