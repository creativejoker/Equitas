# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from HTTPClient import URI
#from net.grinder.plugin.http import HTTPRequest
#from net.grinder.plugin.http import HTTPPluginControl
import utils.parse
import config.settings
import utils.logging
from utils.bblearndb import BbLearnDb

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = grinder.logger.info
debug = utils.logging.checkDebugAndLog
infoAndError = utils.logging.infoAndError
courseTOCMode = config.settings.courseTOCMode

class BbLearn:

    def __init__(self):
        self.bblearndb=BbLearnDb()
        self.reset()
    def reset(self):
        debug("Bblearn.reset(): Resetting the bblearn object")
        
        #Instance Information
        
        self.version = ""
        self.versionBelowSP14 = False
        self.versionAboveSP14 = False
        self.vi = ""
        self.contentSystemTabPk = ""
        self.courseTabPk = "2"
        self.studentPortalMyGradeUrl=""
        self.portalAnnouncementUrl=""
        self.portalCalendarUrl=""
        self.userId=""
        self.isUserInstructorScenario = False
        
        #Section Merge Tool Support
        self.SectionMergeToolPortalEntryUrl =""
        #Image JS/CSS
        self.img = []
        self.css = []
        self.js = []
        
        #Course Specific Information
        self.coursePks = []
        self.resetCourse()
    
        #ULTRA Support
        self.isUltra = False
        self.userPk = ""
        
    def resetUltraCourse(self):
        self.ultraContentJsonResponse = ""
    


    def resetCourse(self):
        debug("Bblearn.resetCourse(): Resetting the course object")
        self.isUserInstructorInCurrentCourse = False
        
        self.courseTOCModeIsLegacy = False
        self.courseTOCModeIsMap = False
        self.coursePk = ""
        self.dbForumUrls = []
        self.assessmentUrls = []
        self.announcementUrls = []
        self.assignmentUrls = []
        self.wikiPageUrls = []
        self.blogUrls = []
        self.courseToolsTOCUrls = []
        self.courseContentTOCUrls = []
        
        #create dictionary for the course toc so we can look them up later. 
        self.courseTOCLinks={}
        self.courseToolTOCTargets=[]
        for target in config.settings.courseToolTOCTargets:
            target = target.replace(" ","")
            self.courseTOCLinks[target] = ""
            self.courseToolTOCTargets.append(target)

        self.fileUrls = []
        self.folderUrls = []
        self.courseContentCollectionURL = []
        
        debug("Bblearn.resetCourse(): Resetting the bblearn course object")
    def loadBbLearnCourseObjectFromCoursePk(self,coursePk):
    
        if self.courseTOCModeIsLegacy:
            info("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Course TOC mode is LEGACY, nothing to load. ")
            return
            
        if utils.bblearndb.BbLearnDeployedCourseContentsHashMap.containsKey(coursePk):
            if config.settings.initialCourseMapping:
                #Just checking to see if it exist, no need to actually load the data.
                return True
                
                
            info("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loading course Pk: "+coursePk+" content objects from the saved data..")
            #Load the hashmap
            courseObjectHashMap = utils.bblearndb.BbLearnDeployedCourseContentsHashMap.get(coursePk)
            if courseObjectHashMap.containsKey("dbForumUrls"):
                self.dbForumUrls = courseObjectHashMap.get("dbForumUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.dbForumUrls))+" dbForumUrls objects in  course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("assessmentUrls"):
                self.assessmentUrls = courseObjectHashMap.get("assessmentUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.assessmentUrls))+" assessmentUrls objects in course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("assignmentUrls"):
                self.assignmentUrls = courseObjectHashMap.get("assignmentUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.assignmentUrls))+" assignmentUrls objects in course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("wikiPageUrls"):
                self.wikiPageUrls = courseObjectHashMap.get("wikiPageUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.wikiPageUrls))+" wikiPageUrls objects in course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("blogUrls"):
                self.blogUrls = courseObjectHashMap.get("blogUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.blogUrls))+" blogUrls objects in course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("courseToolsTOCUrls"):
                self.courseToolsTOCUrls = courseObjectHashMap.get("courseToolsTOCUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.courseToolsTOCUrls))+" courseToolsTOCUrls objects in course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("courseContentTOCUrls"):
                self.courseContentTOCUrls = courseObjectHashMap.get("courseContentTOCUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.courseContentTOCUrls))+" courseContentTOCUrls objects in course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("fileUrls"):
                self.fileUrls = courseObjectHashMap.get("fileUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.fileUrls))+" fileUrls objects in course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("folderUrls"):
                self.folderUrls = courseObjectHashMap.get("folderUrls")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.folderUrls))+" folderUrls objects in course Pk: "+coursePk)
            if courseObjectHashMap.containsKey("courseContentCollectionURL"):
                self.courseContentCollectionURL = courseObjectHashMap.get("courseContentCollectionURL")
                debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded "+str(len(self.courseContentCollectionURL))+" courseContentCollectionURL objects in course Pk: "+coursePk)
            
            #Course Toc
            
            for target in self.courseToolTOCTargets:
                if courseObjectHashMap.containsKey("courseTOCLinks"+target):
                    self.courseTOCLinks[target] = courseObjectHashMap.get("courseTOCLinks"+target)
                    debug("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Loaded 1 "+target+" Course TOC objects in course Pk: "+coursePk)

               
            return True
        else:
            info("BbLearn.loadBbLearnCourseObjectFromCoursePk(): Course Content objects do not exist for course pk:  " + coursePk)
            return False
    def saveBbLearnCourseObject(self):
        #Only need to save if we're mapping the course. Otherwise no need to save the data
        if self.courseTOCModeIsMap:
        
            self.bblearndb.saveBblearnObject(self.coursePk,self.dbForumUrls,"dbForumUrls")
            self.bblearndb.saveBblearnObject(self.coursePk,self.assessmentUrls,"assessmentUrls")
            self.bblearndb.saveBblearnObject(self.coursePk,self.assignmentUrls,"assignmentUrls")
            self.bblearndb.saveBblearnObject(self.coursePk,self.wikiPageUrls,"wikiPageUrls")
            self.bblearndb.saveBblearnObject(self.coursePk,self.blogUrls,"blogUrls")
            self.bblearndb.saveBblearnObject(self.coursePk,self.courseToolsTOCUrls,"courseToolsTOCUrls")
            self.bblearndb.saveBblearnObject(self.coursePk,self.courseContentTOCUrls,"courseContentTOCUrls")
            
            for target in self.courseToolTOCTargets:
                self.bblearndb.saveBblearnObject(self.coursePk,self.courseTOCLinks[target],"courseTOCLinks"+target)
            self.bblearndb.saveBblearnObject(self.coursePk,self.fileUrls ,"fileUrls")
            self.bblearndb.saveBblearnObject(self.coursePk,self.folderUrls ,"folderUrls")
            self.bblearndb.saveBblearnObject(self.coursePk,self.courseContentCollectionURL ,"courseContentCollectionURL")
        #else:
        #    info("BbLearn.saveBbLearnCourseObject(): Course "+self.coursePk +" previously loaded from file, not saving")
    #Helper method to be called each time before a course is mapped. This way it'll ensure that only the table of content is for that particular course.
    def setCourseTocMode(self,overRideMap=False):

        if courseTOCMode == "MAP" or overRideMap:
            if overRideMap:
                info("Bblearn.setCourseTocMode(): config/setting.py Course TOC is "+ courseTOCMode +", however over ride is True. Course TOC Mode is MAP")
            else:
                info("Bblearn.setCourseTocMode(): Course TOC Mode is MAP")
            self.courseTOCModeIsMap = True
            self.courseTOCModeIsLegacy = False
        elif courseTOCMode == "LEGACY":
            info("Bblearn.setCourseTocMode(): Course TOC Mode is Legacy")
            self.courseTOCModeIsLegacy = True
            self.courseTOCModeIsMap = False
            
    def extractBbLearnImagesJSCSS(self,lastPage,reset=False):
        
        if reset == True:
            self.css = []
            self.js =[]
            self.img = []

        if len(self.css) < 30:
        #####START LAUREATE DEEP LINKS CUSTOMIZATION
            #Exclude anything with .com address such as libapps.s3.amazonaws.com/sites/1470/include/custom_js_css_library.css
            #self.css += utils.parse.extractAll(lastPage, 'link rel="stylesheet" type="text/css" href="', '((?!.com).)*$', '"',15,False)
        #####END LAUREATE DEEP LINKS CUSTOMIZATION
           
           self.isObjectUnique(utils.parse.extractAll(lastPage, 'link rel="stylesheet" type="text/css" href="', '[^"]+?', '"',15,False),self.css)

          

        if len(self.js) < 30:
            self.isObjectUnique(utils.parse.extractAll(lastPage, 'script type="text/javascript" src="', '[^"]+?', '"',15,False),self.js)
            
        if len(self.img) < 30:
            #self.img += utils.parse.extractAll(lastPage, 'img src="', '[^"]+.(png|jpg|JPG|jpeg|gif|ico)', '"',15,False)
            self.isObjectUnique(utils.parse.extractAll(lastPage, 'img src="', '[^"]+?', '"',15,False),self.img)
        #Log number of images/js/css found        
        info("Bblearn.extractBbLearnImagesJSCSS(): Found CSS:"+str(len(self.css))+"  JS:"+str(len(self.js))+" IMG:"+str(len(self.img)))     
    
    def isObjectUnique(self,foundObjectsList,targetObjectList):
        
        tempList = []
        runningList = []
        #Iterate through all of the found objects
        for foundObject in foundObjectsList:
            #Check to see if that foundObject already exist in the target array
            if foundObject not in  targetObjectList and foundObject not in runningList:
                debug("BbLearn.isObjectUnique(): " + foundObject+" is unique, adding to list ")
                tempList.append(foundObject)
                #Since we can't use set to get a unique list of incoming found object, keep a running list for comparison of things that have already been added
                runningList.append(foundObject)
        
        #Finally we add the templist to the target list
        targetObjectList +=tempList
            
    def  extractUltraUserPk(self,lastPage):

        #Parse to get the USerID
         #      user: {"systemRoles":["USER"],"visibilityScope":"NOBODY","permissions":{"create":false,"delete":false,"editAccountInfo":true,"editSystemRoles":false,"editInstitutionRoles":false,"editAvatar":true,"sendMessage":true,"fieldPermissions":{"middleName":false,"otherName":false,"title":false,"studentId":true,"familyName":false,"userName":false,"emailAddress":true,"givenName":false,"password":true,"suffix":false}},"id":"_93_1","suffix":"","calendarType":null,"middleName":"","familyName":"Last000000005","title":"","otherName":"","emailAddress":"user000000005@perf.bb.test","systemRole":"None","showWorkInfo":false,"showEmailInfo":false,"showAddressInfo":false,"showAddContactInfo":false,"systemRoleIdentifier":"N","studentId":"","weekFirstDay":null,"givenName":"First000000005","avatar":{"permanentUrl":"default","fileLocation":null,"fileName":null,"webLocation":null},"userName":"user000000005","locale":null},
         
        #only check if we don't already have pk, otherwise no need to recheck
        if self.userPk == "":
            self.userPk = utils.parse.extractOnce(lastPage, '"id":"_', "[0-9]+", "_1",False)
        
        if self.userPk !="":
            #log the number of courses found
            info("Bblearn.extractUltraUserPk(): Found user pk value: "+self.userPk)
        else:
            infoAndError("Bblearn.extractUltraUserPk(): No User PK found: ")
    def extractSectionMergeToolUrl(self,lastPage):
        
        #we only try this if the entry point is empty
        if self.SectionMergeToolPortalEntryUrl =="":
            self.SectionMergeToolPortalEntryUrl = utils.parse.extractOnce(lastPage,'"','/webapps/bbgs-coursemergetool[^"]+?','"', False)
    def extractBbLearnCoursePk(self,lastPage):
        ###################################################################
        #NEW - GRAB COURSE ID LIST
        #try to get the course ID list based of the last page
        
        #Section Merge Tool, check for the portal module link
        
        self.extractSectionMergeToolUrl(lastPage)
        
        if self.isUserInstructorScenario:
            #if this is an instructor, we grab this chunk of courses . 
            # <h3>Courses where you are: Instructor</h3> <ul class="portletList-img courseListing coursefakeclass "> <li> <img alt='' src='/images/ci/icons/bookopen_li.gif' width='12' height='12' /> <a href=" /webapps/blackboard/execute/launcher?type=Course&id=_819_1&url=" target="_top">BD_PEMigration_TestCourse1</a> </li> </ul>
            lastPageTemp=lastPage
            lastPage=utils.parse.extractOnce(lastPage,'<h3>'+config.settings.instructorMyCourseModuleTitle+'</h3>', ".+?", '</ul>', False)
            #lastPage=utils.parse.extractOnce(lastPage,'Courses where you are:[ A-Za-z0-9]+? Instructor', ".+?", '</ul>', False)
            if lastPage == "" and lastPageTemp.count('<ul class="course-list accordion-list courses">')>0:
                lastPage=lastPageTemp
        else:
            #we assume that you're a student, so we grab this chunk
            #<h3>Courses where you are: Student</h3> <ul class="portletList-img courseListing coursefakeclass "> <li> <img alt='' src='/images/ci/icons/bookopen_li.gif' width='12' height='12' /> <a href=" /webapps/blackboard/execute/launcher?type=Course&id=_805_1&url=" target="_top">BVTestCourse5</a> </li> </ul>
            lastPageTemp=lastPage
            lastPage=utils.parse.extractOnce(lastPageTemp,'<h3>'+config.settings.studentMyCourseModuleTitle+'</h3>', ".+?", '</ul>', False)
            if lastPage == "" and lastPageTemp.count('<ul class="course-list accordion-list courses">')>0:
                lastPage=lastPageTemp
                
            #only check if we don't already have coursePks, otherwise no need to recheck
        if len(self.coursePks) ==0:
            if self.versionBelowSP14:
                self.coursePks=utils.parse.extractAll(lastPage, "Course%26id%3[dD]_", "[0-9]+", "_1%26url%3D",50,False)

                if len(self.coursePks)==0:
                    info("Bblearn.extractBbLearnCoursePk(): Blackboard Version is below SP14, but Course IDs extract failed, returning")
                    return False
                else:
                    info("Bblearn.extractBbLearnCoursePk(): Blackboard Version is below SP14: " + str(len(self.coursePks))+" course found")
            elif self.versionAboveSP14:
                self.coursePks=utils.parse.extractAll(lastPage, "Course&id=_", "[0-9]+", "_1&url=",50,False)

                if len(self.coursePks)==0:
                    info("Bblearn.extractBbLearnCoursePk(): Blackboard Version is above SP14, but Course IDs extract failed, returning")
                    return False
                else:
                    info("Bblearn.extractBbLearnCoursePk(): Blackboard Version is above SP14: " + str(len(self.coursePks))+" course found")
            elif self.isUltra:
                self.coursePks=utils.parse.extractAll(lastPage, '"role":"S","courseId":"_', '[0-9]+', '_1"',50,False)

                if len(self.coursePks)==0:
                    info("Bblearn.extractBbLearnCoursePk(): Blackboard Version is Ultra, but Course IDs extract failed, returning")
                    return False
                else:
                    info("Bblearn.extractBbLearnCoursePk(): Blackboard Version is Ultra: " + str(len(self.coursePks))+" course found")
            else:
                info("Bblearn.extractBbLearnCoursePk(): Blackboard Version not recognized, returning")
                return False
            
            
            if self.isUserInstructorScenario:
            #log the number of courses found
                info("Bblearn.extractBbLearnCoursePk(): Found " + str(len(self.coursePks)) + " courses user is enrolled in as instructor on this portal page.")    
            else:
                 info("Bblearn.extractBbLearnCoursePk(): Found " + str(len(self.coursePks)) + " courses user is enrolled in as a student on this portal page.")   
            
            #If we get all the way here, we should return True so the calling method knows we found courses
            return True
        else:
            
            #if we've already have courses, we should return true as well
            return True
   

    def extractBbLearnVersion(self,lastPage):

        # Uses the delete cookie javascript to determine what the vi handle is
        #Updateing this ot use the bb-social b2 as it's a little more stable from build to build
        
        #On login page
        #deleteCookie("JSESSIONID", "/webapps/bb-social-learning-BBLEARN", null, true);

        #On portal page 
        # <script type="text/javascript" src="/webapps/bb-social-learning-bb_bb60/js/social.js?v=3400.0.4-rel.68+a1c490e_3400.0.4-rel.68+a1c490e"></script>
        vi = utils.parse.extractOnce(lastPage, '/webapps/bb-social-learning-', '[^"]+?', '["/]',False)
        
        #Checks to see if there's a value, otherwise we default to BBLEARN
        if vi != "" :
            self.vi = vi
        
        else:
            info("Bblearn.extractBbLearnVersion(): The VI handle was not found, defaulting to \"BBLEARN\"")
            self.vi = "BBLEARN"


        #NEW - EXTRACT THE VI HANDLE FROM THE PAGE SOURCE
        # Uses the delte cookie javascript to determine what the vi handle is
        #deleteCookie("JSESSIONID", "/webapps/Bb-mobile-bb_bb60", null, true);
        bbVersion = utils.parse.extractOnce(lastPage, '<li>Course Delivery \(', '[0-9.]+', '\)</li>',False)
        bbVersion2 = utils.parse.extractOnce(lastPage, '/common/shared.css\?v=', '[0-9.]+', '("|-)',False)
        
        #ULTRA
        bbVersionUltra = utils.parse.extractOnce(lastPage, '/ultra.css\?v=', '[^"]+?', '"',False)
               #Checks to see if there's a value, otherwise we default to BBLEARN
        
        if bbVersion != "" :
            self.version = bbVersion
        elif bbVersion2 !="":
            self.version = bbVersion2
        #Check to see if the version is ULTRA, if so set it as the version and set the isUltra flag to True
        elif bbVersionUltra !="":
            self.version = bbVersionUltra
            self.isUltra = True
            info("BbLearn.extractBbLearnVersion(): This is an ultra version of Blackboard: " + self.version)
        else:
            info("Bblearn.extractBbLearnVersion():  The version was not found, defaulting to 9.1.201404.160205")
            self.version = "9.1.201404.160205"
        info("Bblearn.extractBbLearnVersion():Bb Learn Version: " + self.version +" VI handle: "+ self.vi)
        
        if (self.version=='9.1.120113.0'  or self.version=='9.1.130093.0'or self.version=='9.1.140152.0'):
            self.versionBelowSP14 = True
        else:
            self.versionAboveSP14 = True

    def extractBbLearnCourseContentTabPks(self,lastPage,framesetUrl):
        
        #Check the response for the course and content system tab pk values

        contentSystemTabPk=utils.parse.extractOnce(lastPage, framesetUrl+'\?tab_tab_group_id=_', '[0-9]+', '_1" TARGET="_top"><span>'+config.settings.contentSystemTabName,False)
        courseTabPk = utils.parse.extractOnce(lastPage, framesetUrl+'\?tab_tab_group_id=_', '[0-9]+', '_1" TARGET="_top"><span>'+config.settings.courseTabName,False)
        
        # We use this regex pattern [A-Z0-9a-z.\/:]+ in case blackboard decides to use an absolute 
        # link vs a relative link. 
        #<a href="https://bbgroupd.syr.edu/webapps/blackboard/execute/announcement?method=search&context=mybb&handle=my_announcements&returnUrl=/webapps/portal/execute/tabs/tabAction?tab_tab_group_id=_2_1&tabId=_1_1&forwardUrl=index.jsp" target="_self">Announcements</a>
        # and 
        #<a href="/webapps/blackboard/execute/announcement?method=search&context=mybb&handle=my_announcements&returnUrl=/webapps/portal/execute/tabs/tabAction?tab_tab_group_id=_2_1&tabId=_1_1&forwardUrl=index.jsp" target="_self">Announcements</a>

        studentPortalMyGradeUrl = utils.parse.extractOnce(lastPage, 'href="','[A-Z0-9a-z.\/:]+/do/student/viewCourses[^"]+?','"',False)
        portalAnnouncementUrl = utils.parse.extractOnce(lastPage, 'href="','[A-Z0-9a-z.\/:]+/execute/announcement[^"]+?','"',False)
        portalCalendarUrl = utils.parse.extractOnce(lastPage, 'href="','[A-Z0-9a-z.\/:]+/execute/viewCalendar[^"]+?','"',False)
        
        if contentSystemTabPk !="":
            self.contentSystemTabPk =contentSystemTabPk
        if courseTabPk !="":
            self.courseTabPk = courseTabPk
        
        info("Bblearn.extractBbLearnCourseContentTabPks(): Course Tab PK: " + self.courseTabPk +" Content System Tab Pk: "+ self.contentSystemTabPk)

        if studentPortalMyGradeUrl !="":
            self.studentPortalMyGradeUrl = studentPortalMyGradeUrl
            info("Bblearn.extractBbLearnCourseContentTabPks(): Found the  student portal my grade url" )
        else:
            info("Bblearn.extractBbLearnCourseContentTabPks(): Did not find the  student portal my grade url" )
        if portalAnnouncementUrl !="":
            self.portalAnnouncementUrl = portalAnnouncementUrl
            info("Bblearn.extractBbLearnCourseContentTabPks(): Found the portal announcement url" )
        else:
            info("Bblearn.extractBbLearnCourseContentTabPks(): Did not find the portal announcement url" )
        if portalCalendarUrl !="":
            self.portalCalendarUrl = portalCalendarUrl
            info("Bblearn.extractBbLearnCourseContentTabPks(): Found the portal calendar url")
        else:
            info("Bblearn.extractBbLearnCourseContentTabPks(): Did not find the portal calendar url" )
            
    #Extracts assignment/db/assessment/wiki/blog/urls from the link that's opened
    #Also if there's  match, stores the last URL for that tool so that we can then use it later on when opening the tool
    def extractBbLearnCourseToolsFromTOC(self,lastPage,url=""):
        #ULTRA support, currently only assignments and dbs are supported
        if self.isUltra:
            self.extractAssignmentUrls(lastPage,url)
            self.extractDBForumUrls(lastPage,url)
        else:
            self.extractAssignmentUrls(lastPage,url)
            
            self.extractAssessmentUrls(lastPage,url)
            self.extractBlogUrls(lastPage,url)
            self.extractDBForumUrls(lastPage,url)
            self.extractWikiPageUrls(lastPage,url)
            
            #Here we're just trying to identify the if the previous URL was the particular tool page
            self.extractToolUrlFromPreviousPage(lastPage,url)
            self.extractToolUrlFromCurrentPage(lastPage,url)
            
    def extractDBForumUrls(self,lastPage,url=""):
            
        #ULTRA SUPPORT
        if self.isUltra:
            dbForumUrls=[]
        #resource/x-bb-forumlink","position":0,"permissions":{"copy":false,"contentHandlerPermissionMap":{"createDiscussion":true},"viewAdaptiveRelease":false,"createAdaptiveRelease":false,"modifyAdaptiveRelease":false,"deleteAdaptiveRelease":false,"dashboardView":false,"createLearningStandardsAlignment":false,"delete":true,"edit":false},"id":"_11216_1"}
            discussionPks = utils.parse.extractAll(lastPage, 'resource/x-bb-forumlink[^|]+"id":"_', '[0-9]+?', '_1',10,False)
            #Loop through and build the assignment urls
            for pk in discussionPks:
                dbForumUrls.append("/ultra/courses/_"+self.coursePk+"_1/engagement/discussion/view/_"+pk+"_1/_"+self.coursePk+"_1")
        else:
            dbForumUrls=utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/discussionboard/do/forum\?action=list_threads[^"]+?', '"',10,False)
        
        if len(dbForumUrls)>0:
            info("Bblearn.extractDBForumUrls(): Found " + str(len(dbForumUrls))+" discussionboard forums on this page...")
            self.dbForumUrls += dbForumUrls
            if url !="":
                self.extractNameOfTOC('Discussions',url)
            return True
        else:
            return False
    
    #If the tool name doesn't match up previously based on the pattern matching in extractBbLearnCourseTOC then this should catch them since we should know based on the URL
    def extractToolUrlFromPreviousPage(self,lastPage,url=""):
        
        #This should be the first check since on the tool page there can be multiple other tools 
        if lastPage.count("/webapps/blackboard/execute/course/tools/settings"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is a tool link")
            if url !="":
                self.extractNameOfTOC('Tools',url)
            return
        if lastPage.count("/webapps/achievements/badgeAssertion.json"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is course portfolio page")
            if url !="":
                self.extractNameOfTOC('Achievements',url)
            return
        if lastPage.count("webapps/blackboard/execute/announcement"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is an announcement link")
            if url !="":
                self.extractNameOfTOC('Announcements',url)
            return
        if lastPage.count("webapps/blogs-journals/execute/blogTopicList"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is a blog link")
            if url !="":
                self.extractNameOfTOC('Blogs',url)
            return
        if lastPage.count("calendarsForm"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is calendar page")
            if url !="":
                self.extractNameOfTOC('Calendar',url)
            return
        if lastPage.count("/webapps/blackboard/execute/staffinfo/manageContacts"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is a staff contacts page")
            if url !="":
                self.extractNameOfTOC('Contacts',url)
            return
        if lastPage.count("/webapps/discussionboard/do/conference"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is a discussions link")
            if url !="":
                self.extractNameOfTOC('Discussions',url)
            return
        if lastPage.count("group_content_list.jsp"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is a group page link")
            if url !="":
                self.extractNameOfTOC('Groups',url)
            return

        if lastPage.count("/webapps/blackboard/execute/modulepage/"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is a course home page")
            if url !="":
                self.extractNameOfTOC('HomePage',url)
            return
        #NEW
        if lastPage.count("task_edit_list.jsp"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is a task page")
            if url !="":
                self.extractNameOfTOC('Tasks',url)
            return
        if lastPage.count("webapps/blackboard/messaging/"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is an course message page")
            if url !="":
                self.extractNameOfTOC('Messages',url)
            return
        if lastPage.count("grade_stream_detail.jsp"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is my grades page")
            if url !="":
                self.extractNameOfTOC('MyGrades',url)
            return

        if lastPage.count("/webapps/blackboard/execute/displayEmail"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is email page")
            if url !="":
                self.extractNameOfTOC('Email',url)
            return
        if lastPage.count("/webapps/blackboard/execute/searchRoster"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is roster page")
            if url !="":
                self.extractNameOfTOC('Roster',url)
            return
        if lastPage.count("/webapps/portfolio/viewMyBbPortfolioManager"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is porfolio homepage page")
            if url !="":
                self.extractNameOfTOC('PortfolioHomepage',url)
            return
        if lastPage.count("/webapps/blackboard/glossary/links"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is glossary page")
            if url !="":
                self.extractNameOfTOC('Glossary',url)
            return
        if lastPage.count("coursePortfolios.jsp"):
            info("Bblearn.extractToolUrlFromPreviousPage(): The url is course portfolio page")
            if url !="":
                self.extractNameOfTOC('Portfolio',url)
            return

    def extractToolUrlFromCurrentPage(self,lastPage,url=""):
        

        achievementUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/achievements/studentViewAchievements.form\?[^"]+?', '"',False)
        announcementUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/execute/announcement\?[^"]+?', '"',False)
        blogUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/execute/blogTopicList\?[^"]+?type=blogs', '"',False)
        calendarUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/execute/viewCalendar\?[^"]+?', '"',False)
        contactsUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/execute/staffinfo/manageStaffInfo\?[^"]+?', '"',False)
        courseMessagesUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/messaging/course/folderList.jsp\?[^"]+?', '"',False)
        coursePortfolioUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/portfolio/execute/listCoursePortfolios\?[^"]+?', '"',False)
        discussionBoardUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/discussionboard/do/conference\?[^"]+?', '"',False)
        emailUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/email/caret.jsp\?[^"]+?', '"',False)
        glossaryUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/glossary/links/glossary.jsp\?[^"]+?', '"',False)
        groupUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/bb-group-mgmt-LEARN/execute/groupContentList\?[^"]+?', '"',False)
        journalUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/execute/blogTopicList\?[^"]+?type=journal', '"',False)
        myGradeUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/gradebook/do/student/viewGrades\?[^"]+?', '"',False)
        portfolioHomepageUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/content/contentWrapper.jsp\?[^"]+?/webapps/portfolio/viewMyBbPortfolioManager', '"',False)
        rosterUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/execute/searchRoster\?[^"]+?', '"',False)
        tasksUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/blackboard/execute/taskEditList\?[^"]+?', '"',False)
        wikiUrl = utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+?webapps/Bb-wiki-'+self.vi+'/wikiList\?[^"]+?', '"',False)

        #courseToolTOCTargets = ['Achievements','Announcements','Assessments','Assignments','Blogs','Calendar','Contacts','Discussions','Email','Glossary','Groups','Journals,'Home Page','Messages','My Grades','Portfolio Homepage','Portfolio','Roster','Tasks','Tools','Wikis']

        if len(achievementUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Achievement tools on this page...")
            self.extractNameOfTOC('Achievements',achievementUrl)
        if len(announcementUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Course Announcements tools on this page...")
            self.extractNameOfTOC('Announcements',announcementUrl)
        if len(blogUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Blogs tools on this page...")
            self.extractNameOfTOC('Blogs',blogUrl)
        if len(calendarUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Course Calendar tools on this page...")
            self.extractNameOfTOC('Calendar',calendarUrl)
        if len(contactsUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found  Contacts tools on this page...")
            self.extractNameOfTOC('Contacts',contactsUrl)
        if len(coursePortfolioUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Portfolio tools on this page...")
            self.extractNameOfTOC('Portfolio',coursePortfolioUrl)
        if len(discussionBoardUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Discussions tools on this page...")
            self.extractNameOfTOC('Discussions',discussionBoardUrl)
        if len(emailUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Email tools on this page...")
            self.extractNameOfTOC('Email',emailUrl)
        if len(glossaryUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Glossary tools on this page...")
            self.extractNameOfTOC('Glossary',glossaryUrl)
        if len(groupUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Groups tools on this page...")
            self.extractNameOfTOC('Groups',groupUrl)
        if len(journalUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Journals tools on this page...")
            self.extractNameOfTOC('Journals',journalUrl)
        if len(myGradeUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found My Grades tools on this page...")
            self.extractNameOfTOC('MyGrades',myGradeUrl)
        if len(portfolioHomepageUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Portfolio Homepage tools on this page...")
            self.extractNameOfTOC('PortfolioHomepage',portfolioHomepageUrl)
        if len(rosterUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Roster tools on this page...")
            self.extractNameOfTOC('Roster',rosterUrl)
        if len(tasksUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Tasks tools on this page...")
            self.extractNameOfTOC('Tasks',tasksUrl)
        if len(wikiUrl)>0:
            info("Bblearn.extractToolUrlFromCurrentPage(): Found Wikis tools on this page...")
            self.extractNameOfTOC('Wikis',wikiUrl)
            
    def extractAssignmentUrls(self,lastPage,url=""):
    
        #ULTRA SUPPORT
        if self.isUltra:
            assignmentUrls=[]
            #"visible":null,"scoreProviderHandle":"resource/x-bb-assessment-ultraassignment","courseId":"_170_1","contentId":"_11212_1","dueDate":"2016-05-27T14:47:13.391Z","delegatedGrading":null,"anonymousGrading":null,"linkId":null,"dateCreated":null,"aggregationModel":null,"hideAttempt":null,"scorable":null,"gradingSchemaId":"_963_1","deleted":false,"dateModified":null,"externalAttemptHandlerUrl":null,"visibleInAllTerms":null,"visibleInBook":null,"showStatsToStudent":null,"limitedAttendance":null,"userCreatedColumn":false,"gradingDecimalPlaces":null,"toolComputedPoints":null,"anonymousGradingReleaseDate":null,"anonymousGradingReleaseCriteria":null,"columnName":"New Assignment Mar 17, 
            assignmentPks = utils.parse.extractAll(lastPage, 'resource/x-bb-assessment-ultraassignment","courseId":"_[0-9]+_1","contentId":"_', '[0-9]+?', '_1',10,False)
            #Loop through and build the assignment urls
            for pk in assignmentPks:
                assignmentUrls.append("/ultra/courses/_"+self.coursePk+"_1/outline/assignment/_"+pk+"_1/view?courseId=_"+self.coursePk+"_1")
        else:
            assignmentUrls = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/uploadAssignment[^"]+?', '"',10,False)

        if len(assignmentUrls)>0:
            info("Bblearn.extractAssignmentUrls(): Found " + str(len(assignmentUrls))+" assignments on this page...")
            self.assignmentUrls += assignmentUrls
            if url !="":
                self.extractNameOfTOC('Assignments',url)
            return True
        else:
            return False
            
    def extractAssessmentUrls(self,lastPage,url=""):
        assessmentUrls = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchAssessment.jsp\?[^"]+?', '"',10,False)
        if len(assessmentUrls)>0:
            info("Bblearn.extractAssessmentUrls(): Found " + str(len(assessmentUrls))+" assessements on this page...")
            self.assessmentUrls += assessmentUrls
            if url !="":
                self.extractNameOfTOC('Assessments',url)
            return True
        else:
            return False
            
    def extractWikiPageUrls(self,lastPage,url=""):
        wikiPageUrls = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/Bb-wiki-'+self.vi+'/wikiView[^"]+?', '">',10,False)

        if len(wikiPageUrls)>0:
            info("Bblearn.extractWikiPageUrls(): Found " + str(len(wikiPageUrls))+" wikis on this page...")
            self.wikiPageUrls += wikiPageUrls
            if url !="":
                self.extractNameOfTOC('Wikis',url)
            return True
        else:
            return False
            
    def extractBlogUrls(self,lastPage,url=""):
        blogUrls = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blogs-journals/execute/viewBlog[^"]+?', '">',10,False)
        
        #if no viewBlog links are found, let's check to see if there is a EditBlog link by chance
        if len(blogUrls) ==0:
            blogUrls = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blogs-journals/execute/editBlogEntry[^"]+?', '">',10,False)
        
        if len(blogUrls)>0:
            info("Bblearn.extractBlogUrls(): Found " + str(len(blogUrls))+" blogs on this page...")
            self.blogUrls += blogUrls
            if url !="":
                self.extractNameOfTOC('Blogs',url)
            return True
        else:
            return False
    def extractBbLearnCourseContentFromTOC(self,lastPage):
        #We check for legacy file formats and content system links
        #LEGACY: https://performancetest1.blackboard.com/courses/1/xlarge_1/content/_94087_1/details.txt
        #Xythos: https://csub2integrationqa17.blackboard.com/bbcswebdav/pid-171-dt-content-rid-1729_1/xid-1729_1
        fileUrls=utils.parse.extractAll(lastPage, '<a href="', '/bbcswebdav/[^"]+', '"',10,False)
        fileUrls+=utils.parse.extractAll(lastPage, '<a href="', '/courses/1/[^"]+/content/[^"]+', '"',10,False)
        
        folderUrls = utils.parse.extractAll(lastPage, '<a href="', '[A-Z0-9a-z.\/:]+/blackboard/content/listContent.jsp[^"]+?', '">',30,False)
        courseToolUrls = utils.parse.extractAll(lastPage, '<a href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+?', '">',30,False)
        
        if len(fileUrls)>0:
            info("Bblearn.extractBbLearnCourseContentFromTOC(): Found " + str(len(fileUrls))+" files on this page...")
            self.fileUrls += fileUrls

        elif len(folderUrls)>0:
            info("Bblearn.extractBbLearnCourseContentFromTOC(): Found " + str(len(folderUrls))+" folders on this page...")
            self.folderUrls += folderUrls
            
        elif len(courseToolUrls)>0:
            info("Bblearn.extractBbLearnCourseContentFromTOC(): Found " + str(len(courseToolUrls))+" course tools on this page...")
            self.courseToolsTOCUrls += courseToolUrls
            
        else:
            info("Bblearn.extractBbLearnCourseContentFromTOC(): No usable files/folders found on this page")
            
        return folderUrls
    def isUserInstructorInCourse(self,lastPage=""):
        #if the user is already true, then we just return, otherwise we check. 
        if self.isUserInstructorScenario:
            return True
            
        if lastPage.count("designer_participant.toggleEditMode")>0:
            info("BbLearn.isUserInstructorInCourse(): User is an instructor.")
            self.isUserInstructorInCurrentCourse = True
        else:
            self.isUserInstructorInCurrentCourse = False
        return self.isUserInstructorInCurrentCourse
    def extractBbLearnCourseTOC(self,lastPage):
        
        #/webapps/blackboard/content/listContent.jsp?course_id=_102_1&content_id=_153_1&mode=reset
        
        #grab urls of course tool toc items with the titles intact
        #<a href="/webapps/blackboard/content/launchLink.jsp?course_id=_150_1&tool_id=_123_1&tool_type=TOOL&mode=view&mode=reset" target="_self"><span title="Groups">Groups</span></a>
        courseToolsTOCFullUrls = utils.parse.extractAll(lastPage, 'href=', '"[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp.+?', '</span>',50,False)
        self.isUserInstructorInCourse(lastPage)
        info("Bblearn.extractBbLearnCourseTOC(): Matching the course TOC links to predefined course tools.")
   
        #Iterate through the available urls
        for fullUrl in courseToolsTOCFullUrls:
            
            #Extract out the URL
            courseTOCUrl = utils.parse.extractAll(fullUrl, '"', '/webapps/blackboard/content/launchLink.jsp.+?', '"',1,False)
            
            #Quick and dirty fix to exclude help links due to SSL DNS name issues
            if fullUrl.count('Help')==0:
            
                #Check to ensure that there's something in the courseTOCUrl first:
                if len(courseTOCUrl)>=1:
                    #Parse the Course TOC Name to match with predefined tools
                    self.defineCourseTOCNames(fullUrl,courseTOCUrl[0])
            
                    #Add that tool to the list of the course toc urls when done. 
                    self.courseToolsTOCUrls += courseTOCUrl
                else:
                    infoAndError("BbLearn.extractBbLearnCourseTOC(): Full Course TOC URL not found. Current full url being processed: "+fullUrl)
        
        #For backwards compatibility, SP14 and below,the left pattern is different since the full URL is used on the page
        #https://csub2integrationqa11.blackboard.com/webapps/blackboard/content/listContent.jsp?course_id=_1104_1&content_id=_2162_1&mode=reset
        #For April 2014 +, it's a relative link /webapps/blackboard/content/launchLink.jsp?course_id=_102_1&tool_id=_1413_1&tool_type=TOOL&mode=view&mode=reset
        self.courseContentTOCUrls = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/listContent[^"]+', '"',50,False)

        #Check for the content system URLs for a course, both for the course and user 
        self.courseContentCollectionURL = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/cmsmain/webui/courses/[^"]+', '" title="',5,False)
        #self.bblearn.courseContentCollectionURL += utils.parse.extractOnce(lastPage, 'href="', '/webapps/cmsmain/webui/users/[^"]+', '" title="')
        info("Bblearn.extractBbLearnCourseTOC(): Found "+ str(len(self.courseToolsTOCUrls)) +" Course Tools  and "+str(len(self.courseContentTOCUrls)) +" course content TOCS on page")
    
    def extractLegacyCourseTOC(self,lastPage):

        self.courseTOCLinks['Announcements']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Announcements">',False)
        self.courseTOCLinks['Blogs']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Blogs">',False)
        self.courseTOCLinks['Contacts']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Contacts"',False)
        self.courseTOCLinks['Wikis']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Wikis"',False)
        self.courseTOCLinks['Discussions']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Discussion Board"',False)
        self.courseTOCLinks['Groups']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Groups"',False)
        self.courseTOCLinks['Journals']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Journals"',False)
        self.courseTOCLinks['Tools']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Tools"',False)
        self.courseTOCLinks['Tasks']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Tasks"',False)
        self.courseTOCLinks['HomePage']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/launchLink.jsp[^"]+','" target="_self"><span title="Home Page"',False)
        
        # Content types	
        self.courseTOCLinks['Assignments']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/listContent.jsp[^"]+','" target="_self"><span title="Assignments"',False)
        self.courseTOCLinks['Assessments']=utils.parse.extractOnce(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/listContent.jsp[^"]+','" target="_self"><span title="Assessments"',False)
        
        self.courseContentTOCUrls = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/listContent[^"]+','" target="_self"><span title="Course Documents"',2,False)
        self.courseContentTOCUrls += utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/blackboard/content/listContent[^"]+','" target="_self"><span title="Course Information"',2,False)


        #Check for the content system URLs for a course, both for the course and user
        self.courseContentCollectionURL = utils.parse.extractAll(lastPage, 'href="', '[A-Z0-9a-z.\/:]+/cmsmain/webui/courses/[^"]+', '" title="',5,False)

    def defineCourseTOCNames(self,fullUrl, url):

        for target in self.courseToolTOCTargets:
            if fullUrl.count(target):
                self.extractNameOfTOC(target,url)
        
    def extractNameOfTOC(self,target,url):
        if self.courseTOCLinks.has_key(target):
            info("Bblearn.extractNameOfTOC(): The target \""+target+ "\" exist.")
            self.courseTOCLinks[target] = url
        else:
            info("Bblearn.extractNameOfTOC(): The target \""+target+ "\" doesn't exist.")
        