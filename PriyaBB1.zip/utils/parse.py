# Utility functions to extract lists, load runner style

from java.lang import String
from java.util.regex import Pattern
from net.grinder.script.Grinder import grinder
from HTTPClient import NVPair
import config.settings
import utils.logging

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = grinder.logger.info
debug = utils.logging.checkDebugAndLog

def extractAll(text, leftPattern, matchPattern, rightPattern, count=-1,log=True):
    return extract(text, leftPattern, matchPattern, rightPattern, count,log)

def extractOnce(text, leftPattern, matchPattern, rightPattern,log=True):
    r=extract(text, leftPattern, matchPattern, rightPattern, 1,log)
    if(len(r)>=1):
        return r[0]
    else:
        return ''


def extract(text, leftPattern, matchPattern, rightPattern, count,log=True):
    '''Extract a list of parameters based on two sets of patterns
    Returns a list of matches'''

    p = String('.*?'+leftPattern+'('+matchPattern+')'+rightPattern+'(.*)')
    #Added check to log, by default always log unless instructed otherwise
    debug("Parse.extract(): "+str(p),log)
    pm = Pattern.compile(p, Pattern.DOTALL)
    current=String(text)

    results=[]

    while(count!=0):
        m = pm.matcher(current)
        if not m.matches():
            break
        results.append(m.group(1))
        #info(m.group(1))
        current=String(m.group(2))
        count = count - 1
    
    #Added check to log, by default always log unless instructed otherwise
    debug("Parse.extract(): Matched: " + str(len(results)),log)
    
    return results
#Helper function that takes a form and pulls out all of the NVPairs. 
#Takes a string of form data and pulls out all name/value pairs and appends to a NVPair array
#    <form  name="uploadAssignmentForm" enctype="multipart/form-data" action="/webapps/blackboard/execute/uploadAssignment?action=submit" method="post" onsubmit="return 
#    <input type='hidden' name='blackboard.platform.security.NonceUtil.nonce' value='9129b1d5-81ac-423b-b72c-41877dd09364'>
#    <input type="hidden" name="course_id" value="_1237_1"/>
# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.


# Form: String of form data
# Returns NVPair of form data names/values
def extractNVPairsFromForm(form,debugging=False):
    data=[]
    nvPairs=extractAll(form, 'input type=[\'"]hidden[\'"]', "[^|]+?", '>')
    
    if len(nvPairs)==0:
        info("Parse.extractNVPairsFromForm(): no NVPairs found")
        return # Don't bother
    for p in nvPairs:
        debug("Parse.extractNVPairsFromForm(): NVPAir:" + p,debugging)
        value=''
        name=extractOnce(p, 'name=[\'"]', ".*?", '[\'"]',debugging)
        value=extractOnce(p, 'value=[\'"]', ".*?", '[\'"]',debugging)
        
        #To handle URL encoding
        if value.find("amp;")>0:
            value = value.replace("amp;","")
        if value.find("&quot;")>0:
            value = value.replace('&quot;','"')
            
        data.append(NVPair(name,value))
        debug("Parse.extractNVPairsFromForm(): NAME:" + name +" VALUE: "+ value,debugging)
    
    return data

#Interface that performs a smart add/update of an NVPair in a list without providng a newName value. 
#This will be used by most calls to just update the newValue for the NVPAIR
#
#PARAMETERS: A list of NVPairs
#currentName: Accepts a string of the updated value for the NVPair based on the currentName provided. 
#NEWVALUE: Accepts a string of the updated value for the NVPair based on the currentName provided. 
#DEBUG: Accepts True or False. If True, it prints out the NVPairs in the list before and after the add/update. Defaults to False
#
#Returns: Returns a list of NVPair parameters
def smartUpdateNVPairs(parameters,currentName,newValue,debugging=False):
    return smartUpdateNVPairs(parameters,currentName,newValue,None,debugging=False)
    
#Method that performs a smart add/update of an NVPair in a list based on the provided currentName search string. 
#Iterates through a list of NVPairs and if it finds the NVPair based on the currentName, it pops it from the list and then appends the new values
#If the NVPair is not found, then it adds the value to the list
#
#PARAMETERS: A list of NVPairs
#CURRENTNAME: Accepts a string of the current name to search for in the list of NVPairs. 
#NEWVALUE: Accepts a string of the new value for the NVPair Value based on the currentName provided. 
#NEWNAME: Accepts a string of the new name for the NVPair Name based on the currentName provided. Defaults to None
#DEBUG: Accepts True or False, If True, it prints out the NVPairs in the list before and after the add/update. Defaults to False
#
#Returns: Returns a list of NVPair parameters
#
#USAGE: Call from within class after extracting the NVPairs
#       #Pulls out submission form
#       self.form=utils.parse.extractOnce(lastPage,'name="saveAttemptForm"', ".+", '</form>' )
#       #Update the navigation target
#       utils.parse.smartUpdateNVPairs(self.parameters,'navigationTarget', '' + self.nextQuestionNum)
def smartUpdateNVPairs(parameters,currentName,newValue,newName=None,debugging=False):
    found = False
    index = 0
    #Debug statement, prints out the NVPairs in the list before the update
    if debugging==True or config.settings.logDebugMessages == True:
        debug("Parse.smartUpdateNVPairs(): LIST OF NVPAIRS BEFORE UPDATE",debugging)
        for data in parameters:
            debug(str(data),debugging)
    #If a newName is not provided, it defaults to the original currentName provided, otherwise it's uses the newName
    if newName ==None:
       newName = currentName
    
    #Iterates through the list of parameters and if the NVPair name matches the search currentName then it pops NVPair from the list and then appends the newName and newValue
    for currentNVPair in  parameters:
        if currentNVPair.getName() == currentName:
            #If the newValue is not the same as the current value, we update the value. Otherwise, we do nothing. 
            if currentNVPair.getValue() !=newValue:
                info("Parse.smartUpdateNVPairs(): Updating Current NVPair. NAME: "+ str(currentNVPair.getName()) + " VALUE: "+str(currentNVPair.getValue())+" with NAME: "+ newName+" VALUE: "+newValue)
                parameters.pop(index)
                parameters.append(NVPair(newName, newValue))
            else:
                info("Parse.smartUpdateNVPairs(): Found NVPair. NAME: "+ str(currentNVPair.getName()) + " VALUE: "+str(currentNVPair.getValue())+" value is the same, not updating")
            found = True
            break
        index+=1
    if found == False:
        info("Parse.smartUpdateNVPairs(): Adding NVPair.  NAME: " + currentName + " VALUE: " + newValue )
        parameters.append(NVPair(newName, newValue))
        
    #Debug statement, prints out the NVPairs in the list after the update
    if debugging==True or config.settings.logDebugMessages == True:
        debug("Parse.smartUpdateNVPairs(): LIST OF NVPAIRS AFTER UPDATE",debugging)
        for data in parameters:
            debug(str(data),debugging)

    return parameters
    
    
