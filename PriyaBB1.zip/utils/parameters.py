# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from java.util import Random

# Variable classes

randomGenerator=Random()

class Parameter:

  name = "undefined"
  value = ''

  def __init__(self, name, value=''):
    self.name = name
    self.value = value

  def getValue(self):
  	return self.value


class ListParameter(Parameter):

  mode='once'; # Authorized values: once, each
  select='sequential'; # Authorized values: sequential, random
  values=[];
  lastIndex=0
  assignedValue=''

  def __init__(self, name, mode, select, values=[]):
    Parameter.__init__(self, name)
    self.values=values
    self.mode=mode
    self.select=select
    if mode=='once':
      self.assignedValue=self.getValue()


  def getValue(self):

    if self.mode=='once' and self.assignedValue!='':
      return self.assignedValue

    if self.select == 'sequential':
      if (self.lastIndex) == len(self.values):
        self.lastIndex=0
      ret=self.values[self.lastIndex]
      self.lastIndex+=1
      return ret
    else:
      return self.values[randomGenerator.nextInt()%len(self.values)]


class RangeParameter(Parameter):

  mode='once'; # Authorized values: once, each
  select='sequential'; # Authorized values: sequential, random
  assignedValue=''
  minValue=0
  maxValue=0
  format="%d"
  currentValue=0

  def __init__(self, name, mode, select, format, minValue, maxValue):
    Parameter.__init__(self, name)
    self.mode=mode
    self.select=select
    self.minValue=minValue
    self.maxValue=maxValue
    self.format=format
    self.currentIndex=minValue
    if(mode=='once'):
      assignedValue=self.getValue()

  	
  def getValue(self):

    if self.mode=='once' and self.assignedValue!='':
      return self.assignedValue

    if self.select == 'sequential':
      try:
        self.lastValue
      except AttributeError:
        self.lastValue=self.minValue
      if self.lastValue > self.maxValue:
        self.lastValue=self.minValue
      ret = self.format % self.lastValue
      self.lastValue += 1
      return ret
    else:
      return self.format % (randomGenerator.nextInt()%(self.maxValue-self.minValue+1)+self.minValue)
      #return randomGenerator.nextInt()


# Same as above, but provide a distribution for each item
# Note that the mode and select are ignored, because I am lazy
class DistributedListParameter(Parameter):
	
	def __init__(self, name, values=[], distribution=[]):
		Parameter(self, name)
		self.distribution=distribution
		self.values=values
		self.total=0
		for n in distribution:
			self.total = self.total + n
			

	def getValue(self):
		index = (randomGenerator.nextInt()%self.total)
		threshold=0
		for i in range(len(self.distribution)):
			threshold = threshold + self.distribution[i]
			if index<threshold :
				return self.values[i]

