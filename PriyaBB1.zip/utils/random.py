# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.



from net.grinder.script.Grinder import grinder
from java.util import Random
import utils.logging

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = grinder.logger.info
debug = utils.logging.checkDebugAndLog

# Variable classes

randomGenerator=Random()


# Helper function that determines if we should randomly do something based on provided percentage
# Usage from within another action/*.py location. 
#    1. Import random 
#        import utils.random 
#    2. Call from within your code
#                if  utils.random.randomlySelectPercentOfTime(10):
#                    do x
# For example if you wanted something to be True 10 percent of the time, woul
# percentage: Integer from 1-100. It is the percentage of executions that you'd like to the method to return True. 
#             For example, if you provided the integer 10, then out of 100 calls to the method, it would return true aproximately 10 times. The other 90 times the method would return False
# debug: True or False(Default). If true, it logs the output of the randomly generated integer
# Return: True or False, depending on the percentage of time that you've provided. 

def randomlySelectPercentOfTime(percentage,debugging=False):
    randomInt = randomGenerator.nextInt(100)

    debug("Random.randomlySelectPercentOfTime(): Randomly generated integer :" + str(randomInt) + " of 100, Target percentage of times: "+str(percentage),debugging)
    if randomInt < percentage:
        debug("Random.randomlySelectPercentOfTime(): SELECTED TRUE",debugging)
        return True
    else:
        debug("Random.randomlySelectPercentOfTime():SELECTED FALSE",debugging)
        return False

#Simple function to return list of users, easier than using the normal
#        chooser=ListParameter('param', 'each', 'random', params)
#       self.mid=chooser.getValue()
def randomlySelectValueFromList(list,debugging=False):
    randomInt = randomGenerator.nextInt()
    length = len(list)
    
    if length > 0:
        debug("Random.randomlySelectValueFromList(): Randomly generated integer: " + str(randomInt) + " The length of the list is: "+str(length)+" selecting number: "+str(randomInt%length)+" of the list",debugging)
        return list[randomInt%length]
    else:
        info("Random.randomlySelectValueFromList(): The list is empty, skipping...")
        return ""

#Simple function that when given a list, it provides a random index based on the length of that list
def randomlySelectIndexFromList(list,debug=False):

    length = len(list)
    if length > 0:
        int = randomGenerator.nextInt(length)
        if(debug):
            info("Random.randomlySelectValueFromList(): Randomly generated integer: " + str(int) + " The length of the list is: "+str(length)+" selecting number: "+str(int%length)+" of the list")
        return int
    else:
        info("Random.randomlySelectValueFromList(): The list is empty, skipping...")
        
def randomlySelectInt(max=-1):
    if max>0:
        return randomGenerator.nextInt(max)
    else:
        return randomGenerator.nextInt()


