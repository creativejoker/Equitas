# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
from java.io import File
import utils.logging

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = grinder.logger.info
debug = utils.logging.checkDebugAndLog

# Helper function for concurrent starting or submission of a use case.
# All grinder threads will pause if the specified file exist. Threads will resume once the file has been removed. 
# By default, it only waits if the file EXIST. Therefore, this is backwards compatible with the existing scripts.
# FILE: String of name of the file to check for. 
# TIME: Amount of time in milliseconds to wait
#
# Usage within a action/*.py file
# 1. Import rampup class
#
#   import utils.rampup
#
# 2. Call the function BEFORE the self.POST() action that you want to have all of the threads wait for(i.e. assignment submission)
# 
#   utils.rampup.waitForFile("STARTTEST",5000)
#   self.getTest('Assessments Open All').openAssessments()

def waitForFile(file,time=5000,maxTries=1000):
    f = File(file);
    count = 0
    while f.exists() == True:
        info("Rampup.waitForFile(): "+ f.getName() + " file exist, waiting "+str(time)+" milliseconds")
        grinder.sleep(time)
        
        count +=1
        if count == maxTries:
            info("Rampup.waitForFile(): Reached "+ str(maxTries)+ " maximum number of tries, breaking out of check loop")
            break 
    info("Rampup.waitForFile(): "+ f.getName()+ " file does not exist, continuing with the program")

# This class implements a ramp-up behavior for Grinder threads.
# Note that the ramp-up will only span across threads, not processes.
# Usage: r=Rampup(2,5000); r.wait()
class Rampup:

  def __init__(self, n, t):
    '''n: start n users every t milliseconds'''
    self.n=n
    self.t=t

  def wait(self, factor=1):
    '''Sleep according to the rampup rules, based on the thread number'''

    # Only on first run
    if grinder.runNumber != 0:
    	return

    message="Rampup.wait(): sleep for "+str((grinder.threadNumber/self.n)*self.t * factor)
    #message="Rampup.wait(): sleep for "+Integer.toString((grinder.threadID/self.n)*self.t * factor)
    info(message)
    grinder.sleep( (grinder.threadNumber/self.n)*self.t * factor)
    #grinder.sleep( (grinder.threadID/self.n)*self.t * factor)

