# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.


from net.grinder.script.Grinder import grinder
import utils

subject = ["Ned Stark","Jon Snow","Tyrion Lannister","the Hulk","R2-D2","Robin","Superman","Iron Man","the storm trooper","darth vader", "captain picard","batman","Samuel L Jackson","Homer Simpson","Ice T","The A-Team","Chuck Norris","Jason Bourne"]
verbs = ["wolfed down","slugged","indulged","guzzled","inhaled","gorged on","ate","chowed down on","consumed","will eat","will drink","could drink","bamboozled","bazinga","finagled"]
meats = ["Bacon","BACON","more BACON","bacon","Corned beef","prosciutto","pork chops","tenderloin","short loin","drumstick","Sirloin","pastrami","pork belly","jowl","corned beef","T-bone","pancetta","spare ribs","pork loin","short ribs","ground round","shank","bacon","filet mignon","doner","biltong","venison","boudin beef"]
coordinatingConjunction = ["and","but","nor","or","so","yet"]
subordinatingConjunctions = ["after","although","as","because","before","even though","though","whenever","wherever","while"]

movieQuotes = [
"I'm gonna make him an offer he can't refuse.",
"Live long and prosper.","You can't handle the truth!",
"I pity the fool!","I'll have what she's having.",
"I love the smell of napalm in the morning.",
"May the Force be with you.","Here's looking at you, kid.",
"Nobody puts Baby in a corner.",
"Show me the money.",
 "...Nobody calls me Lebowski. You got the wrong guy. I'm the Dude, man.",
 "Fat guy in a little coat. Fat guy in a little coat...",
 "The greatest trick the devil ever pulled was convincing the world he didn't exist.",
 "Fat, drunk, and stupid is no way to go through life, son.",
 "The ratio of people to cake is too big.",
 "Excuse me, I believe you have my stapler...",
 "Corporate accounts payable, Nina speaking. *JUST* a moment.",
 "I'm in a glass case of emotion!"
 "Do you know who I am?...I don't know how to put this, but, I'm kind of a big deal...People know me.",
 "Are you crying? There's no crying! There's no crying in baseball!",
 "If I'm not back in five minutes, just wait longer.",
 ]

searchTextList = ['Test','Fall','Spring','Summer','Bio','Chem','Math','Sci','Eng','A','B','C','0','1','2','3','4','5','6','7','8','9','.pdf','.doc','.docx','.png','jpg','jpeg','csv','.xslx']
def getSearchText():
    searchText = utils.random.randomlySelectValueFromList(searchTextList)
    return searchText
#Pre build sentences/paragraphs on initial load to reduce overhead each call. 
def getSentence():
    sentence = ""
    sentence += utils.random.randomlySelectValueFromList(subject) +" "+ utils.random.randomlySelectValueFromList(verbs) +" "+ utils.random.randomlySelectValueFromList(meats)
    randomInt = utils.random.randomlySelectInt(3)
    if randomInt==1:
        sentence +=", "+ utils.random.randomlySelectValueFromList(coordinatingConjunction)+" "
        sentence += getSentence()
    elif randomInt ==2:
        sentence +=" "+ utils.random.randomlySelectValueFromList(subordinatingConjunctions) +" "
        sentence += getSentence()
    return sentence
    
def preBuildBaconParagraphs():
    paragraphs = []

    for x in range(15):
        
        paragraph = ""
        
        for x in range(utils.random.randomlySelectInt(8)):
            paragraph += getSentence()+".  "
       
        paragraph += utils.random.randomlySelectValueFromList(movieQuotes)
        paragraphs.append(paragraph)
    return paragraphs


BaconParagraphs = preBuildBaconParagraphs()

    
# Lorem Ipsum Generator: Helper functions that that provide random text for submission to the application.
# Provides a random text for the title or paragraph of a content item that needs to be submitted. 
# Usage from within another script/*.py location
#    1. Import bacon handling
#        import utils.baconLoremIpsum
#    2. Call from within a test case to provide random text
#        parameters.append(NVPair('title', utils.baconLoremIpsum.getBaconTitle()))
#        parameters.append(NVPair('contenttext', utils.baconLoremIpsum.getBaconParagraph()))
#
def getBaconParagraph():
    return utils.random.randomlySelectValueFromList(BaconParagraphs)

def getBaconTitle():
    return utils.random.randomlySelectValueFromList(movieQuotes)


