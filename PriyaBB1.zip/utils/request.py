# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.plugin.http import HTTPRequest
from net.grinder.plugin.http import HTTPPluginControl
from HTTPClient import NVPair
from net.grinder.script.Grinder import grinder
import config.settings
import utils.error
import utils.logging

#  A shorter alias for the grinder.logger.info and utils.logging.checkDebugAndLog method.
info = grinder.logger.info
debug = utils.logging.checkDebugAndLog
blackListedUrls = config.settings.blacklistedUrls
whiteListedUrls = config.settings.whitelistedUrls
targetURL = config.settings.targetURL.getValue()

def loadHeadersFromConfig():

    headers = []
    if len(config.settings.HTTPHeaders)>0:
        debug("loadHeadersFromConfig: HEADERS IN CONFIG")
        for headerKey in config.settings.HTTPHeaders.keys():
            headers.append(NVPair(headerKey,config.settings.HTTPHeaders[headerKey]))
        return headers
    else:
        debug("loadHeadersFromConfig: NO HEADERS IN CONFIG")
        return None

HTTPHeadersFromConfig = loadHeadersFromConfig()
logFile='log.txt'


class LoggingHTTPRequest(HTTPRequest):

    '''
    Note: Add custom header information for all request in the config.settings.HTTPHeaders 
    ###############################################################
    # Header classes
    #Dictionary of headers that should be sent with each request
    #Add additional headers that can be added to all request
    HTTPHeaders= {
    #"X-Forwarded-Proto":"https",
    #"X-Forwarded-For":"true",
    }
    '''

    def GET(self, target, headers=None):
        #Check to see if we have headers
        self.checkHeaders(headers)
        
        #Decode Target
        target = self.decodeTarget(target)
        
        #Print Cookies
        #self.printCookies()
        query = None
        
        #If there's no headers, we just do a normal call
        if self.HTTPHeaders==None:
            debug("LoggingHTTPRequest.GET(): WITHOUT HEADERS")
            
            results=HTTPRequest.GET(self, target)
        
        #otherwise, we perform a GET with Headers
        else:

            debug("LoggingHTTPRequest.GET(): WITH HEADERS: " +str(self.HTTPHeaders))
            
            results=HTTPRequest.GET(self, target, query, self.HTTPHeaders)
        
        #Log the results
        self.log(results, target)
        
        #Return the results to be used up stream
        return results


    def POST(self, target, data, headers=None):
       
       #Check to see if we have headers
        self.checkHeaders(headers)
        
        #Decode Target
        target = self.decodeTarget(target)
        
        #Print Cookies
        #self.printCookies()
        
        #If there's no headers, we just do a normal call
        if self.HTTPHeaders==None:

            debug("LoggingHTTPRequest.POST(): WITHOUT HEADERS")
            result=HTTPRequest.POST(self, target, data)
        
        #otherwise, we perform a POST with Headers
        else:

            debug("LoggingHTTPRequest.POST(): WITH HEADERS: "+str(self.HTTPHeaders))
            result=HTTPRequest.POST(self, target, data, self.HTTPHeaders)
        
        #Log the results
        self.log(result, target,data)
        
        #Return the results to be used up stream
        return result
    
    def PUT(self, target, data, headers=None):
       
       #Check to see if we have headers
        self.checkHeaders(headers)
        
        #Decode Target
        target = self.decodeTarget(target)
        
        #Print Cookies
        #self.printCookies()
        
        #If there's no headers, we just do a normal call
        if self.HTTPHeaders==None:

            debug("LoggingHTTPRequest.PUT(): WITHOUT HEADERS")
            result=HTTPRequest.PUT(self, target, data)
        
        #otherwise, we perform a PUT with Headers
        else:

            debug("LoggingHTTPRequest.PUT(): WITH HEADERS: "+str(self.HTTPHeaders))
            result=HTTPRequest.PUT(self, target, data, self.HTTPHeaders)
        
        #Log the results
        self.log(result, target,data)
        
        #Return the results to be used up stream
        return result
    #Simple class to log Cookies
    def printCookies(self):
        if config.settings.printCookies==True or config.settings.logDebugMessages==True:
            utils.cookie.listAllCookies()
    #Simple class to check the headers and add headers if necessary
    def checkHeaders(self,headers):
    

        
        #Reset all headers to be None
        self.HTTPHeaders=None
        
        #Check to see if there is a header being sent in the call
        #If there is no header sent and there's available headers from the config, we set the headers equal to the value in the config
        if headers == None and HTTPHeadersFromConfig != None:
            
            self.HTTPHeaders = HTTPHeadersFromConfig
            
            debug("LoggingHTTPRequest.checkHeaders(): SETTING CONFIG HEADER TO BE HEADER: "+str(self.HTTPHeaders))
        
        #Otherwise, if there is a header sent in the call and we have headers in the config, we add the headers
        elif headers != None and HTTPHeadersFromConfig != None:
            
            self.HTTPHeaders += HTTPHeadersFromConfig
            self.HTTPHeaders += headers
            
            debug("LoggingHTTPRequest.checkHeaders(): ADDING HEADERS: "+str(self.HTTPHeaders))
        
        #If there's no config headers, then we set the header with whatever is passed in
        elif headers != None and HTTPHeadersFromConfig == None:
            
            self.HTTPHeaders = headers
            debug("LoggingHTTPRequest.checkHeaders(): SETTING PASSED HEADER TO BE HEADER: "+str(self.HTTPHeaders))
    def decodeTarget(self,target):
        
        debug("LoggingHTTPRequest.decodeTarget(): Target Before: "+ target)
        
        #To handle spaces in URLs for the content system - dchow 6/8/2018
        if target.find(" ")>0:
            target = target.replace(" ","%20")
    
        #To handle URL encoding
        if target.find("amp;")>0:
            target = target.replace("amp;","")
        if target.find("&quot;")>0:
            target = target.replace('&quot;','"')
        if target.find("&#39;")>0:
            target = target.replace("&#39;","'")
        if target.find("&#61;")>0:
            target = target.replace("&#61;","=")
        if target.find("&#32;")>0:
            target = target.replace("&#32;"," ")
        if target.find("&#58;")>0:
            target = target.replace("&#58;",":") 
        if target.find("&#45;")>0:
            target = target.replace("&#45;","-")
        debug("LoggingHTTPRequest.decodeTarget(): Target After:  "+ target)
        return target
    def log(self, result, comment="",data=[]):
        
        #NEW Check for HTTP Errors, Inline Error/Success Messages, and/or Bb Error Page
        utils.error.checkResponseForErrors(result,comment,data)
        
        #NEW Logs Response times over certain threshold
        utils.timing.checkResponseForTime(result,config.settings.responseTimeThresholdMilliSeconds)
        
        #if debug is enabled, we log the first grinder thread
        if ( config.settings.logHTMLResponseToLogFile==True and grinder.threadNumber==0 ) :

            file = open(logFile, "a")
            # Not compliant, I know
            print >> file, "<!--"+comment+"-->"
            if result.getStatusCode() != 302:
                print >> file, result.getText()
            else:
                print >> file, result.toString()
            file.close()

    #Universal list of URLS that we might want to blacklist due to issue with url
    def isUrlBlacklist(self,target):

        for url in blackListedUrls:
            if target.count(url)>0:
                return True
                info("LoggingHTTPRequest.isUrlBlacklist(): Blacklisted url: "+ url + " found in targetUrl: "+ target)
        return False
    
    #Universal list of URLS that we might want to whitelist due to issue with url.
    #By default, we blacklist everything BUT the Blackboard environment that we're load testing. 
    def isUrlWhiteListed(self,target):
        
        

        #URL can be relative, if it is then we just return
        if target.index("/") == 0:
            debug("LoggingHTTPRequest.isUrlWhiteListed(): \""+ target + "\" is a relative link, whitelisted...")
            return True 
        #Ensure that the target isn't a part of the TargetURL
        if  targetURL in target:
            debug("LoggingHTTPRequest.isUrlWhiteListed(): \""+ target + "\" is in the targetURL: "+ targetURL+", whitelisted...")
            return True
        #Check to see if the target is in the list of whitelisted URLS
        for url in whiteListedUrls:
            if target.count(url)>0:
                return True
                info("LoggingHTTPRequest.isUrlWhiteListed(): WhiteListed url: "+ url + " found in targetUrl: "+ target+", whitelisted...")
        
        info("LoggingHTTPRequest.isUrlWhiteListed():  "+ target + " is not whitelisted...")
        #if not we assume that this URL is not whitelisted and should be returned as false
        return False
    def isTargetValid(self,target):
        
        if len(target)>0:
            
            #Checking to see if the url is whitelisted     
            if self.isUrlWhiteListed(target) is not True:
                info("LoggingHTTPRequest.isTargetValid(): Target URL \"" + target + "\" is not whitelisted, target is not valid...")
                return False
                
            #Check the blacklisted urls, if we find the URL is blacklisted, we just return
            if self.isUrlBlacklist(target):
                info("LoggingHTTPRequest.isTargetValid(): Target URL \"" + target + "\" is blacklisted, target is not valid...")
                return False
       
            return True   
        else:
            info("LoggingHTTPRequest.isTargetValid(): \""+ target + "\" is empty, target is not valid")


