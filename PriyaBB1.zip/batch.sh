#! /bin/bash

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#
#
# Simple script to automate the execution of the instructor.properties + student.properties
# and archive the results + configuration
#
# Edited by marcus.uy@blackboard.com 
#
set -e

COMMMONCONF="common.sh"

rm -fr */*.class
 
#Include common environment
if [ -f "$COMMMONCONF" ]; then
  source $COMMMONCONF $* 
 
else
  echo "`date  \"+%Y-%m-%d %T\"` ERROR $(hostname): Before running $0, please ensure you have created and configured ${COMMMONCONF}' using the '${COMMMONCONF}.example' template provided."
  exit 1
fi

#Adding a datestamp for use later
TIMEDATESTAMP="$(date '+%Y-%m-%d %r')"
 
 
# Report on Max User Processes limit
echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): MAX USER PROCESSES LIMIT: $(ulimit -u)"

# Output folder name to file for use in case of script failure and to check logs easier with scripts
echo $target > last_run_target

# Keep 1 previous log file in case we forget to grab it before replay analysis
if [ -f log.txt ]; then
  echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Moving log.txt to log.txt.prev" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
  mv log.txt log.txt.prev
fi



if which mutt > /dev/null; then
    ###JOB BEGIN NOTIFICATION
    if [ -z "$EMAIL_RECIPIENTS_NOTIFICATION" ]; then
        echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: JOB BEGIN: Not set up to send email notifications."
    else
        #Send email to update job status
        echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: JOB BEGIN: Sending to $EMAIL_RECIPIENTS_NOTIFICATION"
        echo ""
        if [ -f "$JOB" ]; then
            mutt -s "JOB BEGIN: $target"  -- $EMAIL_RECIPIENTS_NOTIFICATION \ < $JOB
        else
            mutt -s "JOB BEGIN: $target"  -- $EMAIL_RECIPIENTS_NOTIFICATION \ < /dev/null
        fi
    fi
else
    echo "`date  \"+%Y-%m-%d %T\"` ERROR $(hostname): Mutt is not installed on this system"
fi
    
case "$tests" in
  b)
    echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Running instructor and student tests" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    run_grinder instructor.properties &
    run_grinder student.properties &
    #run_grinder webservices.properties &
    #run_grinder restapi.properties &
    ;;
  i)
    echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Running instructor tests only" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    run_grinder instructor.properties &
    ;;
  s)
    echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Running student tests only" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    run_grinder student.properties &
    ;;
  r)
    echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Running restapi tests only" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    run_grinder restapi.properties &
    ;;
  a)
    echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Running administrator tests only" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    run_grinder administrator.properties &
    run_grinder instructor.properties &
    run_grinder student.properties &
    ;;
  w)
    echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Running webservices tests only" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    run_grinder webservices.properties &
    ;;
  *)
    echo "`date  \"+%Y-%m-%d %T\"` ERROR $(hostname): No such test type [i,s,b,r,a,w]" | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    exit
    ;;
esac

#Wait until all background processes finish
wait
sleep 1m
### REMOTE AGENT BEGIN ###
#TODO Check that the test has stopped on the other agent servers
#
### REMOTE AGENT START ###
if [ "$REMOTE_AGENT" == "YES" ]; then
    source common_autoq.sh
    retrieve_rsync_all_apps $PERF_HOME $REMOTE_AGENT_PERF_HOME/student | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    retrieve_rsync_all_apps $PERF_HOME $REMOTE_AGENT_PERF_HOME/restapi | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    retrieve_rsync_all_apps $PERF_HOME $REMOTE_AGENT_PERF_HOME/administrator | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
    retrieve_rsync_all_apps $PERF_HOME $REMOTE_AGENT_PERF_HOME/instructor | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
fi

#Wait until all background processes finish
wait
### REMOTE AGENT END ###
#Collect the results into the "target" directory
if [ -d student ]; then
  mv "student" "$target"
fi
if [ -d webservices ]; then
  mv "webservices" "$target"
fi
if [ -d instructor ]; then
  mv "instructor" "$target"
fi
if [ -d administrator ]; then
  mv "administrator" "$target"
fi
if [ -d restapi ]; then
  mv "restapi" "$target"
fi
cp *.properties "$target"
cp config/settings.py "$target"

#Move the GC log
if [ -f gc_log ]; then
  mv "gc_log" "$target"
fi
#Grab the target/objective/accessmethod/trafficvolume and move it to target results
mv tmp/text_* "$target"

#Summarize Statistics
gather_stats | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

#Grab the last 150 lines for the mapping.map file creation later in generate.sh
files=$(find  $target -wholename *out*.log)
echo $files
for file in $files; do
    echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): Mapping statistic for $file"
    echo $file | gzip -c -9 -f >>$target/mapping_raw.log.gz
    tail -n 400 $file | sed -n "/Final statistics for this process/,\$p" | gzip -c -9 -f  >>$target/mapping_raw.log.gz
done
#Sort the trace file for response times
cat $target/*/trace*.log | awk -F"," '{print $3/1000 ","$4}' | sort -n| tail -n 100 >> $target/long_request_sorted.txt


#Added support for the SAR graphing
if [ "$PERF_USE_SAR_MONITOR" == "YES" ]; then
       
        #Download and graph the SAR data
        ./download_and_graph_sar_data.sh "$TIMEDATESTAMP" "$target"
      
fi 

#Compress Output Logs Files, do it for all directories
gzip --quiet $target/*/*.log

#Generate HTML Reports (MUST BE RUN AFTER COMPRESSING THE LOGS)
./generate.sh | tee -a $LOGGING/$LOGGING_CONSOLE_FILE

###JOB END NOFITICATION
if which mutt > /dev/null; then
    if [ -z "$EMAIL_RECIPIENTS_NOTIFICATION" ]; then
      echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): JOB END: Not set up to send email notifications."
    else
      if [ -d "$target_report" ]; then
        #Send email to update job status
        echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): JOB END: Sending to $EMAIL_RECIPIENTS_NOTIFICATION"
        echo ""
        # Check for attachments individually
        if [ -f "$target_report/hits.svg" ]; then
            muttAttachments+=" $target_report/hits.svg";
        fi
        if [ -f "$target_report/response.svg" ]; then
            muttAttachments+=" $target_report/response_trend.svg";
        fi
        if [ -f "$target_report/running.svg" ]; then
            muttAttachments+=" $target_report/running.svg";
        fi
        if [ -f "$target_report/longResponse.svg" ]; then
            muttAttachments+=" $target_report/longResponse.svg";
        fi
        if [ -f "$target_report/index.html" ]; then
            muttAttachments+=" $target_report/index.html";
        fi

       # mutt -s "JOB END: $target" -a $target_report/running.svg -a $target_report/bytes.svg -a $target_report/response_trend.svg -a $target_report/response.svg -a $target_report/hits.svg -a $target_report/index.html  -- $EMAIL_RECIPIENTS_NOTIFICATION \ < $LOGGING/$LOGGING_CONSOLE_FILE
       mutt -s "JOB END: $target" -a $muttAttachments -- $EMAIL_RECIPIENTS_NOTIFICATION \ < /dev/null
      fi
    fi
else
    echo "`date  \"+%Y-%m-%d %T\"` ERROR $(hostname): Mutt is not installed on this system"
fi
###CLEAR CONSOLE LOG
if [ -f "$JOB" ]; then
  echo ""
else
  #Reset Job console buffer
  echo -n "" | tee $LOGGING/$LOGGING_CONSOLE_FILE
  echo ""
fi
