#! /bin/bash

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#
#
# Simple script for remote agents to call a slimmed down version of batch.sh
# this is only meant to be executed on a remote load generator server  

#
# Created by dchow@blackboard.com
#
set -e


#COMMMONCONF="/home/bbperf/clients/Laureate_REMOTE_AGENT/common.sh"
export REMOTE_AGENT_PERF_HOME="/home/bbperf/clients/Laureate_REMOTE_AGENT/"
export REMOTE_AGENT_HOST="$(hostname)"
cd $REMOTE_AGENT_PERF_HOME

#Clean up old class files
rm -fr */*.class

export LOGGING_CONSOLE_FILE="${REMOTE_AGENT_PERF_HOME}/console.log"
export GRINDER_HOME="${REMOTE_AGENT_PERF_HOME}/grinder-3.10"

function run_grinder()
{
        java -cp "$REMOTE_AGENT_PERF_HOME:$GRINDER_HOME/lib/grinder.jar" -Dgrinder.useConsole=false net.grinder.Grinder $* 2>&1 | tee -a $LOGGING_CONSOLE_FILE
}


# Report on Max User Processes limit
echo "`date  \"+%Y-%m-%d %T\"` INFO $REMOTE_AGENT_HOST: MAX USER PROCESSES LIMIT: $(ulimit -u)" | tee -a $LOGGING_CONSOLE_FILE

# Output folder name to file for use in case of script failure and to check logs easier with scripts
echo $target > last_run_target | tee -a $LOGGING_CONSOLE_FILE

# Keep 1 previous log file in case we forget to grab it before replay analysis
if [ -f $LOGGING_CONSOLE_FILE ]; then
  echo "`date  \"+%Y-%m-%d %T\"` INFO $REMOTE_AGENT_HOST: Moving $LOGGING_CONSOLE_FILE to $LOGGING_CONSOLE_FILE.prev" | tee -a $LOGGING_CONSOLE_FILE
  mv $LOGGING_CONSOLE_FILE $LOGGING_CONSOLE_FILE.prev
fi

echo "`date  \"+%Y-%m-%d %T\"` INFO $REMOTE_AGENT_HOST: Running instructor and student tests" | tee -a $LOGGING_CONSOLE_FILE
run_grinder instructor.properties &
run_grinder student.properties &
#run_grinder administrator.properties &
#run_grinder restapi.properties &
#Wait until all background processes finish
wait

