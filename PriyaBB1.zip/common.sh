#! /bin/sh

set -e

#
# Common script to promote reuse between batch.sh, cs-only.sh and other
# similar run scripts. See those files for examples on how to use this
# script.
#
# Edited by marcus.uy@blackboard.com
#

### Local Configuration Begin###

#The check for existence of a $JOB file determines if autoq.sh
#supercedes these settings.
if [ -f "$JOB" ]; then
  echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): RUNNING IN AUTOQ MODE"
else
  echo "`date  \"+%Y-%m-%d %T\"` INFO $(hostname): RUNNING IN MANUAL MODE"
  export LOGGING="$(pwd)"
  export LOGGING_CONSOLE_FILE="console.log"
  export GRINDER_HOME="$(pwd)/grinder-3.10"
  export EMAIL_RECIPIENTS_NOTIFICATION="root@localhost.localdomain"

  #Finding Java -- Your Mileage May Vary
  #The pipes below should generally work with configured/installed defaults, but
  #you may need to customize if you want to use specific versions of java.
  #Use with understanding and caution.
  #For JRE
  #export JAVA_HOME=$(readlink -f /usr/bin/java | sed "s:/bin/java::")
  #For JDK
  export JAVA_HOME=$(readlink -f /usr/bin/javac | sed "s:/bin/javac::")
  #Extend path as needed
  if [  "$(env | grep PATH | grep $JAVA_HOME/bin)" == "" ]
  then
    #Will only get added once because of the check
    export PATH="$JAVA_HOME/bin:$PATH"
  fi
fi

### Local Configuration End###

################################################################################

function get_results_dir()
{
  local SEDRESULTS="s:^$(pwd)/::"
	echo -n "$1" | sed "$SEDRESULTS"
}

function get_reports_dir()
{
  local SEDRESULTS="s:^$(pwd)/::"
  local SEDREPORTS="s:^results:reports:"
	echo -n "$1" | sed "$SEDRESULTS" |  sed "$SEDREPORTS"
}

function run_grinder()
{
	java -cp "$(pwd):$GRINDER_HOME/lib/grinder.jar" -Dgrinder.useConsole=false net.grinder.Grinder $* 2>&1 | tee -a $LOGGING/$LOGGING_CONSOLE_FILE
}

function gather_stats()
{
	local OUTPUT="$target/stats.txt"
	echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: Gathering statistics in $OUTPUT..."
	sh "$BASEDIR/tools/stats.sh" "$target" > "$OUTPUT"
	cat "$OUTPUT"
}
################################################################################
# Test for bc math

if [ $(echo '1 + 1' | bc) -ne 2 ]; then
	echo You need to have \'bc\' available! >&2
	exit 1
fi

################################################################################
# Test that user has provided a results path, then infer the reports path

if [ -z "$1" ]; then
  echo Syntax: $0 TARGET_DIR TEST_TYPE >&2
  exit 2
else
  ###THIS CONVERTS ALL INPUT PATHS INTO RELATIVE PATHS
  #batch.sh and all related scripts are all designed to run relative to the
  #*home* folder (mainline) where the scripts themselves live. Passing absolute
  #paths to batch.sh is, for the most part, somewhat pointless. We may as well
  #convert the input into relative paths and make thing more consistent
  #throughout.
  target="$(get_results_dir $1)"

  ###THIS CONVERTS THE results/??? PATH TO reports/???
  #The other point to note, although it is set-able, other tools (like
  #generate.sh) assume that results are going to be in a directory within
  #the "results" directory. Again, we may as well enforce that design element.
  target_report="$(get_reports_dir $1)"

  if [ -d "$target" ]; then
  	# Make sure that this directory is not already used. Merging two experiments
  	# will produce wildly unpredictable results.
  	echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: $target already exists. Delete first!"
  	exit 2
  elif mkdir -p "$target"; then
  	echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: $target will be used to output reports"
  else
  	echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: Unable to create $target" >&2
  	exit 2
  fi
fi

if [ -z "$2" ]; then
  echo Syntax: $0 TARGET_DIR TEST_TYPE >&2
  exit 2
else
  tests="$(echo $2 | awk '/[isba]/ {print $1}')"

  # Determine which tests to run based on user input (i,s,b)
  if [ -z "$tests" ]; then
    echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: Please specificy which test to run (instructor [i], student[s], both[b])"
    exit 2
  fi
fi

################################################################################
# Test that user has configured JAVA_HOME

if [ -z "$JAVA_HOME" ]; then
	echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: JAVA_HOME is not set; chances are you are not pointing to a real JVM"
	exit 3
fi

################################################################################
# Test that user has configured GRINDER_HOME

if [ -z "$GRINDER_HOME" ]; then
	export GRINDER_HOME="$(pwd)/grinder-3.4"
fi

################################################################################
# Test that user has suitable logging values

if [ ! -d "$LOGGING" ]; then
  export LOGGING="$(pwd)"
fi

if [ -z "$LOGGING_CONSOLE_FILE" ]; then
  export LOGGING_CONSOLE_FILE="console.log"
fi

################################################################################
# Set base directory value

BASEDIR="$(cd `dirname $0`; pwd)"
