(1) Preparation
  You don't need to download Grinder. Modify batch.sh to use the
  correct location. Grinder version 3.0 is the minimum required to run.
  If GRINDER_HOME environment variable is set, the script will use that
  and you won't need to make any modifications.
  Grinder can be downloaded from http://grinder.sourceforge.net

  The UNIX/Cygwin 'bc' utility needs to be available in your PATH as well.

(2) Structure (Also see README_autoq.txt)
  config/         Configuration
  scenarios/      Scenarios
  scripts/        Script repository
  tools/          Various tools
  utils/          Various supporting classes

(3) Setting up a scenario
  See scenarios/example.py or scenarios/test.py

(4) Scenario settings
  Modify config/settings.py to adjust the different parameters.
  The main variables are targetUrl, username and password.

(5) Configuring grinder
  Grinder relies on a file called "grinder.properties" to find its
  configuration (number of threads, etc.) See the grinder manual for details.
  Make sure to point grinder.script to your scenario.

(6) Starting grinder, from the root of the benchmark directory
  Console
    java -cp $GRINDER_HOME/lib/grinder.jar grinder.net.Console

  Agent
    java -cp $GRINDER_HOME/lib/grinder.jar net.grinder.Grinder

  Note that the agent can run a batch experiment without a console by
  setting grinder.useConsole=false either in grinder.properties or on the
  command line.
    java -cp $GRINDER_HOME/lib/grinder.jar -Dgrinder.useConsole=false net.grinder.Grinder

(7) Saving the data
  Make sure to cleanup the current directory to remove old result files
  before starting; see tools/cleanup.sh.
  At the end of the experiment, save all the data_* error_*  output_* to
  a directory for further processing.

(8) Debugging
  If you set debug to 1 in settings.py, all the HTML transactions are appended
  to a file called log.txt. Use tools/show_log.tcl to generate a playback
  tree (HTML frameset). Note that you need TCL for this.
  
 
(9) Development in Eclipse
  To develop directly in Eclipse, download and install Pydev (http://pydev.org/)
  in your current Eclipse install.
  Create a new Pydev project:
    - Select jyton as the project type
    - Click the link "Click here to configure an interpreter"
    - New > locate "jython.jar" that shipped with your grinder distribution
    - In project content, uncheck use default and set the path to your perforce location
  
  To run: Run > External Tools > New Program

  Location:
     (browse to your JRE -- java.exe)
  Working direction:
     ..../benchmark/mainline, or use one of the built-in eclipse param ${workspace_loc:/PROJECT_NAME_HERE}
  Arguments:  
  -cp "__PATH_TO_GRINDER__/lib/grinder.jar" -Dgrinder.useConsole=false net.grinder.Grinder unittest.properties
  
