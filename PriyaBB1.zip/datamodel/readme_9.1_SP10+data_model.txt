Bb Consulting Performance Audit Data Model for Bb Learn 9.1 SP10 and later.

This is based off the original PD performance engineering data model and is currently designed to be imported through the GUI

Step 1. Restore all template courses to the system  
	From System Admin -> Courses -> Create Course -> Restore
	Use the appropriate course naming convention corresponding to each archive file name.
	- xsmall_template
	- small_template
	- medium_template
	- large_template
	- xlarge_template
	For "Folder for Content Collection Files" use "Course Files Default Directory "

Step 2. Validate course template (may need to self enroll for full validation) and make any necessary modification (for custom use cases etc)
	- Remember to unenroll from the course prior to cloning or your account will be enrolled in all courses

Step 3. Create a SIS integration framework
	- Name: "Bb Consulting - Performance Data Model Load"
	- Description: "SIS Integration for the Bb Consulting Performance Audit Data Model Load - <Date>"
	- Shared Username: (Default)
	- Shared Password: <blank> (Default)
	- Feed File Delimiter: "Pipe"
	- Integration Status: "Active"
	- Log Verbosity: "All Diagnostic Messages"
	- Data Source: "perf" (Note: create here if this does not exist yet)
	- Batch UID Prefix: <blank> (Default)
	- Parent Heirarchy Node: "Create hierarchy under the top level" (Default)
	- Advanced Configuration (Leave all at defaults of Smart Inserts or Updates)
		- Note: we will only use (Courses, Person, and Enrollment) Object Types at this time.
	
Step 4. Upload Feed Files into "Bb Consulting - Performance Data Model Load" SIS integration framework 
	A. Upload "small_users.snap" with data type of "Person" and operation type of "Store".
		- Validate user accounts after upload (log in as student / instructor)
	B. Upload "small_courses.snap" with data type of "Course" and operation type of "Store".
		- Validate all courses are created and properly cloned
	C. Upload small_enrollments.snap with data type of "Course Membership" and operation type of "Store".
		- Validate course memeberships were processed (log in as instructor and student accounts and validate enrollments)