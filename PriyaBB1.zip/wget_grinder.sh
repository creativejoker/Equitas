#!/bin/sh
#wget http://sourceforge.net/projects/grinder/files/The%20Grinder%203/3.11/grinder-3.11-binary.zip
wget http://sourceforge.net/projects/grinder/files/The%20Grinder%203/3.10/grinder-3.10-binary.zip
#wget http://sourceforge.net/projects/grinder/files/The%20Grinder%203/3.9.1/grinder-3.9.1-binary.zip
#wget http://sourceforge.net/projects/grinder/files/The%20Grinder%203/3.8/grinder-3.8-binary.zip
wget http://sourceforge.net/projects/grinder/files/The%20Grinder%203/3.7.1/grinder-3.7.1-binary.zip
#wget http://sourceforge.net/projects/grinder/files/The%20Grinder%203/3.6/grinder-3.6.zip
