# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

from net.grinder.script.Grinder import grinder
import config.settings
import scenarios.base
from utils.rampup import Rampup
from java.lang import Integer
import actions
import utils
import utils.random 
from utils.bblearn import BbLearn
from utils.bblearndb import BbLearnDb

class TestRunner(scenarios.base.Base):

    def __init__(self):

        scenarios.base.Base.__init__(self)
        #Instantiate the self.bblearn object once per thread and then pass that along for the scripts. 
        #This contains the bb version, bb handle, and course id's for a user
        self.bblearn=BbLearn()
        

        
        
                #we load the live users if available, otherwise we just use the regular synthetic users
        if len(utils.bblearndb.BbLearnLiveInstructorUsersList)>0:
        
            liveInstructorUserIds = utils.bblearndb.bbLearnLiveInstructorUsersRandomListParameter
            #otherwise, we should provide a list of synthetic users or live users
            #The percentage below determines what percentage of users are live, set in the config/settings.py
            if utils.random.randomlySelectPercentOfTime(config.settings.percentageLiveUsers):
                
                #Live Users
                self.login = actions.authenticate.LoginAction(self.request, 0, self.bblearn,liveInstructorUserIds)
                #if we use live users we should map the course rather than 
                self.mapCourseTocOverride = True
                
            else:
                #Synthetic Users
                self.login = actions.authenticate.LoginAction(self.request, 0, self.bblearn,config.settings.instructor)
        else:
            self.login = actions.authenticate.LoginAction(self.request, 0, self.bblearn,config.settings.instructor)
        
        self.logout = actions.authenticate.LogoutAction(self.request, 5,self.bblearn)

        #Uncomment if you want to use autosign in or cas authentication
        #self.autosignon = actions.authenticate.autoSignonAction(self.request, 10, self.bblearn,config.settings.instructor)
        #self.caslogin = actions.authenticate.CASLoginAction(self.request, 15,self.bblearn)
        #self.authactions = [
        #        actions.authenticate.autoSignonAction(self.request, 10,self.bblearn),
        #        actions.authenticate.CASLoginAction(self.request, 15,self.bblearn)
        #        ]
        #
        #self.authdistribution=(40,60)
        #self.authchooser=utils.parameters.DistributedListParameter('action',self.authactions, self.authdistribution)

        self.portal = actions.portal.PortalAction(self.request, 100, self.bblearn)
        self.course = actions.course.CourseAction(self.request, 200, self.bblearn)
        
        self.actions = [
            actions.grading.InstructorGradingAction(self.request, 1400,self.bblearn),
            actions.contentsystem.InstructorContentUploadAction(self.request, 1500,self.bblearn),
            actions.contentsystem.ContentSystemAction(self.request, 1600, self.bblearn),
            actions.coursecopy.CourseCopyAction(self.request, 1700, self.bblearn),
            actions.sectionmergetool.SectionMergeAction(self.request, 1800, self.bblearn)
            ]
        self.distribution = (
        config.settings.distributionPercentages["Instructor.Grading"],
        config.settings.distributionPercentages["Instructor.CourseContentSystemUploads"],
        config.settings.distributionPercentages["Instructor.ContentSystem"],
        config.settings.distributionPercentages["Instructor.CourseCopy"],
        config.settings.distributionPercentages["Instructor.SectionMerge"],
        )
        #self.distribution = (50)
        self.chooser=utils.parameters.DistributedListParameter('action',self.actions, self.distribution)
        #self.chooser=utils.parameters.Parameter('action', actions.grading.InstructorGradingAction(self.request, 1400,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.contentsystem.InstructorContentUploadAction(self.request, 1500,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.contentsystem.ContentSystemAction(self.request, 1600,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.coursecopy.CourseCopyAction(self.request, 1700,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.sectionmergetool.SectionMergeAction(self.request, 1800,self.bblearn) )
    def __call__(self):

        # Note: instructors ramp up 5 times more slowly than students
        config.settings.rampup.wait(5)
        
        # Login
        if(self.login()):

        # Or Use Autosignon Login if B2 is installed / configured (set secret in config/settings.py)
        #if(self.autosignon()):
        # Or Use CAS Login if configured on client and config/settings.py
        ##self.caslogin()
        # Or distribute authentication between multiple sources
        #if(self.authchooser.getValue()()):
        
            #set the instructor flag to true
            self.bblearn.isUserInstructorScenario=True
            
            #Load Portal
            self.portal()
            
            if config.settings.initialPortalNamesMapping:
                self.info("Scenarios.Instructor(): Initial Portal Name Mapping Run completed, skipping the rest of the use cases...")
                return
                
            #Load Courses
            #We pass false along so that so the instructor doesn't have to map the course table of contents for assignments/db/etc..
            self.course(False,False)
            
            
            for i in range(config.settings.instructorSessionLength):
                self.chooser.getValue()()
            #self.logout()
            # For only one out of 5 students to log out
            if( ( (grinder.runNumber) % 5 ) == 0 ) :
                    self.logout()
        else:
            self.info("Scenarios.Instructor(): User did not successfully log in, skipping use cases...")