from net.grinder.script import Test
from net.grinder.script.Grinder import grinder
import config.settings
import scenarios.base
import actions.admin
import utils
from utils.bblearn import BbLearn

class TestRunner(scenarios.base.Base):

    def __init__(self):

        scenarios.base.Base.__init__(self)
        
        #Instantiate the bblearn object once per thread and then pass that along for the scripts. 
        self.bblearn=BbLearn()
        self.login = actions.authenticate.LoginAction(self.request, 0, self.bblearn,config.settings.adminUserName)
        
        self.logout = actions.authenticate.LogoutAction(self.request, 5, self.bblearn)
        
        self.actions = [
            actions.admin.CourseSearchAction(self.request, 2000, self.bblearn),
            actions.admin.UserSearchAction(self.request, 2100, self.bblearn)
            
            ]
        # Distribution of actions, based on log analysis;
        # Don't forget to adjust this if one of the actions is commented out 
        self.distribution=(
        config.settings.distributionPercentages["Admin.CourseSearch"],
        config.settings.distributionPercentages["Admin.UserSearch"]
        )        
        

        self.chooser=utils.parameters.DistributedListParameter('action',self.actions, self.distribution)

        # Use one of the actions below to unit test a specif action
        #self.chooser=utils.parameters.Parameter('action', actions.admin.CourseSearchAction(self.request, 2000, self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.admin.UserSearchAction(self.request, 2100, self.bblearn) )

    def __call__(self):
        config.settings.rampup.wait()
        
        # Login
        #Check to ensure that the user has successfully logged in before we execute any of the actions
        if(self.login()):
        
        
            #if this is just a mapping run, then no need to execute any use cases but the course load
            if config.settings.initialCourseMapping:
                self.info("Scenarios.Admin(): Initial Mapping Run, no admin use cases...")
                return
        
        
            for i in range(config.settings.sessionLength):
                self.chooser.getValue()()
                # The code below for unit testing: run the actions in fixed sequence instead of running randomly
                #index=grinder.runNumber*config.settings.sessionLength+i
                #self.actions[index % (len(self.actions))]()
            
            # Logout    
            # All Users Log Out
            #self.logout()
            # For only one out of 5 students to log out
            if( ( (grinder.runNumber) % 5 ) == 0 ) :
                self.logout()

        
        else:
            self.info("Scenarios.Admin(): User did not successfully log in, skipping use cases...")
        
