# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.


from net.grinder.script.Grinder import grinder
import config.settings
import scenarios.base
from utils.rampup import Rampup
import utils.random 
import actions
import utils
from utils.bblearn import BbLearn
from utils.bblearndb import BbLearnDb

    
class TestRunner(scenarios.base.Base):

    def __init__(self):

        scenarios.base.Base.__init__(self)

        #Instantiate the self.bblearn object once per thread and then pass that along for the scripts. 
        #This contains the bb version, bb handle, and course id's for a user
        self.bblearn=BbLearn()
        self.mapCourseTocOverride = False
        
        #we load the live users if available, otherwise we just use the regular synthetic users
        if len(utils.bblearndb.BbLearnLiveStudentUsersList)>0:
        
            #If this is the initial mapping, we should sequentially move through all the users so that each user has been loaded and their courses have been mapped
            if config.settings.initialCourseMapping:
                liveStudentUserIds = utils.bblearndb.bbLearnLiveStudentUsersSequentialListParameter
            else:
                liveStudentUserIds = utils.bblearndb.bbLearnLiveStudentUsersRandomListParameter
                
            #otherwise, we should provide a list of synthetic users or live users
            #The percentage below determines what percentage of users are live, set in the config/settings.py
            if utils.random.randomlySelectPercentOfTime(config.settings.percentageLiveUsers):
                
                #Live Users
                self.login = actions.authenticate.LoginAction(self.request, 0, self.bblearn,liveStudentUserIds)
                #if we use live users we should map the course rather than 
                self.mapCourseTocOverride = True
                
            else:
                #Synthetic Users
                self.login = actions.authenticate.LoginAction(self.request, 0, self.bblearn)
        else:
            self.login = actions.authenticate.LoginAction(self.request, 0, self.bblearn)
            
        self.logout = actions.authenticate.LogoutAction(self.request, 5, self.bblearn)
        
        self.portal = actions.portal.PortalAction(self.request, 100, self.bblearn)
        self.course = actions.course.CourseAction(self.request, 200, self.bblearn)

        #self.shibLogin = actions.authenticate.ShibLoginAction(self.request, 15, self.bblearn)

        #Uncomment if you want to use autosign in or cas authentication
        #self.autosignon = actions.authenticate.autoSignonAction(self.request, 10, self.bblearn)
        #self.caslogin = actions.authenticate.CASLoginAction(self.request, 15, self.bblearn)
        #self.authactions = [
        #    actions.authenticate.autoSignonAction(self.request, 10, self.bblearn),
        #    actions.authenticate.CASLoginAction(self.request, 15, self.bblearn)
        #    ]
        #
        #self.authdistribution=(40,60)
        #self.authchooser=utils.parameters.DistributedListParameter('action',self.authactions, self.authdistribution)

        self.actions = [
            actions.assessment.AssessmentAction(self.request, 300, self.bblearn),
            actions.assignment.AssignmentAction(self.request, 400, self.bblearn),
            actions.blog.BlogAction(self.request, 500, self.bblearn),
            actions.content.ContentAction(self.request, 600, self.bblearn),
            actions.contentsystem.ContentSystemAction(self.request, 700, self.bblearn),
            actions.course.CourseNavigationAction(self.request, 800, self.bblearn),
            actions.db.DbAction(self.request, 900, self.bblearn),
            actions.mobile.mobileAction(self.request, 1000, self.bblearn),
            actions.staticcontent.StaticContentAction(self.request, 1100, self.bblearn),
            actions.grading.StudentGradeAction(self.request, 1200, self.bblearn),
            actions.wiki.WikiAction(self.request, 1300, self.bblearn)
            
            ]
        # Distribution of actions, based on log analysis;
        # Don't forget to adjust this if one of the actions is commented out 
        self.distribution=(
        config.settings.distributionPercentages["Student.Assessment"],
        config.settings.distributionPercentages["Student.Assignment"],
        config.settings.distributionPercentages["Student.Blog"],
        config.settings.distributionPercentages["Student.Content"],
        config.settings.distributionPercentages["Student.ContentSystem"],
        config.settings.distributionPercentages["Student.CourseNavigation"],
        config.settings.distributionPercentages["Student.DB"],
        config.settings.distributionPercentages["Student.Mobile"],
        config.settings.distributionPercentages["Student.StaticContent"],
        config.settings.distributionPercentages["Student.Grading"],
        config.settings.distributionPercentages["Student.Wiki"]
        
        
        )        
        

        self.chooser=utils.parameters.DistributedListParameter('action',self.actions, self.distribution)

        # Use one of the actions below to unit test a specif action
        #self.chooser=utils.parameters.Parameter('action', actions.assessment.AssessmentAction(self.request, 300,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.assignment.AssignmentAction(self.request, 400,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.blog.BlogAction(self.request, 500,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.content.ContentAction(self.request, 600,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.contentsystem.ContentSystemAction(self.request, 700,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.course.CourseNavigationAction(self.request, 800, self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.db.DbAction(self.request, 900,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.mobile.mobileAction(self.request, 1000,self.bblearn))
        #self.chooser=utils.parameters.Parameter('action', actions.staticcontent.StaticContentAction(self.request, 1100,self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.grading.StudentGradeAction(self.request, 1200, self.bblearn) )
        #self.chooser=utils.parameters.Parameter('action', actions.wiki.WikiAction(self.request, 1300,self.bblearn) )

        
        
        
        
        
        

    def __call__(self):
        config.settings.rampup.wait()
        
        # Login
        #Check to ensure that the user has successfully logged in before we execute any of the actions
        if(self.login()):
        #if(self.shibLogin()):
        # Or Use Autosignon Login if B2 is installed / configured (set secret in config/settings.py)
        ##if(self.autosignon()):
        # Or Use CAS Login if configured on client and config/settings.py
        ##if(self.caslogin()):
        # Or distribute authentication between multiple sources
        ##self.authchooser.getValue()()
        
            #Load Portal
            self.portal()
            
            if config.settings.initialPortalNamesMapping:
                self.info("StudentScenario(): Initial Portal Name Mapping Run completed, skipping the rest of the use cases...")
                return
            #Load Courses
            self.course(True,self.mapCourseTocOverride)
            
            #if this is just a mapping run, then no need to execute any use cases but the course load
            if config.settings.initialCourseMapping:
                self.info("StudentScenario(): Initial Mapping Run completed, skipping the rest of the use cases...")
                return
            
            #Check to ensure that the user is enrolled in courses before proceeding
            if len(self.bblearn.coursePks)==0:
                self.info("StudentScenario(): User is not enrolled in any courses, skipping...")
                return
                
            for i in range(config.settings.sessionLength):
                self.chooser.getValue()()
                # The code below for unit testing: run the actions in fixed sequence instead of running randomly
                #index=grinder.runNumber*config.settings.sessionLength+i
                #self.actions[index % (len(self.actions))]()
            
            # Logout    
            # All Users Log Out
            #self.logout()
            # For only one out of 5 students to log out
            if( ( (grinder.runNumber) % 5 ) == 0 ) :
                self.logout()

        
        else:
            self.info("Scenarios.Student(): User did not successfully log in, skipping use cases...")
        
