# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

import config.settings
from utils.request import LoggingHTTPRequest
from net.grinder.script.Grinder import grinder
import utils.logging

class Base:
    def __init__(self):
        server=config.settings.targetURL.getValue()
        self.request  = LoggingHTTPRequest(url = server)
        self.tests    = {}
        
        #Adding Logging alias to be used in scenarios
        self.info = utils.logging.info
        self.debug = utils.logging.checkDebugAndLog
        self.warn = utils.logging.warn
        self.error = utils.logging.error
        self.infoAndError=utils.logging.infoAndError
        
    def sleep(self, type):
        grinder.sleep(config.settings.thinkTime[type])

        
    # Make sure to define this for the test to run
    # def __call__(self):
