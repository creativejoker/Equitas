# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.


from net.grinder.script.Grinder import grinder
import config.settings
import scenarios.base
from utils.rampup import Rampup
import actions
import utils
from utils.bblearn import BbLearn
from utils.bblearndb import BbLearnDb
import scripts
import utils.random 
    
class TestRunner(scenarios.base.Base):

    def __init__(self):

        scenarios.base.Base.__init__(self)

        #Instantiate the self.bblearn object once per thread and then pass that along for the scripts. 
        #This contains the bb version, bb handle, and course id's for a user
        
        #If this is the initial mapping, we should sequentially move through all the users so that each user has been loaded and their courses have been mapped
        liveStudentUserIds = utils.bblearndb.bbLearnLiveStudentUsersRandomListParameter
        initialOAuth2BearerToken=scripts.BbRESTAPI.initialOAuth2BearerToken
        #otherwise, we should provide a list of synthetic users or live users
        #The percentage below determines what percentage of users are live, set in the config/settings.py
        if utils.random.randomlySelectPercentOfTime(config.settings.percentageLiveUsers):
            
            #Live Users
            userList=liveStudentUserIds
           
        else:
            #Synthetic Users
            userList=config.settings.username
                
        self.restapi = actions.BbRESTAPI.BbRESTAPIAction(self.request, 1700,userList,initialOAuth2BearerToken)


    def __call__(self):
        config.settings.rampup.wait()

        #Execute Webservices call
        #for i in range(config.settings.sessionLength):
        self.restapi()
        #self.restapi()


        
