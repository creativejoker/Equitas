datetimestamp=$(date +%Y-%m-%d_%I%M%S)
hostname=$(hostname)
datestamp=$(date +%Y-%m-%d)
export JAVA_HOME=/home/bbuser/jdk/

$JAVA_HOME/jstat -gcutil -t $($JAVA_HOME/jps -m|grep  WorkerProcessEntryPoint|awk ' { print $1}') 30000 2000 > jstat_$hostname.$datetimestamp.txt &
vmstat 20 > vmstat_$hostname.$datetimestamp.txt &
