#!/bin/sh

# Calculate the near-instantaneous throughput (based on a ~ 1 min window)
# using any grinder output file found from here down

if [ $# -eq 0 ]; then
 p=.
else
 p=$*
fi

getHitCount() {
  find $p -name out_\*.log | xargs egrep 'https?://' | wc -l
}


while true; do

  current=`getHitCount`
  currentDate=`date +%s`

  if [ ! -z "$previous" ]; then
    t1=`echo "scale=3; ($current-$previous)/($currentDate-$previousDate)" | bc -l`
    t2=`echo "scale=0; ($current-$previous)*3600/($currentDate-$previousDate)" | bc -l`
    echo "`date '+%s %Y-%m-%d %T %Z'`	$t1 hits/s	$t2 hits/h"
  fi
  previous=$current
  previousDate=$currentDate
  sleep 60

done
