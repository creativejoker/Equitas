rm out_* data_* error_* log.txt
