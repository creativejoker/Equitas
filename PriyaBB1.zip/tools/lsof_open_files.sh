#!/bin/sh

echo "\n!!!!!!Displaying Grinder open file handles every 10 seconds!!!!!\n"
while [ 1 = 1 ]; do
  lsof -c java | wc -l
  sleep 10
done