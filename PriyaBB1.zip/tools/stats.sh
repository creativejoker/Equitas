#! /bin/sh

set -e

if [ $(echo '1 + 1' | bc) -ne 2 ]; then
	echo You need to have \'bc\' available! >&2
	exit 1
fi

if [ $# -eq 0 ]; then
  src="."
else
  src="$*"
fi

hits=`find $src -name out_\* | xargs egrep 'https?://' | wc -l`
duration=`find $src -name data_\*.log -exec cat {} \; | cut -d , -f 4 | sort -r -n | head -1`

cat <<EOF
Hits: $hits
Duration: `echo "$duration / 1000.0" | bc -l`
Throughput: `echo "$hits / $duration * 3600000" | bc -l`
EOF

awk '
BEGIN { FS=",";
min=9999999; max=0; }
/^[0-9]/ { sum+=$5; count++ ; if(min>$5) {min=$5} ; if(max<$5) {max=$5} }
END {printf "Total: %d\nAverage: %f\nMinimum: %f\nMaximum: %f\n", count, sum/1000.0/count, min/1000.0, max/1000.0 } ' `find $src -name data_\*.log`

