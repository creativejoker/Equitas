#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#
# Compute averages and error counts
# Input:
#   - Test mapping file (from numerical to string)
#   - merged data file or single grinder file either as arg or from stdin
# Output: data file, graph

# Grab Report Data to Populate into HTML Below
testName=`echo $PWD | sed "s/.*\/reports\///"`
clientInfo='client.info'
if [ -f $clientInfo ]; then
  clientName=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "CLIENT_NAME") { print $2 }}'`
  # Need to verify the following are properly set / numbers
  navThresholdAvg=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "NAV_THRESHOLD_AVG") { print $2 }}'`
  trnThresholdAvg=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "TRN_THRESHOLD_AVG") { print $2 }}'`
  mobThresholdAvg=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "MOB_THRESHOLD_AVG") { print $2 }}'`
  stcThresholdAvg=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "STC_THRESHOLD_AVG") { print $2 }}'` 
  cntThresholdAvg=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "CNT_THRESHOLD_AVG") { print $2 }}'`
  cltThresholdAvg=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "CLT_THRESHOLD_AVG") { print $2 }}'`
  timeZoneOffset=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "TIMEZONE") { print $2 }}'`
  yMaxAcceptable=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "GRAPH_Y_RANGE_MAX") { print $2 }}'`
  clientProjPeak=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "PROJECTED_PEAK") { print $2 }}'`
else
  clientName="Not Configured"
  navThresholdAvg=0
  trnThresholdAvg=0
  mobThresholdAvg=0
  stcThresholdAvg=0
  cntThresholdAvg=0
  cltThresholdAvg=0
  timeZoneOffset="+0"
  yMaxAcceptable=0
  clientProjPeak=0
fi

# Determine start and end time based on merged.data for overide of X range on long running responses
startTimeEpoch=`head -2 $2 | tail -1 | mawk -F"," '{printf "%d\n",$4/1000}'`
endTimeEpoch=`tail -1 $2 | mawk -F"," '{printf "%d\n",$4/1000}'`
startTimeEpoch=$(($startTimeEpoch+($timeZoneOffset*3600)-946684800));
endTimeEpoch=$(($endTimeEpoch+($timeZoneOffset*3600)-946684800));

#rendering_normal=""
rendering_normal="with lines"
rendering_smooth="with lines smooth bezier"
rendering_impulses="with impulses"
rendering=$rendering_normal

if [ $# -lt 1 ]; then
 echo "Syntax: $0 <testMappingFile> [input data file]"
 exit 1
fi

mappingFile=$1
shift

# Note: save the data somewhere because we need to scan it twice
# in order to compute the standard deviation
tmpFile="tmp/`hostname`_`basename $0`_$$"
cat $* > $tmpFile.1

# Translate test codes to a string using the mapping file and compute summaries
mawk -v mappingFile=$mappingFile '
BEGIN {
 FS=","
 while(  ( getline line < mappingFile ) == 1 ) {
   code=sprintf("%d", substr(line, 0, match(line, "[ \t]")))
   map[code]=substr(line, length(code)+2)
   #print code, "is", map[code]
 }
 close(mappingFile)
}
/^[0-9]/ {
  code=sprintf("%d", $3)
  if($6==0 && $7<400) {
    sum[map[code]]+=$5
    count[map[code]]++
  } else {
    errors[map[code]]++
  }
}
END {
 for(k in sum) {
  printf "%s\t%lu\t%d\n",
    k, sum[k]/count[k], count[k]
 }
}
' $tmpFile.1 > $tmpFile.2

echo "Transaction	Avg	Med	S-dev	90%	95%	99%	Min	Max	Pass	Fail	%Total	< 2	2-5	5-10	10+" > response_data.txt
#echo "Transaction\tAvg\tMed\tS-dev\t90%\t95%\t99%\tMin\tMax\tPass\tFail\t%Total\t< 2\t2-5\t5-10\t10+" > response_data.txt

# Re-read to compute the standard deviation
sort -T tmp -t , -b -n -k 5 $tmpFile.1 | mawk -v mappingFile=$mappingFile -v averageFile=$tmpFile.2 '
BEGIN {
 FS=","
 while(  ( getline line < mappingFile ) == 1 ) {
   code=sprintf("%d", substr(line, 0, match(line, "[ \t]")))
   map[code]=substr(line, length(code)+2)
   #print code, "is", map[code]
 }
 close(mappingFile)
 while(  ( getline line < averageFile ) == 1 ) {
   split(line,d, "\t")
   name=d[1]
   avg[name]=d[2]
   count[name]=d[3]
   min[name]=9999999999999
   max[name]=0
   median[name]=-1
   ninety[name]=-1
   ninetyfive[name]=-1
   ninetynine[name]=-1
   respunder2sec[name]=0
   resp2to5sec[name]=0
   resp5to10sec[name]=0
   resp10plussec[name]=0
   
 }
 close(averageFile)
}
/^[0-9]/ {
  code=sprintf("%d", $3)
  # Error = 0 and HTTP Response Code < 500
  if($6==0 && $7<500) {
    name=map[code]
    sos[name]+= ($5-avg[name])*($5-avg[name])
    if(min[name]>$5) { min[name]=$5 }
    if(max[name]<$5) { max[name]=$5 }
    running_count[name]++;
    if( (median[name]==-1) && (running_count[name] >= (count[name]/2)) ) {
      median[name]=$5
    }
    if( (ninety[name]==-1) && (running_count[name] >= (count[name]*0.90)) ) {
      ninety[name]=$5
    }
    if( (ninetyfive[name]==-1) && (running_count[name] >= (count[name]*0.95)) ) {
      ninetyfive[name]=$5
    }
    if( (ninetynine[name]==-1) && (running_count[name] >= (count[name]*0.99)) ) {
      ninetynine[name]=$5
    }
    if($5 < 2*1000) { respunder2sec[name]++; } 
    if(($5 > 2*1000) && ($5 < 5*1000)) { resp2to5sec[name]++; }
    if(($5 > 5*1000) && ($5 < 10*1000)) { resp5to10sec[name]++; }
    if($5 > 10*1000) { resp10plussec[name]++; }
  } else {
    errors[map[code]]++
  }
}
END {
 for(k in avg) {
  if( (count[k]-1) > 0) {
    stdev=sprintf("%f", sqrt(sos[k]/(count[k]-1))/1000.0)
  } else {
    stdev="n/a"
  }
  { printf "%s\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%d\t%d\t%.2f\t%d\t%d\t%d\t%d\n",
    k,
    avg[k]/1000.0, median[k]/1000.0,
    stdev,ninety[k]/1000.0,ninetyfive[k]/1000.0,ninetynine[k]/1000.0,
    min[k]/1000.0, max[k]/1000.0,
    count[k], errors[k], count[k]/NR*100, respunder2sec[k], resp2to5sec[k], resp5to10sec[k], resp10plussec[k] }
 }
}
' | sort -T tmp >> response_data.txt

# Create summary file for report_data.txt
# Adding hits / % total for static content as well
mawk '
BEGIN { 
FS="\t"
success=0
failure=0
staticContent=0
}
{
 if (NR < 2) { next }
 # Add up values
 success += $10
 failure += $11
 if ($1 ~ /Images/) { staticContent += $10+$11 }
 if ($1 ~ /Java Script/) { staticContent += $10+$11 }
 if ($1 ~ /CSS/) { staticContent += $10+$11 }
} 
END {
  failureRate=(failure/success)
  totalUseCases=(failure+success)
  staticContentPercent=((staticContent/totalUseCases)*100)
  printf "Successful\t%d\nFailed\t%d\nFailure Rate\t%.5f\nStatic Content Requests\t%d\nStatic Content Percent\t%.3f\nTotal Transactions\t%d\n",success,failure,failureRate,staticContent,staticContentPercent,totalUseCases
}
' response_data.txt >> report_data.txt

testLogins=`mawk -F"\t" '$0 ~ /Submit Login/ { printf "Logins\t%d\n" ,$10 }' response_data.txt >> report_data.txt`

# Find Max Response time in order to override if > X seconds
yMaxValue=`mawk 'BEGIN {FS = "\t"; max = 0} {if (NR>1 &&($9>max)) max=$9} END {printf "%.0f", max}' response_data.txt`

# Determine test duration (in Minutes) to override xtics (configured in seconds) for long running tests
reportData="report_data.txt"
if [ -f $reportData ]; then
   testDuration=`mawk -F"\t" '$1 ~ /Duration/ { printf "%.0f" ,$2 }' $reportData`
fi
if ! [[ "$testDuration" =~ ^[0-9]+$ ]] ; then
   echo "Error: testDuration is not an integer -- Setting to 1";
   testDuration=1
fi

# Set to 5 Minute Major and 1 Minute minor
xTics=300
mxTics=5
if [ $testDuration -ge 120 ]; then
   # Set to 30 Minute Major and 5 Minute minor
   xTics=1800
   mxTics=6
fi
if [ $testDuration -ge 480 ]; then
   # Set to 1  Hour Major and 15 Minute minor
   xTics=3600
   mxTics=4
fi

# Create the temp directory for various plots 
tempDir=./tmp$$
# Standard plot directorys
tempPlots=$tempDir/plots
mkdir -p $tempPlots
# Long running plot directory
tempLongPlots=$tempDir/long
mkdir $tempLongPlots
# Transaction plot directory
tempTxnPlots=$tempDir/txn
mkdir $tempTxnPlots
# Navigation plot directory
tempNavPlots=$tempDir/nav
mkdir $tempNavPlots
# Static Content plot directory
tempStcPlots=$tempDir/stc
mkdir $tempStcPlots
# Bb mobile plot directory
tempMobPlots=$tempDir/mob
mkdir $tempMobPlots
# Content System plot directory
tempCntPlots=$tempDir/cnt
mkdir $tempCntPlots
# Custom Use Case plot directory
tempCltPlots=$tempDir/clt
mkdir $tempCltPlots

# dispatch the different samples to their own file
mawk -v mappingFile=$mappingFile -v tempPlots="$tempPlots" -v tempLongPlots="$tempLongPlots" -v tempTxnPlots="$tempTxnPlots" -v tempNavPlots="$tempNavPlots" -v tempStcPlots="$tempStcPlots" -v tempMobPlots="$tempMobPlots" -v tempCntPlots="$tempCntPlots" -v tempCltPlots="$tempCltPlots" '
BEGIN {
 FS=","
 OFMT = "%.03f"
 epoch=-1
 while(  ( getline line < mappingFile ) == 1 ) {
   code=sprintf("%d", substr(line, 0, match(line, "[ \t]")))
   name=substr(line, length(code)+2)
   gsub(/[ \t]/, "_", name)
   map[code]=name
 }
 close(mappingFile)
}
/^[0-9]/ {
  if(epoch==-1) { epoch = $4/1000.0 }
  code=sprintf("%d", $3)
  if($6==0 && $7<400) {
  # Fix time stamps here
  #print $4/1000.0-epoch, $5/1000.0 >>  sprintf("%s/%s", tempPlots, map[code])
  print $4/1000.0, $5/1000.0 >>  sprintf("%s/%s", tempPlots, map[code])
  # Send responses > 10 sec to their own files in addition make dynamic based on client.info in future
  if($5>10000) {print $4/1000.0, $5/1000.00 >> sprintf("%s/%s", tempLongPlots, map[code])} 
  # dispatch STC, TXN, NAV, MOB, CNT and CLT transaction types to their own directories / files here
  if(map[code] ~ /TXN/) {print $4/1000.0, $5/1000.00 >> sprintf("%s/%s", tempTxnPlots, map[code])}
  if(map[code] ~ /NAV/) {print $4/1000.0, $5/1000.00 >> sprintf("%s/%s", tempNavPlots, map[code])}
  if(map[code] ~ /STC/) {print $4/1000.0, $5/1000.00 >> sprintf("%s/%s", tempStcPlots, map[code])}
  if(map[code] ~ /MOB/) {print $4/1000.0, $5/1000.00 >> sprintf("%s/%s", tempMobPlots, map[code])}
  if(map[code] ~ /CNT/) {print $4/1000.0, $5/1000.00 >> sprintf("%s/%s", tempCntPlots, map[code])}
  if(map[code] ~ /CLT/) {print $4/1000.0, $5/1000.00 >> sprintf("%s/%s", tempCltPlots, map[code])}
  }
}
' $tmpFile.1 


generatePlotLines() {
  while [ $# -ne 0 ]; do
   # Modify Key Titles here to remove __
   echo -n "'$1' using (timecolumn(1)$timeZoneOffset*3600):2 $rendering title '`basename $1 | mawk '{ gsub ("_", " ", $0); print}'`'"
   #echo -n "'$1' using timecolumn(1):2 $rendering title '`basename $1 | awk '{ gsub ("_", " ", $0); print}'`'"
   shift
   if [ $# -ne 0 ]; then
     echo ", \\"
   else
     echo ""
   fi
  done
}

# Parameter: 
# output file
# set plot specific settings for different use cases (Navigational, Transactional, Static Content, and Content System)
doPlot() {
 # Unset opt3 to clear for non trend graphs
 opt3=""
 # Break out long response plots
 if [ "$plotType" == "long" ]; then
    # Set yrange to 0 and max value (otherwise will start plots at low end of high range)
    title="set title \"Response Times Over 10 Seconds\" font \"Arial,12\" offset 0,1"
    ylabel="set ylabel \"Response Time(s)\" font \"Arial,10\" offset -4,0"
    opt="set yrange [0:*]"
    opt2="set xrange [\"$startTimeEpoch\":\"$endTimeEpoch\"]"
    opt3="set key on left top"
 else
  if [ ! -z "$OVERRIDE_YRANGE" ]; then
    opt="set yrange $OVERRIDE_YRANGE"
  elif [ $yMaxValue -gt $yMaxAcceptable ]; then
    opt="set yrange [0:$yMaxAcceptable]"
  else
    opt="#"
  fi
  if echo $rendering | grep -q smooth ; then
    qualifier="Trend "

  else
    qualifier=""
  fi
  title="set title \"Response Time $qualifier\" font \"Arial,12\" offset 0,1"
  ylabel="set ylabel \"Response Time $qualifier(s)\" font \"Arial,10\" offset -4,0"
  opt2="set xrange [*:*]"
 fi

 # Plot different response types
 if [ "$plotType" == "NAV" ]; then
  title="set title \"Navigational Response Time $qualifier\" font \"Arial,12\" offset 0,1"
  ylabel="set ylabel \"Navigational Response Time $qualifier(s)\" font \"Arial,10\" offset -4,0"
  
  # Set AVG response time requirements line for trend graphs
  opt3="set ytics add (\"NAV Avg Req\" $navThresholdAvg);"
  opt3+="set arrow from graph 0,first $navThresholdAvg to graph 1,first $navThresholdAvg nohead lc rgb \"#FF0000\" front;"
 fi
 if [ "$plotType" == "TXN" ]; then
  title="set title \"Transactional Response Time $qualifier\" font \"Arial,12\" offset 0,1"
  ylabel="set ylabel \"Transactional Response Time $qualifier(s)\" font \"Arial,10\" offset -4,0"
  
  # Set AVG response time requirements line for trend graphs
  opt3="set ytics add (\"TXN Avg Req\" $trnThresholdAvg);"
  opt3+="set arrow from graph 0,first $trnThresholdAvg to graph 1,first $trnThresholdAvg nohead lc rgb \"#FF0000\" front;"
 fi
 if [ "$plotType" == "STC" ]; then
  title="set title \"Static Content Response Time $qualifier\" font \"Arial,12\" offset 0,1"
  ylabel="set ylabel \"Static Content Response Time $qualifier(s)\" font \"Arial,10\" offset -4,0"
  
  # Set AVG response time requirements line for trend graphs
  opt3="set ytics add (\"STC Avg Req\" $stcThresholdAvg);"
  opt3+="set arrow from graph 0,first $stcThresholdAvg to graph 1,first $stcThresholdAvg nohead lc rgb \"#FF0000\" front;"
 fi
 if [ "$plotType" == "MOB" ]; then
  title="set title \"Bb Mobile Response Time $qualifier\" font \"Arial,12\" offset 0,1"
  ylabel="set ylabel \"Bb Mobile Response Time $qualifier(s)\" font \"Arial,10\" offset -4,0"
  
  # Set AVG response time requirements line for trend graphs
  opt3="set ytics add (\"MOB Avg Req\" $mobThresholdAvg);"
  opt3+="set arrow from graph 0,first $mobThresholdAvg to graph 1,first $mobThresholdAvg nohead lc rgb \"#FF0000\" front;"
 fi
 if [ "$plotType" == "CNT" ]; then
  title="set title \"Content System Response Time $qualifier\" font \"Arial,12\" offset 0,1"
  ylabel="set ylabel \"Content System Response Time $qualifier(s)\" font \"Arial,10\" offset -4,0"
  
  # Set AVG response time requirements line for trend graphs
   opt3="set ytics add (\"CNT Avg Req\" $cntThresholdAvg);"
   opt3+="set arrow from graph 0,first $cntThresholdAvg to graph 1,first $cntThresholdAvg nohead lc rgb \"#FF0000\" front;"
 fi
 if [ "$plotType" == "CLT" ]; then
  title="set title \"$clientName Custom Use Case Response Time $qualifier\" font \"Arial,12\" offset 0,1"
  ylabel="set ylabel \"$clientName Custom Use Case Response Time $qualifier(s)\" font \"Arial,10\" offset -4,0"
  
  # Set AVG response time requirements line for trend graphs
  opt3="set ytics add (\"CLT Avg Req\" $cltThresholdAvg);"
  opt3+="set arrow from graph 0,first $cltThresholdAvg to graph 1,first $cltThresholdAvg nohead lc rgb \"#FF0000\" front;"
 fi

  plotFile=./plot$$.plt
  cat > $plotFile <<EOF
set grid
$title
#set title "Response Time $qualifier" font "Arial,12" offset 0,1
#set terminal svg size 1200,450 fixed fname 'Arial' fsize 8 butt solid enhanced background rgb 'grey'
set terminal svg size 1200,500 fname 'Arial' fsize 8 butt solid
set obj 1 rectangle behind from screen 0,0 to screen 1,1
set obj 1 fillstyle solid 1.0 fc rgb "#F5F5F5"
set obj 2 rectangle from graph 0, graph 0 to graph 1, graph 1 behind fc rgbcolor 'white' fs noborder
#set terminal png size 1200,450
set autoscale
set xlabel "Time\n\n$clientName - $testName\n" font "Arial,10" offset 0,-1
$ylabel
#set ylabel "Response Time $qualifier(s)" font "Arial,10" offset -4,0
set xdata time
# Set input time to Epoch
set timefmt "%s"
$opt2
#set xrange ["$startTimeEpoch":"$endTimeEpoch"]
# Set output time of minutes
#set format x "%b %d %H:%M"
set format x "%H:%M"
set xtics font "Arial,10"
set xtics nomirror
set xtics in 
set xtics rotate by 45 right
set xtics offset 0,-1
set xtics $xTics
set mxtics $mxTics 
set ytics font "Arial,10"
#set ytics 1
# Threshold lines
#set style line 1 lt 1 lw 1
#set style arrow 1 nohead ls 1
$opt3
#set ytics add ("Nav Avg Req" $navThresholdAvg)
#set arrow from graph 0,first $navThresholdAvg to graph 1,first $navThresholdAvg nohead lc rgb "#FF0000" front
#set ytics add ("Trs Avg Req" $trnThresholdAvg)
#set arrow from graph 0,first $trnThresholdAvg to graph 1,first $trnThresholdAvg nohead lc rgb "#FF0000" front
#set grid ytics lc rgb "#bbbbbb" lw 1 lt 0
#set grid xtics lc rgb "#bbbbbb" lw 1 lt 0
$opt
set output "$1"
plot \\
EOF
  if [ "$plotType" == "long" ]; then
   generatePlotLines `find $tempLongPlots -type f` >> $plotFile
  elif [ "$plotType" == "TXN" ]; then
   generatePlotLines `find $tempTxnPlots -type f` >> $plotFile
  elif [ "$plotType" == "NAV" ]; then
   generatePlotLines `find $tempNavPlots -type f` >> $plotFile
  elif [ "$plotType" == "STC" ]; then
   generatePlotLines `find $tempStcPlots -type f` >> $plotFile
  elif [ "$plotType" == "MOB" ]; then
   generatePlotLines `find $tempMobPlots -type f` >> $plotFile
  elif [ "$plotType" == "CNT" ]; then
   generatePlotLines `find $tempCntPlots -type f` >> $plotFile
  elif [ "$plotType" == "CLT" ]; then
   generatePlotLines `find $tempCltPlots -type f` >> $plotFile
  else
   generatePlotLines `find $tempPlots -type f` >> $plotFile
  fi
  
  gnuplot $plotFile
  rm -f $plotFile
}
# Plot All use cases real time and trends
plotType="All";
rendering=$rendering_normal ; doPlot response.svg
rendering=$rendering_smooth ; doPlot response_trend.svg
# Plot transactional use cases
if [ "$(ls -A $tempTxnPlots)" ]; then
 plotType="TXN";
 rendering=$rendering_normal;
 doPlot transactionalResponse.svg
 rendering=$rendering_smooth;
 doPlot transactionalResponse_trend.svg
fi
# Plot navigational use cases
if [ "$(ls -A $tempNavPlots)" ]; then
 plotType="NAV";
 rendering=$rendering_normal;
 doPlot navigationalResponse.svg
 rendering=$rendering_smooth;
 doPlot navigationalResponse_trend.svg
fi
# Plot static content responses
if [ "$(ls -A $tempStcPlots)" ]; then
 plotType="STC";
 rendering=$rendering_normal;
 doPlot staticContentResponse.svg
 rendering=$rendering_smooth;
 doPlot staticContentResponse_trend.svg
fi
# Plot Bb Mobile responses
if [ "$(ls -A $tempMobPlots)" ]; then
 plotType="MOB";
 rendering=$rendering_normal;
 doPlot bbMobileResponse.svg
 rendering=$rendering_smooth;
 doPlot bbMobileResponse_trend.svg
fi
# Plot Content System responses
if [ "$(ls -A $tempCntPlots)" ]; then
 plotType="CNT";
 rendering=$rendering_normal;
 doPlot contentResponse.svg
 rendering=$rendering_smooth;
 doPlot contentResponse_trend.svg
fi
# Plot Client Custom Use Case responses
if [ "$(ls -A $tempCltPlots)" ]; then
 plotType="CLT";
 rendering=$rendering_normal;
 doPlot customResponse.svg
 rendering=$rendering_smooth;
 doPlot customResponse_trend.svg
fi
# Plot long running responses if they exist
if [ "$(ls -A $tempLongPlots)" ]; then
 plotType="long";
 rendering=$rendering_impulses; 
 doPlot longResponse.svg
fi

#rm -r $tempDir
#rm $tmpFile.*
