#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#########################################################################
# Plot the number of active threads
# Input: merged data file or single grinder file either as arg or from stdin
# Output: <date in seconds> <count>

testName=`echo $PWD | sed "s/.*\/reports\///"`
clientInfo='client.info'
if [ -f $clientInfo ]; then
  clientName=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "CLIENT_NAME") { print $2 }}'`
  # Need to verify the following are properly set / numbers
  timeZoneOffset=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "TIMEZONE") { print $2 }}'`
else
  timeZoneOffset=0
fi

# Determine test duration (in Minutes) to override xtics (configured in seconds) for long running tests
reportData="report_data.txt"
if [ -f $reportData ]; then
   testDuration=`mawk -F"\t" '$1 ~ /Duration/ { printf "%.0f" ,$2 }' $reportData`
fi
if ! [[ "$testDuration" =~ ^[0-9]+$ ]] ; then
   echo "Error: testDuration is not an integer -- Setting to 1";
   testDuration=1
fi

# Set to 5 Minute Major and 1 Minute minor
xTics=300
mxTics=5
if [ $testDuration -ge 120 ]; then
   # Set to 30 Minute Major and 5 Minute minor
   xTics=1800
   mxTics=6
fi
if [ $testDuration -ge 480 ]; then
   # Set to 1  Hour Major and 15 Minute minor
   xTics=3600
   mxTics=4
fi

mawk '
BEGIN {FS=","; OFMT = "%.0f"; last=0.0; epoch=-1}
/^[0-9]/ {
  threadid=sprintf("%s:%s", $13, $1); running[threadid]=1;
  date=$4/1000.0;
  if(epoch==-1) { epoch=date }
  epochdate=date
  date=date-epoch
  if((date-last)>1.0) {
    count=0; for(k in running) {count++};
    print epochdate, count;
    last=date;
  }
}
#END { print date+1.0, 0 } # For pretty graphs...
' $1 > running_data.txt

# Find peak running threads
peakThreads=`cat running_data.txt | mawk 'BEGIN {max=0} {if ($2 > max){max=$2}} END {print max}'`

# In future, Determine yRange.  Round up to nearest 10
# For now just set at peak
# Find largest number in running_data.txt
#sort -nrk1,2 running_data.txt | head -1 | mawk '{print $2}'
yRange=$peakThreads

gnuplot <<EOF
set title "Running Grinder Threads" font "Arial,12"
set terminal svg size 1200,450 fixed fname 'Arial' fsize 10 butt solid
set obj 1 rectangle behind from screen 0,0 to screen 1,1
set obj 1 fillstyle solid 1.0 fc rgb "#F5F5F5"
set obj 2 rectangle from graph 0, graph 0 to graph 1, graph 1 behind fc rgbcolor 'white' fs noborder
#set terminal png size 1200,450
set autoscale
set out "running.svg"
#set out "running.png"
set grid 
set key off
# Line style 
set style line 1 linecolor rgb "#475ad9" pt 2 ps 1 lt 1 lw 1
set xtics font "Arial,10"
set xtics nomirror
set xtics in
set xtics rotate by 45 right 
set xtics offset 0,-1
set xdata time
# Set input time of seconds
#set timefmt "%S"
# Set input time to Epoch
set timefmt "%s"
# Set output time of minutes
#set format x "%b %d %H:%M"
set format x "%H:%M"
# Set tic marks per above (5 min major and 1 minute minor) default for most tests
set yrange [0:$yRange]
set xtics $xTics 
set mxtics $mxTics 
set ytics font "Arial,10"
set xlabel "Time\n\n$clientName - $testName" font "Arial,10" offset 0,-1
set ylabel "Running Threads" font "Arial,10"
set key on
# Print max hits on graph
set label 1 gprintf("Max Threads = %'.0f", $peakThreads)
set label 1 at graph .01,.93 left
# Run the plot
plot "running_data.txt" every 1:1 using (timecolumn(1)$timeZoneOffset*3600):2 ls 1 with lines title "Running Threads"
EOF
