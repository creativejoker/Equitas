#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#
# Merge all the grinder output files (out_*.log) into a single meta file
# Input: directories to search for data files (defaults to .)
# Ouput: merged data to stdout. the format is similar to the original
# format except for an additional first column for the current time
# in seconds since 1970
# Note: for multi-line outputs, only the first line is retained
# version 1.0 - initial
# Version 2.0 - updated script to use parallel to process the files faster - DCHOW 7/26/2018 

if [ -z "$*" ]; then
  search=.
else
  search="$*"
fi

#TODO Check to see if Parallel &MAWK Exist
#parallel -v 2>&1 || { echo >&2 "Parallel is required but it's not installed.  Aborting."; exit 1; }
#mawk -v 2>&1 || { echo >&2 "Mawk is required but it's not installed.  Aborting."; exit 1; }


find $search -name out_\*.log.gz  | parallel --gnu --tmpdir tmp  'zcat {}| mawk -f ../../analysis/awk/merge_out.awk' | sort -T tmp -n -k 1
 
#Temp Fix for extra GET in staryer test results (Tim Livers 12-11-2017)
#sed -i 's/GET //' merged.out
