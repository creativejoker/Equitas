#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

#########################################################################
# Plot the throughput in bytes over a 60s sampling period
# Input: merged data file or single grinder file either as arg or from stdin
# Output: data file, graph

testName=`echo $PWD | sed "s/.*\/reports\///"`
clientInfo='client.info'
if [ -f $clientInfo ]; then
  clientName=`cat $clientInfo | mawk -F"\t" '{ if ($1 == "CLIENT_NAME") { print $2 }}'`
  # Need to verify the following are properly set / numbers
  timeZoneOffset=`cat $clientInfo | mawk -F "\t" '{ if ($1 == "TIMEZONE") { print $2 }}'`
  clientProjPeak=`cat $clientInfo | mawk -F"\t" '{ if ($1 == "PROJECTED_PEAK") { print $2 }}'`
  clientNumAppServer=`cat $clientInfo | mawk -F"\t" '$1 == "NUM_APP_SERVER" { print $2 }'`
else
  clientName="Not Configured"
  clientProjPeak=0
  timeZoneOffset="+0"
fi
projPeakPerServer=$(($clientProjPeak / $clientNumAppServer))

echo "Date Hits/s" > hits_data.txt

mawk '
BEGIN {last=0; sum=0; total=0; start=-1}
/https?:\/\// {
  sum++; total++
  date=$1;
  if(start==-1) {start=date;}
  if((date-last)>=60.0) {
     if((sum/(date-last))<1) { 
        print date, "0";
	}
     else {
        #print date-start, sum/(date-last);
        print date, sum/(date-last);
	}
    last=date; 
    sum=0;
  }
}
END {
# Prints out final timestamp for cleaner graphs
# if((date-last)>20) {print date-start, sum/(date-last);}
if((date-last)>20) {print date, sum/(date-last);}
# Print out summary file for use in report generation
printf "Total Hits\t%d\nAverage Throughput (hits/hr)\t%d\nDuration\t%d\n", total, ((total)/(date-start)*(3600)),((date-start)/(60)) >> "report_data.txt" 
}
' $1 >> hits_data.txt

# Determine test duration (in Minutes) to override xtics (configured in seconds) for long running tests
reportData="report_data.txt"
if [ -f $reportData ]; then
   testDuration=`awk -F"\t" '$1 ~ /Duration/ { printf "%.0f" ,$2 }' $reportData`
fi
if ! [[ "$testDuration" =~ ^[0-9]+$ ]] ; then
   echo "Error: testDuration is not an integer -- Setting to 1";
   testDuration=1
fi

# Set to 5 Minute Major and 1 Minute minor
xTics=300
mxTics=5
if [ $testDuration -ge 120 ]; then
   # Set to 30 Minute Major and 5 Minute minor
   xTics=1800
   mxTics=6
fi
if [ $testDuration -ge 480 ]; then
   # Set to 1  Hour Major and 15 Minute minor
   xTics=3600
   mxTics=4
fi

# Sort through hits data and pull out the peak hits / min and convert to peak hits / hour 
peakHits=`mawk 'BEGIN {max=0} NR < 2 { next } {if ($2 > max){max=$2}} END { printf "%d",(max*3600) }' hits_data.txt`

# set YRange to greater of peakHits or clientProjPeak
if [ $peakHits -lt $clientProjPeak ]; then
    yRange=($clientProjPeak+10000); 
else
    yRange=$peakHits;
fi

# Plot the data for the hits graph
gnuplot << EOF
# set title "Throughput (Hits/Hr)" font "Arial 16" textcolor rgb "#475ad9"
set title "Throughput (Hits/Hr)" font "Arial,12" offset 0,1
set terminal svg size 1200,450 fixed fname 'Arial' fsize 10 butt solid
set obj 1 rectangle behind from screen 0,0 to screen 1,1
set obj 1 fillstyle solid 1.0 fc rgb "#F5F5F5"
set obj 2 rectangle from graph 0, graph 0 to graph 1, graph 1 behind fc rgbcolor 'white' fs noborder
#set terminal png size 1200,400
set autoscale
set out "hits.svg"
#set out "hits.png"
set grid 
set xdata time
# Set input time to Epoch
set timefmt "%s"
# Set output time of minutes
#set format x "%b %d %H:%M"
set format x "%H:%M"
# Set tic marks to 5 min major and 1 minute minor
set xtics $xTics 
set mxtics $mxTics 
set xtics nomirror
set xtics in
set xtics rotate by 45 right
set xtics offset 0,-1
#set xtics border
set ytics font "Arial,10"
set xlabel "Time\n\n$clientName - $testName" font "Arial,10" offset 0,-1 
set ylabel "Throughput(hits/hr)" font "Arial,10"
set decimal locale
set format y "%'.0f"
#set format y "%12.f"
# Uncomment the following to override yrange  with calc value and Add Projected Peak Line for reference
set yrange [0:$yRange]
set ytics add ("Projected Peak" $clientProjPeak)
set arrow from graph 0,first $clientProjPeak to graph 1,first $clientProjPeak nohead lc rgb "#FF0000" front
# Line style for axes
set style line 1 linecolor rgb "#475ad9" pt 2 ps 1 lt 1 lw 1
set style line 2 linecolor rgb "#2e8b57" pt 2 ps 1 lt 1 lw 1
# Print max hits on graph
set label 1 gprintf("Max Hits / Hour = %'.0f", $peakHits)
set label 1 at graph .2,.95 right 
set label 2 gprintf("Projected Peak =  %'.0f", $clientProjPeak)
set label 2 at graph .2,.88 right
set label 3 gprintf("Projected Peak / Server =  %'.0f", $projPeakPerServer)
set label 3 at graph .2,.81 right 
# fix for variable usage in plot
c2=2
plot "hits_data.txt" every ::1 using (timecolumn(1)$timeZoneOffset*3600):(3600*(column(c2))) ls 1 with lines title "Absolute Throughput", "hits_data.txt" every ::1 using (timecolumn(1)$timeZoneOffset*3600):(3600*(column(c2))) ls 2 with lines title "Running Average" smooth bezier
EOF
