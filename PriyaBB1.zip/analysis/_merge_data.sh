#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#
# Merge all the grinder files (data_*.log) into a single meta file
# Input: directories to search for data files (defaults to .)
# Ouput: merged data to stdout. the format is backward-compatible
# with standard grinder files, just with an extra column at the end
# version 1.0 - initial
# Version 2.0 - updated script to use parallel to process the files faster - DCHOW 7/26/2018

if [ -z "$*" ]; then
  search=.
else
  search="$*"
fi

#Print Header first, it's always goign to be the same
echo "Thread, Run, Test, Start time (ms since Epoch), Test time, Errors, HTTP response code, HTTP response length, HTTP response errors, Time to resolve host, Time to establish connection, Time to first byte, Source"

#Doing a double parallel here. In order to do that you need to escape '"$\ in the mawk statement

find $search -name data_\*.log.gz -print | parallel --gnu --tmpdir tmp 'zcat {}| mawk -f ../../analysis/awk/merge_data.awk' | sort -T tmp -n -k 4 -t ,
 
