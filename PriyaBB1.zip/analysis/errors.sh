#!/bin/sh

# (C) Copyright Blackboard Inc. 2018 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#########################################################################
# Plot the number of errors and successes over a 10s sampling period
# Input: merged data file or single grinder file either as arg or from stdin
# Output: data file, graph

echo "Date Passed/s Failed/s" > errors_data.txt
awk '
BEGIN {FS=","; last=0.0; start=-1}
/^[0-9]/ {
  if($7<400) {
    ok++; totalOk++;
  } else {
    error++; totalError++;
  }
  date=$4/1000.0;
  if(start==-1) {start=date}
  if((date-last)>10.0) {
    print date, ok/(date-last), error/(date-last);
    last=date; ok=0; error=0;
  }
}
END {
print date+60.0, 0;
}
' $1 >> errors_data.txt


gnuplot <<EOF
set term png
set out "errors.png"
set grid 
set xlabel "Time (s)"
set ylabel "Counts/s"
# Run the plot
plot "errors_data.txt" using 1:2 with lines title "Passed", "errors_data.txt" using 1:3 with lines title "Failed"
EOF
