#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#
# Compute various session statistics from grinder logs.
# Counts the number of user logins in an ten minute and hour period
# based on the logs, assumes login was successful 
# 8/6/13 7:11:13 AM (thread 4 run 1 test 1): Logging in user000020746 with pass

# This script supports compressed or uncompressed files as well
# as reading from standard input.
# Typical syntaxes:
# zcat results/<testname>/*/out*.gz | ./grinder_session_statistics.sh > sessions.txt
# ./grinder_session_statistics.sh results/<testname>/*/out*.gz > sessions.txt
# ./grinder_session_statistics.sh results/<testname>/*/out*.gz> sessions.txt

# Warning: the input files are sorted by modified date.

testName=`echo $PWD | sed "s/.*\/reports\///"`
clientInfo='client.info'
if [ -f $clientInfo ]; then
  clientName=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "CLIENT_NAME") { print $2 }}'`
  # Need to verify the following are properly set / numbers
  timeZoneOffset=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "TIMEZONE") { print $2 }}'`
else
  clientName="Not Configured"
  timeZoneOffset="+0"
fi

if date --date "`date`" > /dev/null ; then
  /bin/true
else
  echo "`which date` does not support the --date option" >&2
  exit 1
fi

if [ -z "$*" ]; then
  search=.
else
  search="$*"
fi

#find $search -name out_\*.log.gz -print -exec zcat {} \; | grep 'Logging in' | \
cat merged.data | \
mawk -F "," '
NR < 2 { next }
{
#hour = strftime("%b/%d:%H",($4/1000))
min = strftime("%b/%d:%H:%M",($4/1000))
grinderThread = sub(/^[ ]+/,"",$2)
grinderThreadRun = $1":"$2
# unique grinder threads / min
uniqueThreadsPerMin[min"-"grinderThreadRun]=1
# Hard code login test number (1) to position 3 (grinder test number column
if ( $3 == 1 ) {
#Session per hour based on grinder login use case
#loginsPerHour[hour]++;
#Sessions per min
loginsPerMin[min]++;
}
}
END {
#for(hour in loginsPerHour) {
#  printf "%s %d\n",hour,loginsPerHour[hour];
#  printf "%s %d\n",hour,loginsPerHour[hour] > "tmp_logins_per_hour.txt";
#  }
for(min in loginsPerMin) {
  #printf "%s %d\n",min,loginsPerMin[min];
  printf "%s %d\n",min,loginsPerMin[min] > "tmp_logins_per_min_data.txt";
  }
#for(time in uniqueThreadsPerHour) {
# printf "%d %d",time,uniqueThreadsPerHour[time] > "tmp_threadrun_per_hour.txt";
# }
for(min in uniqueThreadsPerMin) {
  split (min,a,"-")
  printf "%s\n",a[1] > "tmp_threadrun_per_min_data.txt";
  }

#print "Total Sessions per test: " totalSessionsbyUserID
#print "Total Unique Sessions per test: " unqiueSessionsbyUserIDTotal
}
'

#cat tmp_logins_per_hour.txt| sort -T tmp -s -t ' ' -k1.8n -k1.4M -k 1.1n -k 1.13n > logins_per_hour.txt
cat tmp_logins_per_min_data.txt | sort -T tmp -s -t ' ' > logins_per_min_data.txt
#cat tmp_threadrun_per_hour.txt| sort -T tmp -s -t ' ' -k1.8n -k1.4M -k 1.1n -k 1.13n > threadrun_per_hour.txt
cat tmp_threadrun_per_min_data.txt| sort -T tmp -s -t ' ' | uniq -c | awk '{print $2,$1}' > threadrun_per_min_data.txt

# Determine test duration (in Minutes) to override xtics (configured in seconds) for long running tests
reportData="report_data.txt"
if [ -f $reportData ]; then
   testDuration=`mawk -F"\t" '$1 ~ /Duration/ { printf "%.0f" ,$2 }' $reportData`
fi
if ! [[ "$testDuration" =~ ^[0-9]+$ ]] ; then
   echo "Error: testDuration is not an integer -- Setting to 1";
   testDuration=1
fi

# Set to 5 Minute Major and 1 Minute minor
xTics=300
mxTics=5
if [ $testDuration -ge 120 ]; then
   # Set to 30 Minute Major and 5 Minute minor
   xTics=1800
   mxTics=6
fi
if [ $testDuration -ge 480 ]; then
   # Set to 1  Hour Major and 15 Minute minor
   xTics=3600
   mxTics=4
fi


gnuplot <<EOF
set terminal svg size 1200,450 fixed fname 'Arial' fsize 10 butt solid
set obj 1 rectangle behind from screen 0,0 to screen 1,1
set obj 1 fillstyle solid 1.0 fc rgb "#F5F5F5"
set obj 2 rectangle from graph 0, graph 0 to graph 1, graph 1 behind fc rgbcolor 'white' fs noborder
# Line style for text, currently grey
set style line 2 lt rgb "#595959"
set autoscale
set xdata time
#set timefmt "%m/%d/%Y:%H:%M"
set timefmt "%b/%d:%H:%M"
#set format x "%b %d %H:%M"
set format x "%H:%M"
set grid 
set key on
set style line 1 linecolor rgb "#475ad9" pt 2 ps 1 lt 1 lw 1
set xtics font "Arial,10"
set xtics nomirror
set xtics in
set xtics rotate by 45 right
set xtics offset 0,-1
set xlabel "Time\n\n$clientName - $testName" font "Arial,10" offset 0,-1
set ylabel "Logins" font "Arial,10" offset -1,0
set xtics $xTics 
set mxtics $mxTics 
set ytics font "Arial,10"
set out "logins_per_min.svg"
# Add mean to graphs per below if desired
#f(x) = mean_y
#        fit f(x) "sessions_per_min.txt" every ::1 using 1:2 via mean_y
#set label 1 gprintf("Mean = %'12.0f", mean_y)
#    set label 1 at graph .98, 0.85 textcolor ls 2 right
set title "Logins / Min" font "Arial,12"
plot  "logins_per_min_data.txt" using (timecolumn(1)):2 ls 1 with lines title "Logins per Minute"
set title "Unique Grinder Threads / Min" font "Arial,12"
set ylabel "Unique Grinder Threads" font "Arial,10"
set out "threadrun_per_min.svg"
# Add mean to graphs per below if desired
#f(x) = mean_y
#        fit f(x) "threadrun_per_min.txt" every ::1 using 1:2 via mean_y
#set label 1 gprintf("Mean = %'12.0f", mean_y)
#    set label 1 at graph .98, 0.85 textcolor ls 2 right
plot  "threadrun_per_min_data.txt" using (timecolumn(1)):2 ls 1 with lines title "Unique Grinder Threads per Minute"
EOF

#rm tmp_logins_per_min.txt tmp_logins_per_hour.txt
#rm tmp_threadrun_per_min.txt tmp_threadrun_per_hour.txt
