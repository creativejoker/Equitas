#!/bin/sh

# (C) Copyright Blackboard Inc. 2018 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#########################################################################
# Plot the HTTP status code distribution
# Input: merged data file or single grinder file either as arg or from stdin
# Output: data file, list of non 200 response codes and specific errors / counts 

outFile='http_data.txt'
echo -e "HTTP Status Code\tCount" > $outFile 
mawk '{if ($(NF-3)~/[0-9]+/){print $(NF-3)}if($0~/302 Moved Temporarily/){print  "302"}}' $1 | sort -T tmp | uniq -c | awk '{printf "%s\t%'"'"'d\n",$2,$1}'  >> $outFile

# List of error codes / counts / URI's 
# Note: if you wanted to add a full list with timestamp, create another file and print col $3 and $4
outFile='http_error_counts.txt'
echo -e "HTTP Status Code\tCount\tURI" >> $outFile
#awk '{if ($(NF-3) != '200' && $(NF-3)~/[0-9]+/){print $(NF-3)"\t"$0}if($0~/302 Moved Temporarily/){print  "302\t"$11}}' $1 | sort -T tmp | uniq -c | awk '{print $2"\t"$1"\t"$3}' >> $outFile
mawk '{if ($(NF-3) != '200' && $(NF-3)~/^[0-9][0-9][0-9]/){print $(NF-3)"\t"$(NF-5)}if($0~/302 Moved Temporarily/){print  "302\t"$11} if ($(NF)!~/bytes/) { print "Bad-Line\t"$(NF) }}' $1 | sort -T tmp | uniq -c | mawk '{print $2"\t"$1"\t"$3}' >> $outFile

# List of servers hit and hits/ server / % of total hits 
outFile='servers_data.txt'
echo -e "Server\tHits\t% Total" > $outFile
#awk '{split($11,a,":"); print a[2]}' $1 | sort -T tmp | uniq -c | awk 'BEGIN {total=0} {total +=$1; gsub(/\/\//, "", $2); perServer[$2]=$1} END{for (c in perServer) {print c"\t"perServer[c]"\t"(perServer[c]/total)}}' >> $outFile
mawk '{split($11,a,"/"); print a[3]}' $1 | sort -T tmp | uniq -c | awk 'BEGIN {total=0} {total +=$1; gsub(/\/\//, "", $2); perServer[$2]=$1} END {for (c in perServer) { printf "%s\t%'"'"'d\t%.2f\n",c,perServer[c],(perServer[c]/total)*100 }}' >> $outFile

# List of long running response times in ranges (Future dev, 10-30,30-60,60+?
#outFile='http_log_running_10-30_sec.txt'
#echo -e "tus Code\tCount\tURI" >> $outFile
#awk '{if ($13 != '200') {print $13"\t"$11}}' $1 | sort -T tmp | uniq -c | awk '{print $2"\t"$1"\t"$3}' >> $outFile

exit
