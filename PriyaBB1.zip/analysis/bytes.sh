#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

#########################################################################
# Plot the throughput in bytes over a 10s sampling period
# Input: merged data file or single grinder file either as arg or from stdin
# Output: data file, graph

# Thread, Run, Test, Start time (ms since Epoch), Test time, Errors, HTTP response code, HTTP response length, HTTP response errors, Time to resolve host, Time to establish connection, Time to first byte, Source

testName=`echo $PWD | sed "s/.*\/reports\///"`
clientInfo='client.info'
if [ -f $clientInfo ]; then
  clientName=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "CLIENT_NAME") { print $2 }}'`
  # Need to verify the following are properly set / numbers
  timeZoneOffset=`cat $clientInfo | mawk 'BEGIN { FS="\t" } { if ($1 == "TIMEZONE") { print $2 }}'`
else
  clientName="Not Configured"
  timeZoneOffset="+0"
fi

# Determine test duration (in Minutes) to override xtics (configured in seconds) for long running tests
reportData="report_data.txt"
if [ -f $reportData ]; then
   testDuration=`mawk -F"\t" '$1 ~ /Duration/ { printf "%.0f" ,$2 }' $reportData`
fi
if ! [[ "$testDuration" =~ ^[0-9]+$ ]] ; then
   echo "Error: testDuration is not an integer -- Setting to 1";
   testDuration=1
fi

# Set to 5 Minute Major and 1 Minute minor
xTics=300
mxTics=5
if [ $testDuration -ge 120 ]; then
   # Set to 30 Minute Major and 5 Minute minor
   xTics=1800
   mxTics=6
fi
if [ $testDuration -ge 480 ]; then
   # Set to 1  Hour Major and 15 Minute minor
   xTics=3600
   mxTics=4
fi

echo "Date Bytes/s" > bytes_data.txt

mawk '
BEGIN {FS=","; OFMT = "%.0f"; last=0.0; sum=0; total=0; epoch=-1}
/^[0-9]/ {
  sum+=$8; total+=$8
  date=$4/1000.0;
  if(epoch==-1) { epoch=date }
  epochdate=date
  date=date-epoch;
  if(start==-1) {start=date}
  if((date-last)>10.0) {
    print epochdate, sum/(date-last);
    last=date; sum=0
  }
}
END {
#print date+60.0, 0;
printf "Total Mb Transferred\t%d\nAverage Throughput (Mb/s)\t%.2f\n", (total/1024/1024), (total/(date-start)/1024/1024) >> "report_data.txt" }
' $1 >> bytes_data.txt

# Determine peak Mb/s throughput
peakMbPerSec=`cat bytes_data.txt | mawk 'BEGIN {max=0} NR < 2 { next } {if ($2 > max){max=$2}} END { printf "%.2f",(max/1024/1024) }'`

gnuplot <<EOF
set title "Throughput (Mb/s)" font "Arial,12"
set terminal svg size 1200,450 fixed fname 'Arial' fsize 10 butt solid
set obj 1 rectangle behind from screen 0,0 to screen 1,1
set obj 1 fillstyle solid 1.0 fc rgb "#F5F5F5"
set obj 2 rectangle from graph 0, graph 0 to graph 1, graph 1 behind fc rgbcolor 'white' fs noborder
#set terminal png size 1200,450
#set autoscale
set out "bytes.svg"
#set out "bytes.png"
set grid xtics ytics layerdefault back 
#show grid
set xdata time
# Set input time to Epoch
set timefmt "%s"
# Set output time of minutes
#set format x "%b %d %H:%M"
set format x "%H:%M"
# Set tic marks to 5 min major and 1 minute minor
set xtics $xTics
set mxtics $mxTics 
set xtics font "Arial,10"
set xtics nomirror
set xtics in 
set xtics rotate by 45 right
set xtics in offset 0,-1
set ytics font "Arial,10"
set xlabel "Time\n\n$clientName - $testName" font "Arial,10" offset 0,-1
set ylabel "Throughput(Mb/s)" font "Arial,10"
set decimal locale
# Set to bytes (readable)
#set format y "%'12.${dP}f"
# Convert to Mb
set format y '%.0s%cB'
# Line style for axes
set style line 1 linecolor rgb "#475ad9" pt 2 ps 1 lt 1 lw 1
set style line 2 linecolor rgb "#2e8b57" pt 2 ps 1 lt 1 lw 1
# Line style for grid
#set style line 81 lt 0  # dashed
#set style line 81 lt rgb "#808080"  # grey
# Print Peak Mb/s on graph
set label 1 gprintf("Peak = %'.2f Mb/s", $peakMbPerSec)
set label 1 at graph .01,.93 left
# Run the plot
plot "bytes_data.txt" every ::1 using (timecolumn(1)$timeZoneOffset*3600):2 ls 1 with lines title "Absolute Throughput", "bytes_data.txt" every ::1 using (timecolumn(1)$timeZoneOffset*3600):2 ls 2 with lines title "Running Average" smooth bezier
EOF
