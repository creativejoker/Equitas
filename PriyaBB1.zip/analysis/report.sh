#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#########################################################################
base=`dirname $0`
# 1) Merged data
mergedData="./merged.data"
# 2) Merged logs
mergedOut="./merged.out"
# Report Data File
reportData="report_data.txt"

# Grab Report Data to Populate into HTML Below
clientInfo='client.info'
if [ -f $clientInfo ]; then
  clientName=`cat $clientInfo | mawk -F"\t" '$1 == "CLIENT_NAME" { print $2 }'`
  # Need to verify the following are numbers
  clientProjPeak=`cat $clientInfo | mawk -F"\t" '$1 == "PROJECTED_PEAK" { print $2 }'`
  #if (![ $clientProjPeak =~ '^[0-9]+' ]); then
  #   clientProjPeak=0
  #fi
  clientNumAppServer=`cat $clientInfo | mawk -F"\t" '$1 == "NUM_APP_SERVER" { print $2 }'`
else
  clientName="Not Configured"
  clientProjPeak=0
  clientNumAppServer=0
fi
peakPerServer=`printf "%'.f\n" $(($clientProjPeak / $clientNumAppServer))`
testName=`echo $PWD | sed "s/.*\/reports\///"`
startDate=`head -1 $mergedOut | mawk '{print $2, $3, $4}'`
# Objective (use from autoq config)
testObjective=`cat text_objective.txt`
# Target (use target from autoq config)
testTarget=`cat text_target.txt`
# Test Access Method (use from autoq config)
testAccessMethod=`cat text_accessmethod.txt`
# Traffic Volume 
testVolume=`cat text_volumeoftraffic.txt`
# Extract Various Report Data from $reportData file compiled in individual scripts
testNumUseCases=$((`cat response_data.txt | wc -l` -1))
totalHits=`mawk -F"\t" '$1 ~ /Total Hits/ { print $2 }' $reportData`
avgThroughputHits=`mawk -F"\t" '$1 ~ /Average Throughput \(hits\/hr\)/ { print $2 }' $reportData`
testDuration=`mawk -F"\t" '$1 ~ /Duration/ { printf "%.0f" ,$2 }' $reportData`
testLogins=`mawk -F"\t" '$1 ~ /Login/ { print $2 }' $reportData`
successfulRequests=`mawk -F"\t" '$1 ~ /Successful/ { print $2 }' $reportData`
failedRequests=`mawk -F"\t" '$1 ~ /Failed/ { print $2 }' $reportData`
failureRate=`mawk -F"\t" '$1 ~ /Failure Rate/ { print $2 }' $reportData`
totalMb=`mawk -F"\t" '$1 ~ /Total Mb Transferred/ { print $2 }' $reportData`
avgThroughputMb=`mawk -F"\t" '$1 ~ /Average Throughput \(Mb\/s\)/ { print $2 }' $reportData`
staticContentRequests=`mawk -F"\t" '$1 ~ /Static Content Requests/ { print $2 }' $reportData`
staticContentPercent=`mawk -F"\t" '$1 ~ /Static Content Percent/ { print $2 }' $reportData`
# Check Data and calculate as needed
avgHitsPerSession="Calculation Error";
if ! [[ "$totalHits" =~ ^[0-9]+$ ]] ; then
   echo "Error: totalHits is not an integer -- Excluding";
   #exec >&2; echo "Error: totalHits is not an integer"; exit 1
elif ! [[ "$testLogins" =~ ^[0-9]+$ ]] ; then
   echo "Error: testLogins is not an integer -- Excluding";
else
   avgHitsPerSession=$(($totalHits / $testLogins))
fi

# Check for long running Response graph and put td in place depending on existence
if [ -f longResponse.svg ]; then
  longRunning="<details><summary>Long Running Response Times</summary><img src=\"longResponse.svg\" alt=\"Long Running Response Times\" width=\"100%\"></details>"
else
  longRunning="No Long Running Use Cases"
fi

# Format output for report with commas etc
clientProjPeak=`printf "%'.f\n" $clientProjPeak`
totalHits=`printf "%'.f\n" $totalHits`
testLogins=`printf "%'.f\n" $testLogins`
avgThroughputHits=`printf "%'.f\n" $avgThroughputHits`
successfulRequests=`printf "%'.f\n" $successfulRequests`
failedRequests=`printf "%'.f\n" $failedRequests`
totalMb=`printf "%'.f\n" $totalMb`
avgThroughputMb=`printf "%'.2f\n" $avgThroughputMb`
staticContentRequests=`printf "%'.f\n" $staticContentRequests`
staticContentPercent=`printf "%.1f\n" $staticContentPercent`

# Small utility function to convert a text table to an HTML table
# Input: $1 filename
#        $2 field separator (note: + is an alias for tab)

convertTable() {
if [ $# -eq 2 ]; then
opts="-v sep=$2"
fi
mawk $opts '
BEGIN {
if(sep!="") {
if(sep=="+") {
FS="\t"
} else {
FS=sep
}
}
print "<table id=\"auto\" border=\"1\"><tr>";
}
{
if(NR==1) { tag="th" } else { tag="td" }
for (i=1; i<=NF; i++) { printf "<%s>%s</%s>", tag, $i, tag }
print "</tr>";
}
END { print "</table>" }
' $1
}

httpStatusCodes=$(convertTable http_data.txt +)
serversHit=$(convertTable servers_data.txt +)

# Modification of above function to convert text table to sortable table
convertSortTable() {
if [ $# -eq 2 ]; then
opts="-v sep=$2"
fi
mawk $opts '
BEGIN {
if(sep!="") {
if(sep=="+") {
FS="\t"
} else {
FS=sep
}
}
}
{
if(NR==1) { tag="th" } else { tag="td" }
if(NR==1) {printf "<thead>"}
print "<tr>";
for (i=1; i<=NF; i++) { printf "<%s>%s</%s>", tag, $i, tag }
print "</tr>";
if(NR==1) {printf "</thead>\n<tdata>"}
}
END { print "</tdata>"}
' $1
}

convertSortTableFoot() {
# Additional function to simplify creating a table footer based on NR==1 in awk
if [ $# -eq 2 ]; then
opts="-v sep=$2"
fi
mawk $opts '
BEGIN {
if(sep!="") {
if(sep=="+") {
FS="\t"
} else {
FS=sep
}
}
}
{
 if(NR==1) {
   print "<tfoot><tr>";
   for (i=1; i<=NF; i++) { printf "<%s>%s</%s>", "th", $i, "th" }
   print "</tr></tfoot>";
 }
}
' $1
}



cat <<EOF
<html>
<head>
<title>$clientName - Blackboard Learn 9.1 Performance Test Report</title>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.1.min.js"></script> 
<script type="text/javascript" src="http://cdn.datatables.net/1.10.5/js/jquery.dataTables.min.js"></script>
<script>
\$(document).ready(function() {
    \$('#useCases').dataTable( {
		 <!-- "paging":   false, -->
		"lengthMenu": [[-1, 50, 25, 10], ["All", 50, 25, 10]]
	} );
        \$('#longResponses').dataTable( {
		 <!-- "paging":   false, -->
		"lengthMenu": [[25, 10, 25, -1], [25, 10, 25, "All"]] 
	} );
    \$('#non200responses').dataTable( {
                 <!-- "paging":   false, -->
                "lengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]] 
        } );
} );
</script>
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/1.10.5/css/jquery.dataTables.css">
<style type="text/css">
table { 
border: 1px solid black;
border-collapse: separate;
border-spacing: 0pt;
margin: 0px 0px 0px 5px;
}
td { 
border: 1px solid black;
font-family: Arial, Helvetica, sans-serif;
font-size: 12;
padding: 1px;
color: #000000;
text-align:left;
}
td.special { 
border: inset 1pt;
}
th { 
border: 1px solid black;
font-family: Arial, Helvetica, sans-serif;
font-size: 12;
font-weight: bold;
padding: 1px;
background-color: #BDBDBD;
color: #000000;
text-align:left;
}
#report tr > td:first-child { font-weight: bold;}
#auto tr > td:first-child { font-weight: normal;}
#useCases tfoot > tr > th { background-color: #ffffff;}
#longResponses tfoot > tr > th { background-color: #ffffff;}
h1 {
font-family: Arial, Helvetica, sans-serif;
font-size: 22;
color: #000000;
}
body {
font-family: Arial, Helvetica, sans-serif;
font-size: 12;
}
</style>
</head>
<body>
<h1>$clientName - Blackboard Learn 9.1 - Performance Test Report</h1>
<h1>$testName</h1>
<table id="report" align="center">
<col span="1" style="background-color: #BDBDBD; color: #ffffff" />
<tr><td valign="top">Test Name</td><td>$testName</td></tr>
<tr><td valign="top">Test Objective</td><td>$testObjective</td></tr>
<tr><td valign="top">Test Start Time</td><td>$startDate</td></tr>
<tr><td valign="top">Duration</td><td>$testDuration Minutes</td></tr>
<tr><td valign="top">Target</td><td>$testTarget</td></tr>
<tr><td valign="top">Access Method</td><td>$testAccessMethod</td></tr>
<tr><td valign="top">Volume of Traffic</td><td>$testVolume</td></tr>
<tr><td valign="top">Projected Peak</td><td>Full Cluster Project Peak: $clientProjPeak (hits/hr)<br>Single Server Projected Peak: $peakPerServer (hits/hr)</td></tr>
<tr><td valign="top">Total Use Cases</td><td>$testNumUseCases</td></tr>
<tr><td valign="top">Use Case Stats</td><td>Successful Use Cases: $successfulRequests<br>Failures: $failedRequests<br>Failure Rate: %$failureRate<br>Static Content Requests(Images/CSS/JS): $staticContentRequests<br>Static Content %: $staticContentPercent</td></tr>
<tr><td valign="top">Logins</td><td>$testLogins</td></tr>
<tr><td valign="top">Avg Hits / Login</td><td>$avgHitsPerSession</td></tr>
<tr><td valign="top">Throughput (Hits/Hr)</td><td>Total Hits: $totalHits<br>Average Throughput (hits/hr): $avgThroughputHits</td></tr>
<tr><td valign="top">Servers Hit</td><td>$serversHit</td></tr>
<tr><td valign="top">Throughput (Mb)</td><td>Total Mb Transferred: $totalMb<br>Average Throughput (Mb/s): $avgThroughputMb</td></tr>
<tr><td valign="top">HTTP Status Codes</td><td>$httpStatusCodes</td></tr>
<tr><td valign="top">Non 200<br>HTTP Responses</td><td>
EOF

# Determine if non 200 responses exists based on http_error_counts.txt line count before processing table
if [ -f http_error_counts.txt ]; then
   non200LineCount=`cat http_error_counts.txt | wc -l`
fi
if [ $non200LineCount -gt 1 ]; then
   echo "<table id='non200responses' class='display' cellspacing='0'>";
   # Build Non 200 Response Code Table if http_error_counts exists
   convertSortTable http_error_counts.txt +
   echo "</table>";
else
   echo "None";
fi

cat <<EOF
</td></tr>
<!-- Graphs Start Here -->
<tr><td valign="top">Response Time<br>Graph</td><td><details><summary>Response Time</summary><img src="response.svg" alt="Response Times" width="100%"></details></td></tr>
<tr><td valign="top">Response Time<br>Trend Graph</td><td><details open><summary>Response Time Trends Graph</summary><img src="response_trend.svg" alt="Response Time Trends" width="100%"></details></td></tr>
<tr><td valign="top">Long Running<br>Use Cases</td><td>$longRunning</td></tr>
EOF

if [ -f navigationalResponse.svg ]; then
cat <<EOF
<tr><td valign="top">Navigational<br>Response Graphs</td><td><details><summary>Navigational Response Time</summary><img src="navigationalResponse.svg" alt="Naviational Response Time" width="100%"></details><br><details><summary>Navigational Response Time Trends</summary><img src="navigationalResponse_trend.svg" alt="Naviational Response Time Trends" width="100%"></details></td></tr>
EOF
fi

if [ -f transactionalResponse.svg ]; then
cat <<EOF
<tr><td valign="top">Transactional<br>Response Graphs</td><td><details><summary>Transactional Response Time</summary><img src="transactionalResponse.svg" alt="Transactional Response Time" width="100%"></details><br><details><summary>Transactional Response Time Trends</summary><img src="transactionalResponse_trend.svg" alt="Transactional Response Time Trends" width="100%"></details></td></tr>
EOF
fi

if [ -f staticContentResponse.svg ]; then
cat <<EOF
<tr><td valign="top">Static Content<br>Response Graphs</td><td><details><summary>Static Content Response Time</summary><img src="staticContentResponse.svg" alt="Static Content Response Time" width="100%"></details><br><details><summary>Static Content Response TimeTrends</summary><img src="staticContentResponse_trend.svg" alt="Static Content Response Time Trends" width="100%"></details></td></tr>
EOF
fi

if [ -f bbMobileResponse.svg ]; then
cat <<EOF
<tr><td valign="top">Blackboard Mobile<br>Response Graphs</td><td><details><summary>Blackboard Mobile Response Time</summary><img src="bbMobileResponse.svg" alt="Blackboard Mobile Response Time" width="100%"></details><br><details><summary>Blackboard Mobile Response Time Trends</summary><img src="bbMobileResponse_trend.svg" alt="Blackboard Mobile Response Time Trends" width="100%"></details></td></tr>
EOF
fi

if [ -f contentResponse.svg ]; then
cat <<EOF
<tr><td valign="top">Content System<br>Response Graphs</td><td><details><summary>Content System Response Time</summary><img src="contentResponse.svg" alt="Content System Response Time" width="100%"></details><br><details><summary>Content System Response Time Trends</summary><img src="contentResponse_trend.svg" alt="Content System Response Time Trends" width="100%"></details></td></tr>
EOF
fi

#Support for the SAR graphs
if [ -f sar/sar_DB_gnuplot.svg ]; then
cat <<EOF
<tr><td valign="top">DB<br>SAR Graphs</td><td><details><summary>DB SAR Graph</summary><img src="sar/sar_DB_gnuplot.svg" alt="DB SAR Graph" width="100%"></details></td></tr>
EOF
fi

if [ -f sar/sar_APP_gnuplot.svg ]; then
cat <<EOF
<tr><td valign="top">APP<br>SAR Graphs</td><td><details><summary>APP SAR Graph</summary><img src="sar/sar_APP_gnuplot.svg" alt="APP SAR Graph" width="100%"></details></td></tr>
EOF
fi

if [ -f sar/sar_LG_gnuplot.svg ]; then
cat <<EOF
<tr><td valign="top">APP<br>SAR Graphs</td><td><details><summary>LG SAR Graph</summary><img src="sar/sar_LG_gnuplot.svg" alt="LG SAR Graph" width="100%"></details></td></tr>
EOF
fi

cat <<EOF
<tr><td valign="top">HTTP Hits Graph</td><td><details open><summary>HTTP Hits Graph</summary><img src="hits.svg" alt="Throughput in Hits per Hour" width="100%"></details></td></tr>
<tr><td valign="top">Throughput Graph</td><td><details><summary>Throughput Graph (Mb/s)</summary><img src="bytes.svg" alt="Throughput in Mb per Second" width="100%"></details></td></tr>
<tr><td valign="top">Running Grinder<br>Threads Graph</td><td><details><summary>Running Grinder Threads Graph</summary><img src="running.svg" alt="Running Threads" width="100%"></details></td></tr>
<tr><td valign="top">Logins Per Minute</td><td><details><summary>Unique Logins / Min</summary><img src="logins_per_min.svg" alt="Logins Per Minute" width="100%"></details></td></tr>
<tr><td valign="top">Unique Grinder Threads<br>Per Minute</td><td><details><summary>Unique Grinder Threads / Min</summary><img src="threadrun_per_min.svg" alt="Unique Grinder Threads Per Minute" width="100%"></details></td></tr>
<!-- <tr><td valign="top">Grinder Logins /<br>Unique Threads</td><td><details><summary>Unique Logins and Threads</summary><img src="logins_per_min.svg" alt="Logins Per Minute" width="50%"><img src="threadrun_per_min.svg" alt="Unique Grinder Threads Per Minute" width="50%"></details></td></tr> -->

<!-- Response Time Table -->
<tr><td valign="top">Response Time<br>Summary Table</td><td><details open><summary>Response Time Summary Table</summary>
<table id="useCases" class="display" cellspacing="0" width="95%">
<!-- <col style="background-color: #BDBDBD; color: #ffffff" font-weight: bold; /> -->
<!-- <col span="2"/> -->
EOF

convertSortTable response_data.txt +
convertSortTableFoot response_data.txt +
cat <<EOF
</table>
<!-- Long Response Table -->
<tr><td valign="top">Long Response Time<br>Summary Table</td><td><details open><summary>Long Response Time Summary Table</summary>
<table id="longResponses" class="display" cellspacing="0" width="95%">
<!-- <col style="background-color: #BDBDBD; color: #ffffff" font-weight: bold; /> -->
<!-- <col span="2"/> -->

EOF
convertSortTable long_request_sorted.txt ,
convertSortTableFoot long_request_sorted.txt ,

cat <<EOF

</details></td></tr>
</table>
<a href='calibration.html'>Calibration</a>
</body>
</html>
EOF
