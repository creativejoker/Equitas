#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

#########################################################################
base=`dirname $0`
pwd=`pwd`
# make tmp directory in reports dir for specific run
mkdir $pwd/tmp

# Use this to override the mapping file
if [ -z "$OVERRIDE_MAPPING" ] ; then
  mappingFile=$base/mapping.map
else
  mappingFile=$OVERRIDE_MAPPING
fi

if [ ! -z "$OVERRIDE_SHELL" ]; then
  extraMakeOptions="SHELL='$OVERRIDE_SHELL'"
fi

# Watch your dependencies or you may not get the data you need in the correct order hits_summary.txt is needed for setting xtics in gnuplot
# Specifically the test duration calculated in hits_summary.txt is needed to make calculations in subsequent scripts for gnuplot
cat > ./Makefile <<EOF
OBJECTS=merged.data merged.out hits_summary.txt grinder_sessions response_data.txt http_data.txt bytes_summary.txt running.svg json_table calibrate
all:  report.html

merged.data:
	$base/_merge_data.sh $* > merged.data

merged.out:
	$base/_merge_out.sh $* > merged.out

hits_summary.txt: merged.out
	$base/hits.sh merged.out

grinder_sessions: merged.data hits_summary.txt
	$base/grinder_session_stats.sh $* 

response_data.txt: merged.data hits_summary.txt
	$base/response.sh $mappingFile merged.data

http_data.txt: merged.out
	$base/http.sh merged.out

bytes_summary.txt: merged.data hits_summary.txt
	$base/bytes.sh merged.data

running.svg: merged.data hits_summary.txt
	$base/running.sh merged.data

json_table: merged.data response_data.txt
	$base/json_table.sh > response_data.json
	$base/json_table.sh > response_data.json
    
calibrate: merged.data hits_summary.txt response_data.txt
	$base/calibrate.sh > calibration.html

report.html: \$(OBJECTS)
	$base/report.sh  > index.html

clean:
	echo rm merged.data merged.out

bare:
	rm \$(OBJECTS) report.html

EOF

if make -j 2 -f ./Makefile $extraMakeOptions all ; then
  true
  make -f ./Makefile clean
else
  exit $!
fi
