#!/bin/sh

responseData=response_data.txt
longRequestData=long_request_sorted.txt
convertJsonTable() {
if [ $# -eq 2 ]; then
opts="-v sep=$2"
fi
awk $opts '
BEGIN {
if(sep!="") {
if(sep=="+") {
FS="\t"
} else {
FS=sep
}
}
print "{"
print "  \"data\": ["
}

{
if(NR==1) {
 for (i=1; i<=NF; i++) {
  header[i]=$i
  }
 }

if(NR==2) {
 print "    {"
 for (i=1; i<=NF; i++) { 
  if (i<NF) {printf "      \"%s\": \"%s\",\n",header[i],$i}
  if (i==NF) {printf "      \"%s\": \"%s\"\n",header[i],$i}
  }
 }

if(NR>2) {
 print "    },"
 print "    {"
 for (i=1; i<=NF; i++) {
  if (i<NF) {printf "      \"%s\": \"%s\",\n",header[i],$i}
  if (i==NF) {printf "      \"%s\": \"%s\"\n",header[i],$i}
  }
 }

}

END { 
print "    }"
print "  ]"
print "}"
}
' $1
}

convertJsonTable $responseData +
convertJsonTable $longRequestData ,