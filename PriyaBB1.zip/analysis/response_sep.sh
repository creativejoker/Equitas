#!/bin/sh

# Compute averages and error counts
# Input:
#   - Test mapping file (from numerical to string)
#   - merged data file or single grinder file either as arg or from stdin
# Output: data file, graph

# Grab Report Data to Populate into HTML Below
testName=`echo $PWD | sed "s/.*\/reports\///"`

#rendering_normal=""
rendering_normal="with lines"
rendering_smooth="with lines smooth bezier"
rendering=$rendering_normal

if [ $# -lt 1 ]; then
 echo "Syntax: $0 <testMappingFile> [input data file]"
 exit 1
fi

mappingFile=$1
shift

# Note: save the data somewhere because we need to scan it twice
# in order to compute the standard deviation
tmpFile="tmp/`hostname`_`basename $0`_$$"
cat $* > $tmpFile.1

# Translate test codes to a string using the mapping file and compute summaries
awk -v mappingFile=$mappingFile '
BEGIN {
 FS=","
 while(  ( getline line < mappingFile ) == 1 ) {
   code=sprintf("%d", substr(line, 0, match(line, "[ \t]")))
   map[code]=substr(line, length(code)+2)
   #print code, "is", map[code]
 }
 close(mappingFile)
}
/^[0-9]/ {
  code=sprintf("%d", $3)
  if($6==0 && $7<400) {
    sum[map[code]]+=$5
    count[map[code]]++
  } else {
    errors[map[code]]++
  }
}
END {
 for(k in sum) {
  printf "%s\t%lu\t%d\n",
    k, sum[k]/count[k], count[k]
 }
}
' $tmpFile.1 > $tmpFile.2

echo "Transaction	Average	Median	Stddev	90%	95%	99%	Minimum	Maximum	Passed	Failed	%Total" > response_data.txt

# Re-read to compute the standard deviation
sort -T tmp -t , -b -n -k 5 $tmpFile.1 | awk -v mappingFile=$mappingFile -v averageFile=$tmpFile.2 '
BEGIN {
 FS=","
 while(  ( getline line < mappingFile ) == 1 ) {
   code=sprintf("%d", substr(line, 0, match(line, "[ \t]")))
   map[code]=substr(line, length(code)+2)
   #print code, "is", map[code]
 }
 close(mappingFile)
 while(  ( getline line < averageFile ) == 1 ) {
   split(line,d, "\t")
   name=d[1]
   avg[name]=d[2]
   count[name]=d[3]
   min[name]=9999999999999
   max[name]=0
   median[name]=-1
   ninety[name]=-1
   ninetyfive[name]=-1
   ninetynine[name]=-1
 }
 close(averageFile)
}
/^[0-9]/ {
  code=sprintf("%d", $3)
  if($6==0 && $7<500) {
    name=map[code]
    sos[name]+= ($5-avg[name])*($5-avg[name])
    if(min[name]>$5) { min[name]=$5 }
    if(max[name]<$5) { max[name]=$5 }
    running_count[name]++;
    if( (median[name]==-1) && (running_count[name] >= (count[name]/2)) ) {
      median[name]=$5
    }
    if( (ninety[name]==-1) && (running_count[name] >= (count[name]*0.90)) ) {
      ninety[name]=$5
    }
    if( (ninetyfive[name]==-1) && (running_count[name] >= (count[name]*0.95)) ) {
      ninetyfive[name]=$5
    }
    if( (ninetynine[name]==-1) && (running_count[name] >= (count[name]*0.99)) ) {
      ninetynine[name]=$5
    }
  } else {
    errors[map[code]]++
  }
}
END {
 for(k in avg) {
  if( (count[k]-1) > 0) {
    stdev=sprintf("%f", sqrt(sos[k]/(count[k]-1))/1000.0)
  } else {
    stdev="n/a"
  }
  { printf "%s\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%d\t%d\t%.3f\n",
    k,
    avg[k]/1000.0, median[k]/1000.0,
    stdev,ninety[k]/1000.0,ninetyfive[k]/1000.0,ninetynine[k]/1000.0,
    min[k]/1000.0, max[k]/1000.0,
    count[k], errors[k], count[k]/NR*100 }
 }
}
' | sort -T tmp >> response_data.txt

# Create the plots

tempDir=./tmp$$
mkdir $tempDir

# dispatch the different samples to their own file
awk -v mappingFile=$mappingFile -v tempDir="$tempDir" '
BEGIN {
 FS=","
 OFMT = "%.03f"
 epoch=-1
 while(  ( getline line < mappingFile ) == 1 ) {
   code=sprintf("%d", substr(line, 0, match(line, "[ \t]")))
   name=substr(line, length(code)+2)
   gsub(/[ \t]/, "_", name)
   map[code]=name
   # workaround for blank (unmapped) codes
   #if(length(map[code])==0){map[code]="Unset_Value"}
   #print code, "is", "<begin>"map[code]"<end>"
 }
 close(mappingFile)
}
/^[0-9]/ {
  if(epoch==-1) { epoch = $4/1000.0 }
  code=sprintf("%d", $3)
  if($6==0 && $7<400) {
  # Fix time stamps here
    #print $4/1000.0-epoch, $5/1000.0 >>  sprintf("%s/%s", tempDir, map[code])
    print $4/1000.0, $5/1000.0 >>  sprintf("%s/%s", tempDir, map[code])
  }
}
' $tmpFile.1 


generatePlotLines() {
  while [ $# -ne 0 ]; do
   # Modify Key Titles here to remove __
   echo -n "'$1' using (timecolumn(1)-5*3600):2 $rendering title '`basename $1 | awk '{ gsub ("_", " ", $0); print}'`'"
   #echo -n "'$1' using (timecolumn(1)-5*3600):2 $rendering title '`basename $1`'"
   shift
   if [ $# -ne 0 ]; then
     echo ", \\"
   else
     echo ""
   fi
  done
}

# Parameter: 
#  output file
doPlot() {
  if [ ! -z "$OVERRIDE_YRANGE" ]; then
    opt="set yrange $OVERRIDE_YRANGE"
  else
    opt="#"
  fi
  if echo $rendering | grep -q smooth ; then
    qualifier="Trend "
  else
    qualifier=""
  fi
  plotFile=./plot$$.plt
  cat > $plotFile <<EOF
set grid
$opt
set title "Response Time $qualifier(s)" font "Arial,12" offset 0,1
#set terminal svg size 1200,450 fixed fname 'Arial' fsize 8 butt solid enhanced background rgb 'grey'
set terminal svg size 1200,500 fname 'Arial' fsize 8 butt solid
set obj 1 rectangle behind from screen 0,0 to screen 1,1
set obj 1 fillstyle solid 1.0 fc rgb "#F5F5F5"
set obj 2 rectangle from graph 0, graph 0 to graph 1, graph 1 behind fc rgbcolor 'white' fs noborder
#set terminal png size 1200,450
set autoscale
set xlabel "Time(s)\n\n$testName\n" font "Arial,10" offset 0,-1
set ylabel "Response Time $qualifier(s)" font "Arial,10" offset -4,0
set xdata time
# Set input time to Epoch
set timefmt "%s"
# Set output time of minutes
set format x "%b %d %H:%M"
set xtics font "Arial,10"
set xtics nomirror
set xtics in 
set xtics rotate by 45 right
set xtics offset 0,-1
set xtics 300
set mxtics 5
set ytics font "Arial,10"
#set ytics 1
# Threshhold line
#set style line 1 lt 1 lw 1
#set style arrow 1 nohead ls 1
set ytics add ("Threshhold" 8)
set arrow from graph 0,first 8 to graph 1,first 8 nohead lc rgb "#FF0000" front
set grid ytics lc rgb "#bbbbbb" lw 1 lt 0
set grid xtics lc rgb "#bbbbbb" lw 1 lt 0
set output "$1"
plot \\
EOF
  #generatePlotLines `find $tempDir -type f` >> $plotFile
  # split use cases into multiple plot files based on transactional or navigational
  find $tempDir -type f` >> tmp_plotFile.txt
  cat 'tmp_plotFile.txt' | awk '
  BEGIN {
  }
  {
  }
  END
  {
  }
  '
  gnuplot $plotFile
  rm -f $plotFile
}

rendering=$rendering_normal ; doPlot response.svg
rendering=$rendering_smooth ; doPlot response_trend.svg
#rendering=$rendering_normal ; doPlot response.png
#rendering=$rendering_smooth ; doPlot response_trend.png

rm -r $tempDir
#rm $tmpFile.*

