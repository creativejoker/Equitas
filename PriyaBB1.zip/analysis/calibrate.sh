#!/bin/sh

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#
testName=`echo $PWD | sed "s/.*\/reports\///"`
clientInfo='client.info'
if [ -f $clientInfo ]; then
  clientName=`cat $clientInfo | awk 'BEGIN { FS="\t" } { if ($1 == "CLIENT_NAME") { print $2 }}'`
  # Need to verify the following are properly set / numbers
  clientProjPeak=`cat $clientInfo | awk 'BEGIN { FS="\t" } { if ($1 == "PROJECTED_PEAK") { print $2 }}'`
else
  clientName="Not Configured"
  clientProjPeak=0
fi

# Report Data File
reportData="report_data.txt"
if [ -f $reportData ]; then 
  testLogins=`awk -F"\t" '$1 ~ /Login/ { print $2 }' $reportData`
  totalHits=`awk -F"\t" '$1 ~ /Total Hits/ { print $2 }' $reportData`
  testDuration=`awk -F"\t" '$1 ~ /Duration/ { printf "%.0f" ,$2 }' $reportData`
else
  echo "Error: unable to find report_data.txt\nSetting all values to 0";
  testLogins=0
  totalHits=0
  testDuration=0
fi
# Check Data and calculate as needed
avgHitsPerSession="Calculation Error";
if ! [[ "$totalHits" =~ ^[0-9]+$ ]] ; then
   echo "Error: totalHits is not an integer -- Excluding";
   #exec >&2; echo "Error: totalHits is not an integer"; exit 1
elif ! [[ "$testLogins" =~ ^[0-9]+$ ]] ; then
   echo "Error: testLogins is not an integer -- Excluding"; 
else
   avgHitsPerSession=$(($totalHits / $testLogins))
fi

# Format output for report
totalHits=`printf "%'.f\n" $totalHits`
testLogins=`printf "%'.f\n" $testLogins`

cat <<EOF
<html>
<head>
</head>
<br>
<a href='index.html'>Back to Report</a>
<br>
<br>
<table border=1>
<tr><th>Calibration Data</th><th>Value</th></tr>
<tr><td>Test Duration (Min)</td><td>$testDuration</td></tr>
<tr><td>Logins</td><td>$testLogins</td></tr>
<tr><td>Total Hits</td><td>$totalHits</td></tr>
<tr><td>Average Hits / Session</td><td>$avgHitsPerSession</td></tr>
</table>
<br>
<table border=1>
<tr><th>Use Case</th><th>Requests</th></tr>
EOF

cat 'response_data.txt' | awk '
BEGIN {
FS="\t"
# Set up variables for each calibration setting
nonCachedImages=0
nonCachedFonts=0
nonCachedCss=0
nonCachedJavascript=0
announcements=0
bbMobile=0
assessmentSave=0
assessmentSubmit=0
discussionBoardSubmit=0
assignmentSubmit=0
blogView=0
wikiView=0
instructorGradebookLoad=0
studentGradebookLoad=0
documentDownloads=0
}
# Loop through and check to see if pattern matches then increment value for use case
{
if ($1 ~ "Images") { (nonCachedImages=nonCachedImages+$10+$11) }
if ($1 ~ "CSS") { (nonCachedCss=nonCachedCss+$10+$11) }
if ($1 ~ "Java Script") { (nonCachedJavascript=nonCachedJavascript+$10+$11) }
if ($1 ~ "Course Announcements") { (announcements=announcements+$10+$11) }
if ($1 ~ "Bb Mobile") { (bbMobile=bbMobile+$10+$11) }
if ($1 ~ "Assessment Save") { (assessmentSave=assessmentSave+$10+$11) }
if ($1 ~ "Assessment Submit") { (assessmentSubmit=assessmentSubmit+$10+$11) }
if ($1 ~ "Discussions Submit Forum Reply") { (discussionBoardSubmit=discussionBoardSubmit+$10+$11) }
if ($1 ~ "Assignment Submit") { (assignmentSubmit=assignmentSubmit+$10+$11) }
if ($1 ~ "Blog View") { (blogView=blogView+$10+$11) }
if ($1 ~ "Wiki Open All") { (wikiView=wikiView+$10+$11) }
if ($1 ~ "Instructor Grade Center Open") { (instructorGradebookLoad=instructorGradebookLoad+$10+$11) }
if ($1 ~ "Student Open Course My Grade") { (studentGradebookLoad=studentGradebookLoad+$10+$11) }
if ($1 ~ "Content Open Document") { (documentDownloads=documentDownloads+$10+$11) }
}

END {
print "<tr><td>Non Cached Images</td><td>"nonCachedImages"</td></tr>"
print "<tr><td>Non Cached CSS</td><td>"nonCachedCss"</td></tr>"
print "<tr><td>Non Cached JavaScript</td><td>"nonCachedJavascript"</td></tr>"
print "<tr><td>Announcements</td><td>"announcements"</td></tr>"
print "<tr><td>Blackboard Mobile Request</td><td>"bbMobile"</td></tr>"
print "<tr><td>Assessment Save</td><td>"assessmentSave"</td></tr>"
print "<tr><td>Assessment Submissions</td><td>"assessmentSubmit"</td></tr>"
print "<tr><td>Discussion board submissions</td><td>"discussionBoardSubmit"</td></tr>"
print "<tr><td>Assignment Submissions</td><td>"assignmentSubmit"</td></tr>"
print "<tr><td>Blog Views</td><td>"blogView"</td></tr>"
print "<tr><td>Wiki View</td><td>"wikiView"</td></tr>"
print "<tr><td>Instructor Gradebook Loads</td><td>"instructorGradebookLoad"</td></tr>"
print "<tr><td>Student gradebook loads</td><td>"studentGradebookLoad"</td></tr>"
print "<tr><td>Document Downloads</td><td>"documentDownloads"</td></tr>"
}
'

cat <<EOF
</table>
</html>
EOF
