#!/usr/bin/perl

# Create results ,reports and replay directories as well as common* files if they do not exist
system('if [ ! -d reports ] ; then mkdir reports ; fi');
system('if [ ! -d results ] ; then mkdir results ; fi');
system('if [ ! -d replay ] ; then mkdir replay ; fi');
system('if [ ! -d tmp ] ; then mkdir tmp ; fi');
system('if [ ! -f common.sh ] ; then cp common.sh.example common.sh ; fi');
system('if [ ! -f common_autoq.sh ] ; then cp common_autoq.sh.example common_autoq.sh ; fi');

# Fix file RWX settings
system('find . -type f ! -path "./jdk*/*" ! -path "./java" ! -path "./exiftool/*" -exec chmod 644 {} \;');
system('chmod 755 *.sh *.pl tools/*.sh tools/*.tcl analysis/*.sh exiftool/exiftool');


# Remove Windows EOL Characters in various files
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' client.info');
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' */*.py');
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' */*.sh');
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' *.sh');
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' *.pl');
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' *.properties');
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' tools/*.tcl');
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' queue/*/*');
system('/usr/bin/perl -pi -e \'s/\r?\n/\n/g\' analysis/*');

# Check for framework application dependencies (in development)
#$muttVersion=exec('mutt -v | head -1 | awk \'{print $2}\'');
#$gnuPlotVersion=exec('gnuplot -V | awk \'{print $2}\'');
#print ("mutt version: $muttVersion");
#print ("gnuplot version: $gnuPlotVersion");

# Clear out previous compiled jython files 
system('find . -name *.class -exec rm {} \;');

# Assess process burden for queued jobs
#system('./calcProcesses.sh');

# Assess ramp up values for queued jobs
#system('./calcRampup.sh');
