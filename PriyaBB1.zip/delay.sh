#! /bin/bash

### Simple script to delay / time execution of autoq.sh
### Particularly useful on systems with restricted access
### to "at" or without it installed at all!

### This script depends on the "bc" command line
### calculator to convert the sigle argument into an
### integer for use as the delay period specified in
### miniutes.

DELAYLOG="$(pwd)"
DELAYLOG_CONSOLE_FILE=delayconsole.log

#PROCESS THE INPUT ARGUMENT
#Make sure that DELAY ends up as some kind of integer greater than zero.
DELAY=$(echo "$1" | bc)
if [ -n "$DELAY" ]; then
    if [ $DELAY -lt 1 ]; then
      DELAY=1
    fi
  else
    DELAY=1
fi

#MAIN PROCESS, sleep then execute autoq.sh
echo "Will delay run for $DELAY minute(s) starting at $(date)" | tee -a $DELAYLOG/$DELAYLOG_CONSOLE_FILE

sleep ${DELAY}m

echo "Delay ended at $(date)" | tee -a $DELAYLOG/$DELAYLOG_CONSOLE_FILE

./autoq.sh

#Remove Console Log
###rm -v -f "$DELAYLOG/$DELAYLOG_CONSOLE_FILE"
