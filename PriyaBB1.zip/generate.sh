#!/bin/bash

# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
#
# Simple script to automate report generation
# by default expects test results to be placed in the results directory
# and will generate reports to the reports directory
here=`pwd`
resultsdir=results
reportsdir=reports
list=`find $here/$resultsdir -name stats.txt -print`

if [ ! -d $reportsdir ]; then
 mkdir -p $reportsdir
fi

for f in $list; do
  dir=`echo $f | sed "s~$here/$resultsdir[/]*~~
s~/stats.txt~~"`
  #echo  -n "$dir: "
  if [ ! -d $here/$reportsdir/$dir -o  $f -nt $here/$reportsdir/$dir/index.html ]; then
    

    echo ""
    echo "#####################################################################################################################"
    echo "# Fixing Logs File Names with Spaces $here/$resultsdir/$dir"
    echo "#####################################################################################################################"
    find "$here/$resultsdir/$dir" -name "*UNNAMED*" -exec rename 'y/ /_/' "{}" \;

    
    
    echo ""
    echo "#####################################################################################################################"
    echo -e "# Generating report for $reportsdir/$dir \n # TIME: `date  \"+%m-%d-%Y %T\"`"
    echo "#####################################################################################################################"
    echo "Creating mapping.map file for report"
    
    
    #Create the mapping.map file, checks to see if there is a mapping_raw.log.gz
    #otherwise for backwards capability, it just zcats the whole log file
    if [ -f $here/$resultsdir/$dir/mapping_raw.log.gz ]; then
        echo "Found the mapping_raw.log.gz, using it to figure out the mapping.map"
        mapping_raw=$here/$resultsdir/$dir/mapping_raw.log.gz
    else
        echo "Did not find the mapping_raw.log.gz, using the whole out*.gz to figure out the mapping.map"
        mapping_raw=$here/$resultsdir/$dir/*/out*.gz
    fi
        #Create the mapping.map file, checks to see if there is a mapping_raw.log.gz
    #otherwise for backwards capability, it just zcats the whole log file

    #Quick awk script to look at the out file results and grab the test number and the test name 
    #Add a tab inbetween the two values and output it to analysis/mapping.map 
    #We do this for each run in case the tests vary from each results, adds a little overhead
    zcat $mapping_raw  | mawk  'BEGIN{FS="\""}/Test [0-9]+/{key=substr($1,6,4);gsub(/[ \t]+$/, "", key);gsub(/^[ \t]+/, "", $2); mapping[key]=$2;}END{for(key in mapping){print key "\011" mapping[key]}}' | sort -n -k1 > analysis/mapping.map
    
    echo -n "$dir: processing"
    mkdir -p $here/$reportsdir/$dir
    
    #If we have a long request file, we move it to the report directory to be used later
    if [ -f $here/$resultsdir/$dir/long_request_sorted.txt ]; then
        echo "Found the long request sorted.txt file, copying it to the report directory"
        cp $here/$resultsdir/$dir/long_request_sorted.txt $here/$reportsdir/$dir/
    else
        echo "Did not long request sorted.txt file, creating from the trace files"
        zcat $target/*/trace* | mawk -F"," '{print $3/1000 ","$4}'| sort -n| tail -n 100 >> $here/$reportsdir/$dir/long_request_sorted.txt
    fi
    
    cd $here/$reportsdir/$dir
    
    #Grab the target/objective/accessmethod/trafficvolume and move it to reports directory
    cp $here/$resultsdir/$dir/text_*.txt $here/$reportsdir/$dir/
    
    #Grab the SAR SVG Images
    mkdir -p $here/$reportsdir/$dir/sar/
    cp $here/$resultsdir/$dir/sar/*.svg $here/$reportsdir/$dir/sar/
    
    
    if [ -f $here/client.info ]; then
        cp $here/client.info $here/$reportsdir/$dir/
    else
        echo "ERROR: client.info file not found!"
        exit 1
    fi
    
    $here/analysis/analyze.sh $here/$resultsdir/$dir
    rm merged*
    rm Makefile
    rm -r tmp*
    cd $here
    echo "#####################################################################################################################"
    echo "# HTML report generated in $reportsdir/$dir @ `date  +%m-%d-%Y:%T`"
    echo "#####################################################################################################################"
  fi
  touch -r $here/$resultsdir/$dir $here/$reportsdir/$dir
done

#echo "html report(s) generated!"
