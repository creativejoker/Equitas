#!/bin/sh
# rsync example for pulling results back to bbperf2 etc.
# Note: --rsync-path may need to be modified for Solaris clients
# Note: --exclude-from filename contains specific files to exclude from the sync 
# Note: uncomment and validate generate.sh if results are to be generated locally vs client system
rsync -azv -e ssh --progress --exclude-from 'rsync_exclude_files' --rsync-path=/usr/bin/rsync bperf@<client ip>:performance/mainline remote/
echo "rsync completed!"

#./generate.sh
#echo "generated reports!"
