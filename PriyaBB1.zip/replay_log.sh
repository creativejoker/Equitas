#!/bin/sh

tools/replay.sh log.txt