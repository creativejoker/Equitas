#!/bin/sh
if !([ -d files ]); then
  mkdir files 
fi
dd if=/dev/zero of=files/perf_50k.txt bs=50k count=1
dd if=/dev/zero of=files/perf_100k.txt bs=100k count=1
dd if=/dev/zero of=files/perf_200k.txt bs=200k count=1
dd if=/dev/zero of=files/perf_512k.txt bs=512k count=1
dd if=/dev/zero of=files/perf_1m.txt bs=1M count=1
dd if=/dev/zero of=files/perf_10m.txt bs=1M count=10
dd if=/dev/zero of=files/perf_100m.txt bs=1M count=100
dd if=/dev/zero of=files/perf_1g.txt bs=1M count=1024