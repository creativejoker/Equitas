# (C) Copyright Blackboard Inc. 2015 - All Rights Reserved
# 
# Permission to use, copy, modify, and distribute this software
# without prior explicit written approval is strictly prohibited.
#  
# BLACKBOARD MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
# OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE, OR NON-INFRINGEMENT. BLACKBOARD SHALL NOT BE LIABLE FOR ANY
# DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
#
# Note: Ensure host names, debug, password, sessionlength, rampup, 
#   and coursesTabPk are set correctly for the client 
#       environment and test being conducted.

from utils.parameters import *
from utils.rampup import Rampup
from java.lang import System

###############################################################
# DEBUGGING
###############################################################

# Purpose: Log html response output of thread 0 to a log.txt 
# To recreate html pages, execute replay.sh
# Referenced in Class: LoggingHTTPRequest.log() in utils/response.py
# Output: log.txt
# Options: True or False, default is False
logHTMLResponseToLogFile=False

# Purpose: If set to True, sends the debugging messages to the info logs
# Output Destination: Info logs (i.e. student/out_*.log)
# Referenced in Class: checkDebugAndLog() in utils/logging.py and smartUpdateNVPairs() in utils/parse.py
# Options: True or False, default is False
logDebugMessages=False

# Purpose: Prints NVPair post data to the out_*.log.
# If logDebugMessages = True, it will override this setting. 
# Referenced in Class: printPostData() in utils/error.py 
# Output Destination: Info logs (i.e. student/out_*.log)
# Options: True or False, default is False
printPostDataToOutput=False

# Purpose: Fail test if error is found. 
# If set to True, sends the test fail if there is an error. 
# If set to False, it will just log the error and not fail the test
# Referenced in Class:  utils/error.py
# Output Destination: Info logs (i.e. student/out_*.log)
# Options: True or False, default is True
failTestIfError=True

# Purpose: Prints HTTP Cookie information to the out_*.log
# If logDebugMessages = True, it will override this setting. 
# Referenced in Class: printCookies() in utils/request.py 
# Output Destination: Info logs (i.e. student/out_*.log)
# Options: True or False, default is False
printCookies=False

###############################################################
# SESSIONS
###############################################################
# Define the length of a session in number of sessions
# This is the number of actions a user will take within a session(after logging in and before logging out)
# Correlate to session statistic information
sessionLength=20
instructorSessionLength=sessionLength/5

###############################################################
# UPLOAD FILES
###############################################################

# Purpose: Set the directory of custom files to be upload during the assignment/content use cases
# Referenced in Class:  utils.uploadFiles
# Options: Relative path of folder under the mainline/ directory, default is "files"
filesPath="files"

# Purpose: Limit the max file size for files to be submitted to the application
# Referenced in Class:  utils.uploadFiles
# Options: Integer > 0, default is 5. Value is in MB
maxFileSize=5

# Purpose: Determine whether to randomize the meta data of the files being uploaded 
# If true, use exiftool to randomize the name and title metadata of the files underneath the filesPath directory
# Random tmp file gets created in filesPath/tmp directory.
# NOTE: There is an overhead to randomize the files, the scripts will wait till the file is created before moving on
#       This can add additional wait time to your test as the files are created 
# All tmp files get removed on startup
#
# Exiftool is hardcoded to be under mainline exiftool/exiftool
# Referenced in Class:  utils.uploadFiles.getRandomFile()
# Options: True or False. Default is True
randomizeUploadFiles=True

# Purpose: If randomizeUploadFiles = TRUE, Determine whether to batch create the random files or create them on the fly
# Referenced in Class:  utils.uploadFiles
# Options: BATCH or JIT(JUST IN TIME). Default is BATCH
# BATCH: The Student Process 0 will create in batch at the start of the test the number of random files specified in totalNumberOfRandomFiles 
#       All of the other student/instructor processes will wait till the files are created before moving forward with the rest of the loading
#       Note: This will increase the start up time.
#           utils.uploadFiles.getRandomFile(), will provide a random file from the batch created files
#           utils.uploadFiles.removeFile(), nothing is performed. The file is not removed so that it can be used in the future.
# 
# JIT: This will create a new uniquely random file each time the utils.uploadFiles.getRandomFile() method is called
#       NOTE:   There may be additional overhead with performing this action, be sure to remove the file
#               This will also add additional wait time to the upload use cases, as the scripts have to wait till the files is
#               created before moving forward so that it doesn't hit a file not found error. 
randomizeUploadFilesCreationMethod="BATCH"
#randomizeUploadFilesCreationMethod="JIT"

# Purpose: Determine the total number of random files to create in "Batch" file creation mode
# The Student Process 0 will create all of the random files based on the value below. 
# Referenced in Class:  utils.uploadFiles.BatchCreateRandomFiles()
# Options: Integer, 100 is default
totalNumberOfRandomFiles=100

###############################################################
# HOSTS
###############################################################

# Configuration variables
# See parameters.py for the different types of parameter classes available.

# Direct to a single host (http and https example) 
App0URL=Parameter("target_url", 'https://app00.example.com')
App1URL=Parameter("target_url", 'https://app01.example.com')
App2URL=Parameter("target_url", 'https://app02.example.com')
App3URL=Parameter("target_url", 'https://app03.example.com')
App4URL=Parameter("target_url", 'https://app04.example.com')

# Direct to Load Balancer
loadBalancedURL=Parameter("target_url", 'https://bblearn.example.com')

# Example to implement round-robin to multiple hosts
directClusterURL=ListParameter("target_url", "each", "random", \
[
'https://app00.example.com',
'https://app01.example.com',
'https://app02.example.com',
'https://app03.example.com',
'https://app04.example.com'
])

# Decide where you are sending traffic
targetURL=loadBalancedURL
#targetURL=loadBalancedURL
#targetURL=loadBalancedURL

#Urls that should not be loaded if picked up in the portal page 
blacklistedUrls=['image.weather.com','bbgs-partner-cloud-bb_bb60/app/materials/','cuny.edu','bgsu.edu']
whitelistedUrls=['blackboard.com']

###############################################################
#USERS
###############################################################
#Note: Use "sequential" instead of "random" below if you need to select users in sequential order
#      This only applies to a single process, and will not carry across multiple processes 

instructor=RangeParameter("instructor", "each", "random", "instructor%09lu", 1, 240)
username=RangeParameter("username", "each", "random", "user%09lu", 1, 7000)
adminUserName=RangeParameter("username", "each", "random", "admin%09lu", 1, 1)
#If using live users, percentage of live users to use during a test. By default, it's set to not use live user.
#If using live users, be sure to set the initialCourseMapping = True and execute a first couple of runs to map the liver user's course information. 
percentageLiveUsers=0

#Externalized name of the text "Courses where you are: Instructor" used within the My Course Module to determine whether the user is enrolled as an instructor or student in a course
instructorMyCourseModuleTitle="Courses where you are: Instructor"
studentMyCourseModuleTitle="Courses where you are: Student"
###############################################################
#AUTHENTICATION
###############################################################

# AutoSignon B2 Shared Secret (in GUI)
autoSignonSecret='secret-from-gui-autosignon-b2'

#RDBMS
# Password in clear text to use when challenge-response is on
password=Parameter("password", "pass")
#Password for Live users
#password=Parameter("password", "password")

#LDAP
# Password to use when challenge-response is turned off, including LDAP 
#password=Parameter("password", "cGFzcw==")
# Same password, unicode then base64 encoded
password_unicode=Parameter("password_unicode", "cABhAHMAcwA=")


###############################################################
#Bb Mobile Version
###############################################################

#NOTE: This is the value of the Bb Mobile app version sent by the user.  Current scripts are set to 4.1.2
bbMobileVersion="4.1.2"
#bbRegId - impact BbMobile Scripts  Verify the value for each client engagement
bbRegId="21545"

###############################################################
#Bb REST API
#
#To Obtain a Client Application Key and Secret
#1. Signup for https://developer.blackboard.com
#2. Create a new application under https://developer.blackboard.com/portal/applications
#3. Save the application key and secret to be used in the configuration below. 
#    Save the Application ID to be used in step 4
#4. Create a new REST API Integration in the Blackboard Learn Instance. 
#    System Admin Tab > REST API Integrations > Create Application > Application ID <-- Application ID from step 3
#    System Admin Tab > REST API Integrations > Create Application > Learn User <-- A user with system admin system role. 
#5. Increase the Rate limit. The current rate limit is set to 10K request per day. The key below has 500K request per a day. To increase beyond that, you need to contact Developers@blackboard.com
###############################################################

clientApplicationKey = "f54f9aee-d85d-469a-8230-10b1b5f39fe0"
clientSecret = "Vv5OBxw6aFVkYwcOjBKsdKtJviQwbR1u"

###############################################################
#Portal Tab Names
###############################################################
#Execute with initial mapping set to true and then execute this at the endswith
#zcat student/warn_fgprd-bbperf-app*.log.gz |awk -F"|" '{key=$2"|"$3;count[key]++} END { for(key in count) {print key, count[key]}}'  |sort                                                                             

#Used in bblearn.extractBbLearnCourseContentTabPks() to search and extract the PK of the tab
#Text of the Course tab, typically "Courses"
courseTabName="Courses"
#Text of the Content Collection tab, typically "Content Collection"
contentSystemTabName="Content Collection"
#NEW - This allows you to specify which content collection folders should be attempted to be opened and traversed for content
contentCollectionFolders=["orgs","institution","courses","library"]

utilizePortalTargetNames = True                               

#Default possible Top Tab targets. Update with client specific values from System Admin Panel > Tabs and Modules > Tabs
portalTopTabTargets = ['My Institution',\
'Course',
'Community',
'Content Collection',
'Services',
'The Web',
'Notification Dashboard'
]

#Default possible Sub Tab targets. Update with client specific values from System Admin Panel > Tabs and Modules > Tabs
portalSubTabTargets = ['My Institution',\
'Course',
'Community',
'Content Collection',
'Services','The Web',
'Notification Dashboard'
]

#Default possible tool panel targets. Update with values from System Admin Panel > Tabs and Modules > Tool Panel
portalToolPanelTargets=['Announcements',\
'Calendar',
'Tasks',
'My Grades',
'Send Email',
'User Directory',
'Address',
'Personal Information',
'Goals',
'Enterprise Surveys',
'Course Material'
]



courseToolTOCTargets = ['Achievements',\
'Announcements',
'Assessments',
'Assignments',
'Blogs',
'Calendar',
'Contacts',
'Discussions',
'Email',
'Glossary',
'Groups',
'Journals',
'Home Page',
'Messages',
'My Grades',
'Portfolio Homepage',
'Portfolio',
'Roster',
'Tasks',
'Tools',
'Wikis'
]                                                                                                                                                                                                                                                                           
###############################################################
# Course Content Sub Folder Mapping
###############################################################

# Purpose: Determine how the scripts should extract the content/assignments/blogs/wikis/dbs/assessments TOCS, either using the legacy method or the new mapping function.
# LEGACY: For the LEGACY data model. It assumes that the course TOC is the standard naming convention found below
# MAP: For LIVE courses that don't match the data model naming convention. 
#      It iterates through the course TOC and figures out the TOC
#
# Below is a list of a sample course toc and which TOC's would be extracted base on the mode
#   -> Home Page  (LEGACY and MAP)
#   -> Course Information (LEGACY and MAP)
#   -> Course Documents (LEGACY and MAP)
#   -> Discussion Board (LEGACY and MAP)
#   -> Groups (LEGACY and MAP)
#   -> Tools (MAP)
#   -> Help (MAP)
#   -> Announcements (LEGACY and MAP)
#   -> Assessments (LEGACY and MAP)
#   -> Assignments (LEGACY and MAP)
#   -> Blogs (LEGACY and MAP)
#   -> Contacts (MAP)
#   -> Web Links (MAP)
#   -> Journals (MAP)
#   -> Tasks (MAP)
#   -> Wikis (LEGACY and MAP)
# Referenced in Class:  scripts/base.py, scripts/course.py, actions/course.py
# Options: LEGACY or MAP, default is LEGACY
courseTOCMode="LEGACY"
#courseTOCMode="MAP"

courseToolTOCTargets = ['Achievements','Announcements','Assessments','Assignments','Blogs','Calendar','Contacts','Discussions','Email','Glossary','Groups','Journals','Home Page','Messages','My Grades','Portfolio Homepage','Portfolio','Roster','Tasks','Tools','Wikis']
##########################################################################
# Purpose: Switch to provide mapping functionality for mapping the course and saving the data to course_contents.snap file. 
# If set to True, users will sequentially will log into the system, sequentially load all of their courses and map each course. This will ensure that each course has been mapped prior to the execution of the real load testing
# Options: True or False, default is False
initialCourseMapping = False

               
#If mapping the portal object names is set to true
#Run this awk script to grab the unique portal objects 
#zcat student/warn_fgprd-bbperf-app*.log.gz |awk -F"|" '{key=$2"|"$3;count[key]++} END { for(key in count) {print key, count[key]}}'  |sort
initialPortalNamesMapping = False


# Purpose: Determine how many levels down in a course content folder structure to search for content/assignments/blogs/wikis/dbs/assessments. 
# For example, if set to 2, the script will map out 2 levels of sub folders under the original course table of content item. 
# Main TOC: Course Documents 
#       -> Sub Folder Level 1: "Lesson 1 - Day 1"
#            -> Sub Folder Level 2: "Addition"
#            -> Sub Folder Level 2: "Subtraction"
#       -> Sub Folder Level 1: "Lesson 2 - Day 2"
#            -> Sub Folder Level 2: "Division"
#               -> Sub Folder Level 3: "Fractions" <- Content on this sub folder level would not be mapped. 
#
# Referenced in Class:  CourseAction.openCourse() in action/course.py
# Options: Integer, default is 2
numSubFolderLevelsToMap=2




###############################################################
# Header classes
###############################################################

#Dictionary of headers that should be sent with each request
#Add additional headers that can be added to all request
#By default, they're commented out
HTTPHeaders= {
#"X-Forwarded-Proto":"https",
#"X-Forwarded-For":"true",
}


###############################################################
# Response Time Threshold
###############################################################

#Prints all URL request and response times over a certain threshold to the warn.log
#By default, it's set to 5000 milliseconds or 5 seconds
responseTimeThresholdMilliSeconds = 5000

###############################################################
# Thinktime classes
###############################################################

thinkTime= {
"staticcontent":1*500,
"quick":1*1000,
"navigational":2*1000,
"authentication":3*1000,
"other":4*1000,
"transactional":10*1000,
"institutional":1*1000,
"email":15*1000,
"modify_grades":15*1000,
"author":0*1000,
"read":45*1000,
"content":45*1000,
"view_grades":60*1000
}

###############################################################
# Distribution  classes
###############################################################

distributionPercentages= {

#Student Distribution
"Student.Assessment":4,
"Student.Assignment":1,
"Student.Mobile":2,
"Student.Blog":1,
    "Student.StaticContent":35,
"Student.DB":25,
"Student.ContentSystem":0,
    "Student.CourseNavigation":11,
"Student.Wiki":1,
"Student.Content":20,
"Student.Grading":5,

#Instructor Distribution
"Instructor.Grading":40,
"Instructor.CourseContentSystemUploads":5,
"Instructor.ContentSystem":5,
"Instructor.CourseCopy":0,#- Set to 0 by default, set to non zero for utilize
"Instructor.SectionMerge":0, #- Set to 0 by default, set to non zero for utilize

#Admin Distribution
"Admin.CourseSearch":5,
"Admin.UserSearch":5,


#Discussion Board
"DbAction.OpenMessageIteration":4,
"DbAction.OpenCreateForumPercentage":5,
"DbAction.SubmitForumReplyPercentage":10,

#Assignment
"AssignmentAction.NumOfOpens":2,
"AssignmentAction.OpenIterations":2,
"AssignmentAction.SubmitAssignmentPercentage":20,

#Assessment 
"AssessmentAction.SaveAAOPercentage":25,


#Course Copy - Set to 0 by default, set to something other than 0 if you want to use it
"CourseCopyAction.openCourseCopyPercentage":0,

#Course Search Actions
"AdminCourseSearchAction.openCourseSearchPercentage":5,
"AdminCourseSearchAction.submitCourseSearchPercentage":1,

#Content System Actions
"ContentSystemAction.openBasicSearchPercentage":5,
"ContentSystemAction.SubmitContentUploadPercentage":2,
"ContentSystemAction.OpenIterations":2,
"InstructorContentUploadAction.SubmitContentUploadPercentage":50,

#Content System Scripts
"ContentSystem.openInstitutionFileRandomSelectionPercentage":50,
"ContentSystem.openFolderRandomSelectionPercentage":50,


#Section Merge Tool - Set to 0 by default, set to something other than 0 if you want to use it
"SectionMergeAction.openSectionMergePercentage":0,
"SectionMergeAction.submitNewSectionMergesPercentage":5,
"SectionMergeAction.submitDisassociateSectionMergesPercentage":5,

#Static Content
"StaticContentAction.Iterations":20,
"StaticContentAction.JSPercentage":25,
"StaticContentAction.CSSPercentage":25,

#Portal
"PortalAction.OpenTopTabPercentage":50,
"PortalAction.OpenSubTabPercentage":20,
"PortalAction.OpenToolPanelPercentage":20,
"PortalAction.OpenAnnouncementPercentage":100,
"PortalAction.OpenGradePercentage":0,#right now this is zero due to bug
"PortalAction.OpenCalendarPercentage":100,

#mobile
"mobileAction.IsStudentAppPercentage":50,
"mobileAction.OpenContentFolderPercentage":25,
"mobileAction.OpenContentPercentage":50,
"mobileAction.OpenAssessmentPercentage":25,
"mobileAction.OpenDBPercentage":25,
"mobileAction.SubmitDBPercentage":25,
"mobileAction.OpenBlogsPercentage":25,
"mobileAction.OpenJournalsPercentage":25,
"mobileAction.OpenTasksPercentage":25,
"mobileAction.OpenMyGradesPercentage":75,

#Instructor Grading
"InstructorGradingAction.gradeSubmissionPercentage":10,
"InstructorGradingAction.downloadGradebookPercentage":5,

#Instructor Box Assignment Grading
"InstructorGradingAction.openBoxAssignmentPercentage":20,
"InstructorGradingAction.spellCheckIterations":4,
"InstructorGradingAction.submitBoxAssignmentPercentage":25,

#Student Grading 
"StudentGradeAction.openCourseGradePercentage":50,
"StudentGradeAction.openReviewGradePercentage":50,
"StudentGradeAction.openReviewGradeIteration":3,

#User Search Actions
"UserSearchAction.openUserSearchPercentage":5,
"UserSearchAction.submitUserSearchPercentage":1,

#Wiki
"WikiAction.OpenWikiIterations":2,
"WikiAction.SubmitWikiPercentage":20,
"WikiAction.SubmitEditWikiPercentage":20,

#Blogs
"BlogAction.OpenCreateBlogPercentage":10,
"BlogAction.SubmitBlogDraftPercentage":10,

#Course Navigation
"CourseNavigationAction.OpenNavigationTargetPercentage":50,
"CourseNavigationAction.OpenNavigationTargetIterations":3,

#Course
"CourseAction.OpenCourseTabPercentage":25,

#BB WS
"BbSoapWebServicesAction.OpenAnnouncementPercentage":50,
"BbSoapWebServicesAction.OpenContentPercentage":75,
"BbSoapWebServicesAction.OpenContentIterations":3,
"BbSoapWebServicesAction.OpenGradePercentage":15

}
###############################################################
# Rampup configuration
###############################################################

# Note: This has no effect unless your scenario calls config.settings.rampup.wait()
# Note: The rampup time is applied to each process individually.  If you are running 2 processes 
#       and a setting of (1,2500), you will be adding 2 threads every 2.5 seconds (1 per process)
# Parameters: n users every t milliseconds

# Standard Quick Rampup
rampup=Rampup(1,2500)


###############################################################
# WARNING: do no change this
###############################################################
tests={}
testCount=0


###############################################################
#DEPRECATED PROPERTIES
###############################################################

#the following properties are no longer used and are deprecated

## Branding image. Varies from institution to institution
#brandingImage="/images/console/logos/header_institution.png"
##brandingImage="/branding/_1_1/1856_1305538486228_1463492025_846418_891110_n.jpg"
##CSS Version
#cssVersion="9.1.201404.160205"
##JS Version
#jsVersion="9.1.201404.160205"


# Support for the different VI identifier between fresh 9.1 install and upgrade from 8.0. Valid value is BBLEARN or bb_bb60; default is bb_bb60.
#vi="bb_bb60"
#vi="BBLEARN"

# Custom headers (across all requests if needed)
# If specific header modifications are required for specific URL's
# Not Currently Implemented 
#globalHeaders=

## At some institutions a custom courses tab is created; the pk1 value is configureable here.
#coursesTabPk="2"
#
## Content Collection tab ID (22 by default with 9.1)
#contentTabPk="22"

#Content Collection, number of results to display and extract when loading the institution content page
#Use to limit the amount of results if there are a lot of items in the institution content collection
#ContentSystemNumResults=15

