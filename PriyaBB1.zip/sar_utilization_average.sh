#This is a quick script that goes through and averages the CPU utilization for the test

#!/bin/bash
here=`pwd`

resultsdir=results
list=`ls $here/$resultsdir`


for dir in $list ; do

    if [ -f $here/$resultsdir/$dir/sar/sar_DB_u_gnuplot.gz ]; then
        sarDBaverage=`zcat $here/$resultsdir/$dir/sar/sar_DB_u_gnuplot.gz | mawk '/[0-9.]+/{{count++;totalCPU+=$4;} }   END {printf "%s,%s,%s", count ,totalCPU, totalCPU/count}'`
        sarAPPaverage=`zcat $here/$resultsdir/$dir/sar/sar_fg*_u_gnuplot.gz | mawk '/[0-9.]+/{{count++;totalCPU+=$4;} }   END {printf "%s,%s,%s", count ,totalCPU, totalCPU/count}'`
        echo "${dir},DB CPU utilization,${sarDBaverage} , APP CPU utilization, ${sarAPPaverage}" >> sar_utilization_average.csv
    fi
done