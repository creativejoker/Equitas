#! /bin/sh

#
# Edited by marcus.uy@blackboard.com
#
#version 1.0 - Initial Draft
#version 2.0 - Added support for multiple load generator servers - DCHOW
#version 3.0 - Added support for SAR graphing for the load generators and target servers


###Remote Agent Configuration Begin###
export CLIENTINFO="client.info"
export CLIENT_NAME=`cat $CLIENTINFO | mawk 'BEGIN { FS="\t" } { if ($1 == "CLIENT_NAME") { print $2 }}'`
export REMOTE_AGENT_USER="bbperf"
export REMOTE_AGENT_USER_PASSWORD="Bb650Mass"
export REMOTE_AGENT_PERF_HOME="/home/$REMOTE_AGENT_USER/clients/${CLIENT_NAME}_REMOTE_AGENT"
export REMOTE_AGENT_SERVERS="fgprd-bbperf-app001.mhint fgprd-bbperf-app003.mhint"
export REMOTE_AGENT="NO"

###INITIAL MAPPING FOR LIVE USER###
#If initial mapping is set to TRUE in conjunction with initialMapping = True in config/settings.py, the autoq.sh script will take the last user_id from the previous test 
#and use that as the starting point for the next user so we can sequentially cycle through the whole list of live users without having to do it in a single test. This is for large
export INITIAL_MAPPING="FALSE"

###Remote Agent Configuration END### 

### Local Configuration Begin###

export PIDFILE="/tmp/autoq.pid"
export MAXUSERPROC_FACTOR="2"

export PERF_HOME="$(pwd)"
export PERF_HOME_RESULTS="results"
export PERF_HOME_REPORTS="reports"

#MAILPAUSE in seconds
#TESTPAUSE in seconds
export MAILPAUSE="3"
export TESTPAUSE="30"

#USE: YES|NO
#LOG: GETALL|GETCURRENT
export PERF_USE_SAR_MONITOR="YES"
export PERF_USE_MONITOR="NO"
export PERF_LOG_MONITOR="GETCURRENT"

export HOSTNAME="$(hostname)"
export LOGGING="$PERF_HOME"
export LOGGING_CONSOLE_FILE=console.log

export CONF_QUEUE="$PERF_HOME/queue"
export CONF_QUEUE_COMPLETE="$PERF_HOME/queue/complete"

#REMOTE App Server Variables
export BBHOME="/usr/local/blackboard"
export BBUSER="bbuser"
export BBUSER_HOME="/home/bbuser"
#Provide a list of remote servers delimited by a "space"
#export SERVERS="app1.example.com app2.example.com"
export SERVERS=`cat $CLIENTINFO | mawk 'BEGIN { FS="\t" } { if ($1 == "APP_SERVER_HOSTNAMES") { print $2 }}'`

#REMOTE Database Server Variables
export BBUSER_DB="oracle"
export BBUSER_HOME_DB="/home/oracle"
#Provide a list of remote servers delimited by a "space"
export SERVERS_DB=`cat $CLIENTINFO | mawk 'BEGIN { FS="\t" } { if ($1 == "DB_SERVER_HOSTNAME") { print $2 }}'`
export SERVERS_DB_PORT="1521"

#Email Recipients (separate with commas)
export EMAIL_RECIPIENTS_RESULTS="root@localhost"
export EMAIL_RECIPIENTS_NOTIFICATION="root@localhost"

#Grinder Environemnt
export GRINDER_HOME="$PERF_HOME/grinder-3.10"

#JAVA_HOME on local/load generator system
#Finding Java -- Your Mileage May Vary
#The pipes below should generally work with configured/installed defaults, but
#you may need to customize if you want to use specific versions of java.
#Use with understanding and caution.
#For JRE
#export JAVA_HOME=$(readlink -f /usr/bin/java | sed "s:/bin/java::")
#For JDK
export JAVA_HOME=$(readlink -f /usr/bin/javac | sed "s:/bin/javac::")
#Extend path as needed
if [  "$(env | grep PATH | grep $JAVA_HOME/bin)" == "" ]
then
  #Will only get added once because of the check
  export PATH="$JAVA_HOME/bin:$PATH"
fi

#JAVA_HOME on the (remote) App Servers
export JAVA_HOME_REMOTE="/usr/lib/jvm/java-7-oracle"

### Local Configuration End###

################################################################################

#Utility Functions
function parse_config()
{
  local CONF=$(readlink -e -n -q $1)

  if [ -f $CONF ]
  then
    export CONFSTATUS="OK"
    export TESTTYPE="$(awk -F = '/^\s*test_type=/ {print $2}' $CONF)"
    export TESTNAME="$(awk -F = '/^\s*test_name=/ {print $2}' $CONF | sed s/[[:space:]]/-/g)"
    export TESTTARGET="$(awk -F = '/^\s*test_target=[isba]/ {print $2}' $CONF)"
    export PROCESSES_STUDENT="$(awk -F = '/^\s*processes_student=/ {printf "%.0f", $2}' $CONF)"
    export THREADS_STUDENT="$(awk -F = '/^\s*threads_student=/ {printf "%.0f", $2}' $CONF)"
    export PROCESSES_INSTRUCTOR="$(awk -F = '/^\s*processes_instructor=/ {printf "%.0f", $2}' $CONF)"
    export THREADS_INSTRUCTOR="$(awk -F = '/^\s*threads_instructor=/ {printf "%.0f", $2}' $CONF)"
    export TARGETURL="$(awk -F = '/^\s*target_url=/ {print $2}' $CONF)"

    #Convert minutes into milliseconds
    export DURATION="$(awk -F = '/^\s*duration=/ {printf "%.0f", $2}' $CONF)"
    export DURATION_MS="$(awk -F = '/^\s*duration=/ {printf "%.0f", $2 * 60 * 1000}' $CONF)"

    #Grinder Environemnt
    export GRINDER_DEBUG="$(awk -F = '/^\s*grinder_debug=/ {printf "%.0f", $2}' $CONF)"
    export GRINDER_RAMPUP="$(awk -F = '/^\s*grinder_rampup=/ {print $2}' $CONF)"
  else
    export CONFSTATUS="NOK"
    export TESTTYPE="baseline"
    export TESTNAME=""
    export TESTTARGET="b"
    export PROCESSES_STUDENT="0"
    export THREADS_STUDENT="0"
    export PROCESSES_INSTRUCTOR="0"
    export THREADS_INSTRUCTOR="0"
    export TARGETURL="127.0.0.1"

    #Convert minutes into milliseconds
    export DURATION="0"
    export DURATION_MS="0"

    #Grinder Environemnt
    export GRINDER_DEBUG="0"
    export GRINDER_RAMPUP="Rampup(1,2500)"
  fi
}

### REMOTE AGENT START ###
function execute_ssh_all_apps()
{
  for SERVER in $REMOTE_AGENT_SERVERS
  do
    echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Executing:ssh -n $REMOTE_AGENT_USER@$SERVER $*"
    ssh -n $REMOTE_AGENT_USER@$SERVER "$*" &
  done
}

function deploy_rsync_all_apps()
{
  if [ -d "$1" ]
  then
    for SERVER in $REMOTE_AGENT_SERVERS
    do
      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME:  Deploying $1 to $SERVER:$2"
      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Command executed: rsync -4 -avzh  --stats --progress --exclude=$PERF_HOME_RESULTS --exclude=$PERF_HOME_REPORTS  $1 $REMOTE_AGENT_USER@$SERVER:$2"
      rsync -4 -azh  --stats --progress --exclude=$PERF_HOME_RESULTS --exclude=$PERF_HOME_REPORTS --exclude=student --exclude=instructor  $1 $REMOTE_AGENT_USER@$SERVER:$2
    done
  else
    echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: Unable to deploy $1 to servers. Not a directory."
  fi
}
function retrieve_rsync_all_apps()
{
  if [ -d "$1" ]
  then
    for SERVER in $REMOTE_AGENT_SERVERS
    do
      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Retrieving $SERVER:$2 to $1 "
      echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Command executed: rsync -4 -avzh  --stats --progress    $REMOTE_AGENT_USER@$SERVER:$2 $1"
      rsync -4 -azh  --stats --progress    $REMOTE_AGENT_USER@$SERVER:$2 $1
    done
  else
    echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: Unable to deploy $1 to servers. Not a directory."
  fi
}

function retrieve_sar_data()
{

    DATETESTSTART=$(date -d "$1 5 minutes ago" +"%Y%m%d")
    TIMETESTSTART=$(date -d "$1 5 minutes ago" +"%H:%M:%S")
    DATETESTEND=$(date -d "$2" +"%Y%m%d")
    TIMETESTEND=$(date -d "$2" +"%H:%M:%S")
    SERVER=$3
    REPORTDIR=$4
    TYPE=$5
    
    
    echo -e "\n----------------------------------------------------------------------"
    echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Retrieving SAR Data for $TYPE Server $SERVER"
    echo -e "----------------------------------------------------------------------\n"


    #Test to see if we can SSH to the machine
    #SSHTEST=$(sshpass -p "$REMOTE_AGENT_USER_PASSWORD"  ssh -o StrictHostKeyChecking=no -n $REMOTE_AGENT_USER@$SERVER)
    #SSHTEST=$(sshpass -p "$REMOTE_AGENT_USER_PASSWORD" ssh -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=no  $REMOTE_AGENT_USER@$SERVER 2>&1 )
    #
    #if [[ "$SSHTEST" == *"ssh: Could not resolve hostname"* ]]; then
    #    echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: SSH FAILED with the following message: $SSHTEST"
    #    return 1 
    #elif [[ "$SSHTEST" == *"Permission denied, please try again."* ]]; then
    #    echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: SSH FAILED with the following message: $SSHTEST"
    #    return 1
    #fi
    
    #Check to see if SAR is installed
    #SARTEST=$(sshpass -p "$REMOTE_AGENT_USER_PASSWORD" ssh -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=no  $REMOTE_AGENT_USER@$SERVER sar -V 2>&1 )
    
    #Check to see if the sar file exist, error message recieved when it's not there
    #Note, this probably isn't as big of a deal as it'll just fail and keep moving
     #Invalid system activity file: /var/log/sa/201810/sa10


        while [ $DATETESTSTART -lt $DATETESTEND ]; #put the loop where you need it
        do
            #Iterate through the various SAR options
            for i in u r q w W b; 
            do 
                #only need to print this once, so we go with the first statement
                if [[ $i == "u" ]]; then
                    echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Date of $DATETESTSTART is less than the end of the test date $DATETESTEND";
                fi
                #break apart the date for use with sar
                YEARMONTH=$(date -d $DATETESTSTART +"%Y%m")
                DAY=$(date -d $DATETESTSTART +"%d")
                #Need to format to use for gnuplot
                GNUPLOTDATEFORMAT=$(date -d $DATETESTSTART +"%Y-%m-%d")
                
                echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Retrieving SAR $i data from $SERVER for $DATETESTSTART"
                #using SSH pass since we can't use ssh keys for app/db servers in MH
                #We call SAR for the specific date starting from the start of the test date
                sshpass -p "$REMOTE_AGENT_USER_PASSWORD"  ssh -o StrictHostKeyChecking=no -n $REMOTE_AGENT_USER@$SERVER LC_TIME="en_US.UTF-8" "sar -f /var/log/sa/$YEARMONTH/sa$DAY -s $TIMETESTSTART -$i | tail -n +4 | head -n -1" >> $REPORTDIR/sar_${SERVER}_${i}_tmp 
                
                if [[ $TYPE == "DB" ]]; then
                    #If this is the db, then we concatenate all files into a single file for plotting
                    convertSARtoGNUPLOTDateFormat  $REPORTDIR/sar_${SERVER}_${i}_tmp $GNUPLOTDATEFORMAT $REPORTDIR/sar_${TYPE}_${i}_gnuplot
                elif [[ $TYPE == "APP" ]] || [[ $TYPE == "LG" ]]; then
                     #If this is the app server, then we don't want to concatenate all of the files so that we can graph all servers on a single graph.  all files into a single file for plotting
                    convertSARtoGNUPLOTDateFormat  $REPORTDIR/sar_${SERVER}_${i}_tmp $GNUPLOTDATEFORMAT $REPORTDIR/sar_${SERVER}_${TYPE}_${i}_gnuplot
                fi
                #Test SSH
                #echo  -e " sshpass -p \"$REMOTE_AGENT_USER_PASSWORD\"  ssh -o StrictHostKeyChecking=no -n $REMOTE_AGENT_USER@$SERVER LC_TIME=\"en_US.UTF-8\" \"sar -f /var/log/sa/$YEARMONTH/sa$DAY -s $TIMETESTSTART -$i | tail -n +4 | head -n -1\" >> $REPORTDIR/sar_${SERVER}_${i}_tmp "
                #remove the original tmp file
                rm -fr $REPORTDIR/sar_${SERVER}_${i}_tmp
           done
           #if this is yesterday, we reset the timestart for the next day so that it catches everything from the begining
           DATETESTSTART=$(date -d "$DATETESTSTART+1 days" +"%Y%m%d")
           TIMETESTSTART="00:00:00"
           
        done

        
        
        #Iterate through the various SAR options
        for i in u r q w W b; 
            do 
                echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: Retrieving SAR $i data from $SERVER for $DATETESTEND"
                GNUPLOTDATEFORMAT=$(date -d $DATETESTEND +"%Y-%m-%d")
                #echo $i $TIMETESTSTART $SERVER
                #using SSH pass since we can't use ssh keys for app/db servers in MH
                sshpass -p "$REMOTE_AGENT_USER_PASSWORD"  ssh -o StrictHostKeyChecking=no -n $REMOTE_AGENT_USER@$SERVER LC_TIME="en_US.UTF-8" "sar -s $TIMETESTSTART -$i | tail -n +4 | head -n -1" >> $REPORTDIR/sar_${SERVER}_${i}_tmp 
                
                
                if [[ $TYPE == "DB" ]]; then
                    #If this is the db, then we concatenate all files into a single file for plotting
                    convertSARtoGNUPLOTDateFormat  $REPORTDIR/sar_${SERVER}_${i}_tmp $GNUPLOTDATEFORMAT $REPORTDIR/sar_${TYPE}_${i}_gnuplot
                elif [[ $TYPE == "APP" ]] || [[ $TYPE == "LG" ]]; then
                     #If this is the app server, then we don't want to concatenate all of the files so that we can graph all servers on a single graph.  all files into a single file for plotting
                    convertSARtoGNUPLOTDateFormat  $REPORTDIR/sar_${SERVER}_${i}_tmp $GNUPLOTDATEFORMAT $REPORTDIR/sar_${SERVER}_${TYPE}_${i}_gnuplot
                fi
                
                
                #echo  -e " sshpass -p \"$REMOTE_AGENT_USER_PASSWORD\"  ssh -o StrictHostKeyChecking=no -n $REMOTE_AGENT_USER@$SERVER LC_TIME=\"en_US.UTF-8\" \"sar -s $TIMETESTSTART -$i | tail -n +4 | head -n -1\" >> $REPORTDIR/sar_${SERVER}_${i}_tmp "
                #remove the original tmp file
                rm -fr $REPORTDIR/sar_${SERVER}_${i}_tmp
            done

}
function convertSARtoGNUPLOTDateFormat()
{

#Change the time to be gnuplot friendly, added the date in the format
# original SAR format  = 09:05:01 AM 
# Gnuplot format = 2018-10-07:9:10 AM 
awk -v DATE="$2" '/^[0-9]+:[0-9]+/{time = $1; 
if($2 == "PM" && substr(time,1,2) < 12) add = 12; 
else add = 0; 
$1 = substr(time,1,2)+add "" substr(time,3,3); 

if($2 == "AM" && substr(time,1,2)==12){$1 = "0" substr(time,3,3); }
print DATE":"$0}' $1 >> $3


}

function gnuplotSARData()
{
REPORTDIR=$1
TYPE=$2
TEMPCPU=""
TEMPMEM=""
TEMPLOADAVG=""
TEMPSWAP=""
TEMPIO=""

#if [ ! -f $file ] && [[ $TYPE == "DB" ]]; then
#    echo "`date  \"+%Y-%m-%d %T\"` ERROR $HOSTNAME: $file does not exist, nothing to graph"
#    return 1
#fi


    if [[ $TYPE == "DB" ]]; then
        #We Plot the whole C
        PLOTCPU=$( echo \"$REPORTDIR/sar_DB_u_gnuplot\" using 1:\(\$4+\$6+\$7\) with filledcurve x1 lc rgb \"grey\"  title \"$SERVERS_DB CPU Usage%\",\"$REPORTDIR/sar_DB_u_gnuplot\" using 1:4 with lines title \"CPU User%\",\"$REPORTDIR/sar_DB_u_gnuplot\" using 1:6 with lines title \"CPU SYS%\",\"$REPORTDIR/sar_DB_u_gnuplot\" using 1:7 with lines title \"CPU IOWAIT%\")
        PLOTMEM=$( echo \"$REPORTDIR/sar_DB_r_gnuplot\" using 1:5  with lines title \"MEM %Used\",\"$REPORTDIR/sar_DB_r_gnuplot\" using 1:\(\(\$6+\$7\)*100/\(\$3+\$4\)\)  with lines title \"MEM %buffers+disk cache\")
        PLOTLOADAVG=$( echo \"$REPORTDIR/sar_DB_q_gnuplot\" using 1:3 with lines title \"DB Run-q size%\",\"$REPORTDIR/sar_DB_q_gnuplot\" using 1:6 with lines title \"DB Load Avg-5\")
        PLOTSWAP=$( echo \"$REPORTDIR/sar_DB_W_gnuplot\" using 1:3 with lines title \"Pages swapin/s\",\"$REPORTDIR/sar_DB_W_gnuplot\" using 1:4 with lines title \"Pages swapout/s\")
        PLOTIO=$( echo \"$REPORTDIR/sar_DB_b_gnuplot\" using 1:3 with lines title \"tps\",\"$REPORTDIR/sar_DB_b_gnuplot\" using 1:4 with lines title \" rtps\",\"$REPORTDIR/sar_DB_b_gnuplot\" using 1:5  with lines title \"wtps\")
        SARCPUTHRESHOLD=`cat $CLIENTINFO | mawk 'BEGIN { FS="\t" } { if ($1 == "SARDBCPUTHRESHOLD") { print $2 }}'`
        OUTPUTFILE="${REPORTDIR}/sar_${TYPE}_gnuplot.svg"
    elif [[ $TYPE == "APP" ]]; then
        #We loop through each server to add it to the list
        for SERVER in $SERVERS;
            do            
            
            #if this is MH then the app server hostname is named are typically the following formart
            # <{ServerType&Usage}-{clientId}-{#/CR #}-{app #}.mhint i.e. fgtemp-147231-cr711805-app015.mhint
            #if this is true, for larger clients to clean up the graphs and make them more presentable, we just want the App#
            if [[ $SERVER == *"mhint" ]]; then
                SERVERTITLE=$(echo $SERVER |cut -d "-" -f 4|cut -d "." -f 1)
            fi
                #TEMPCPU=$TEMPCPU"\"$REPORTDIR/sar_${SERVER}_${TYPE}_u_gnuplot\" using 1:(\$4+\$6+\$7) with lines title \"$SERVERTITLE CPU Usage%\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_r_gnuplot\" using 1:5 with lines title \"$SERVER MEM  Usage%\","
                TEMPCPU=$TEMPCPU"\"$REPORTDIR/sar_${SERVER}_${TYPE}_u_gnuplot\" using 1:(\$4+\$6+\$7) with lines title \"$SERVERTITLE CPU Usage%\","
                TEMPMEM=$TEMPMEM"\"$REPORTDIR/sar_${SERVER}_${TYPE}_r_gnuplot\" using 1:5 with lines title \"$SERVERTITLE MEM Usage%\","
                TEMPLOADAVG=$TEMPLOADAVG"\"$REPORTDIR/sar_${SERVER}_${TYPE}_q_gnuplot\" using 1:6 with lines title \"$SERVERTITLE Load Avg-5\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_w_gnuplot\" using 1:3 with lines title \"$SERVERTITLE Proc Created/s\","
                TEMPSWAP=$TEMPSWAP"\"$REPORTDIR/sar_${SERVER}_${TYPE}_W_gnuplot\" using 1:3 with lines title \"$SERVERTITLE Pages swapin/s\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_W_gnuplot\" using 1:4 with lines title \"$SERVERTITLE Pages swapout/s\","
                TEMPIO=$TEMPIO"\"$REPORTDIR/sar_${SERVER}_${TYPE}_b_gnuplot\" using 1:3 with lines title \"$SERVERTITLE tps\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_b_gnuplot\" using 1:4 with lines title \"$SERVERTITLE rtps\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_b_gnuplot\" using 1:5  with lines title \"$SERVERTITLE wtps\","
               
            done
            
    #FOR LOAD GENERATORS
    elif [[ $TYPE == "LG" ]]; then
        #We loop through each server to add it to the list
        for SERVER in $REMOTE_AGENT_SERVERS;
            do   
                SERVERTITLE=$(echo $SERVER)
                #TEMPCPU=$TEMPCPU"\"$REPORTDIR/sar_${SERVER}_${TYPE}_u_gnuplot\" using 1:(\$4+\$6+\$7) with lines title \"$SERVERTITLE CPU Usage%\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_r_gnuplot\" using 1:5 with lines title \"$SERVER MEM  Usage%\","
                TEMPCPU=$TEMPCPU"\"$REPORTDIR/sar_${SERVER}_${TYPE}_u_gnuplot\" using 1:(\$4+\$6+\$7) with lines title \"$SERVERTITLE CPU Usage%\","
                TEMPMEM=$TEMPMEM"\"$REPORTDIR/sar_${SERVER}_${TYPE}_r_gnuplot\" using 1:5 with lines title \"$SERVERTITLE MEM Usage%\","
                TEMPLOADAVG=$TEMPLOADAVG"\"$REPORTDIR/sar_${SERVER}_${TYPE}_q_gnuplot\" using 1:6 with lines title \"$SERVERTITLE Load Avg-5\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_w_gnuplot\" using 1:3 with lines title \"$SERVERTITLE Proc Created/s\","
                TEMPSWAP=$TEMPSWAP"\"$REPORTDIR/sar_${SERVER}_${TYPE}_W_gnuplot\" using 1:3 with lines title \"$SERVERTITLE Pages swapin/s\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_W_gnuplot\" using 1:4 with lines title \"$SERVERTITLE Pages swapout/s\","
                TEMPIO=$TEMPIO"\"$REPORTDIR/sar_${SERVER}_${TYPE}_b_gnuplot\" using 1:3 with lines title \"$SERVERTITLE tps\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_b_gnuplot\" using 1:4 with lines title \"$SERVERTITLE rtps\",\"$REPORTDIR/sar_${SERVER}_${TYPE}_b_gnuplot\" using 1:5  with lines title \"$SERVERTITLE wtps\","
               
            done 

    fi
    if [[ $TYPE == "LG" ]] || [[ $TYPE == "APP" ]]; then
        PLOTCPU=$( echo ${TEMPCPU})
        PLOTMEM=$( echo ${TEMPMEM})
        PLOTLOADAVG=$( echo ${TEMPLOADAVG})
        PLOTSWAP=$( echo ${TEMPSWAP})
        PLOTIO=$( echo ${TEMPIO})
        SARCPUTHRESHOLD=`cat $CLIENTINFO | mawk 'BEGIN { FS="\t" } { if ($1 == "SARAPPCPUTHRESHOLD") { print $2 }}'`
        OUTPUTFILE="${REPORTDIR}/sar_${TYPE}_gnuplot.svg"
        GRAPHTITLE="CPU $TYPE"
    fi
    

    echo -e "\n----------------------------------------------------------------------"
    echo "`date  \"+%Y-%m-%d %T\"` INFO $HOSTNAME: GRAPHING SAR Data for $TYPE Server to $OUTPUTFILE"
    echo -e "----------------------------------------------------------------------\n"


gnuplot <<EOF

set terminal svg size 1200,1000 fixed fname 'Arial' fsize 10 butt solid 

#Sets the grey borders
set style line 80 lt rgb "#808080"

set xdata time
set timefmt "%Y-%m-%d:%H:%M"
set format x "%m/%d %H:%M"

set out "$OUTPUTFILE"
set size 
set origin 0,0


set multiplot layout 5,1 

set size 1,0.2
set origin 0,.80
set yrange [0:100]
set grid ytics lc rgb "grey" lw 1 lt 0 
set xtics nomirror
set grid xtics lc rgb "grey" lw 1 lt 0
set border 3 back linestyle 80 
set arrow from graph 0,first $SARCPUTHRESHOLD to graph 1,first $SARCPUTHRESHOLD nohead lc rgb "#FF0000" front;
plot $PLOTCPU
unset arrow

set size 1,0.2
set origin 0,0.60
set yrange [0:*]
set border 3 back linestyle 80 
plot $PLOTMEM


set size 1,0.2
set origin 0,0.40
set yrange [0:*]
set border 3 back linestyle 80 
plot $PLOTLOADAVG


set size 1,0.2
set origin 0,0.2
set yrange [0:*]
set border 3 back linestyle 80 

plot $PLOTSWAP


set size 1,0.2
set origin 0,0.0
set yrange [0:*]
set border 3 back linestyle 80 

plot $PLOTIO

unset multiplot

EOF


}

### REMOTE AGENT END ###
function download_scp_all_apps()
{
  for SERVER in $REMOTE_AGENT_SERVERS
  do
    # Make sure SERVER directory exists
    if [ ! -d $2/$SERVER ]; then
      mkdir -p $2/$SERVER
    fi

    echo "Downloading $1 from $SERVER"
    scp $REMOTE_AGENT_USER@$SERVER:$1 $2/$SERVER/
  done
}

function execute_ssh_all_db()
{
  for SERVER_DB in $SERVERS_DB
  do
    echo "Executing $* on $SERVER_DB"
    ssh -n $BBUSER_DB@$SERVER_DB "$*"
  done
}

function deploy_scp_all_db()
{
  if [ -f "$1" ]
  then
    for SERVER_DB in $SERVERS_DB
    do
      echo "Deploying $1 to $SERVER_DB:$2"
      scp -p $1 $BBUSER_DB@$SERVER_DB:$2
    done
  else
    echo "Unable to deploy $1 to servers. Not a file."
  fi
}

function download_scp_all_db()
{
  for SERVER_DB in $SERVERS_DB
  do
    # Make sure SERVER_DB directory exists
    if [ ! -d $2/$SERVER_DB ]; then
      mkdir -p $2/$SERVER_DB
    fi

    echo "Downloading $1 from $SERVER_DB"
    scp $BBUSER_DB@$SERVER_DB:$1 $2/$SERVER_DB/
  done
}