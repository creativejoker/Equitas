#!/bin/sh

# Show the error log from the last know run


user_type="$1"

last_run=`cat last_run_target`

case $user_type in
  i)
    echo "viewing instructor error logs"
    less $last_run/instructor/error*
    ;;
  s)
    echo "viewing student error logs"
    less $last_run/student/error*
    ;;
  *)
    echo "Incorrect User Type '$user_type'. Please specificy which out log to view (instructor [i], student[s])"
    ;;
esac
