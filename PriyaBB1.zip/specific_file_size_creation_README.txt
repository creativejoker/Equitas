On the LG system you can use the following commands to generate various file sizes for performance testing.

Or just run "create_perf_files.sh" to create these files in the "files" firectory.

http://linuxcommando.blogspot.com/2008/02/create-file-of-given-size.html

These can be used to file uploads into the system:
	- Assignment
	- Content System
	- Etc.

They can also be uploaded into the institution content collection to be downloaded as part of the content system downloads.

dd if=/dev/zero of=perf_50k.txt bs=50k count=1
dd if=/dev/zero of=perf_100k.txt bs=100k count=1
dd if=/dev/zero of=perf_200k.txt bs=200k count=1
dd if=/dev/zero of=perf_512k.txt bs=512k count=1
dd if=/dev/zero of=perf_1m.txt bs=1M count=1
dd if=/dev/zero of=perf_10m.txt bs=1M count=10
dd if=/dev/zero of=perf_100m.txt bs=1M count=100
dd if=/dev/zero of=perf_1g.txt bs=1M count=1024

