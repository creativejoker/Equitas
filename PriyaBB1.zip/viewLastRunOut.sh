#!/bin/sh

# Show the output log from the last know run


user_type="$1"

last_run=`cat last_run_target`

case $user_type in
  i)
    echo "viewing instructor out"
    less $last_run/instructor/out*
    ;;
  s)
    echo "viewing student out"
    less $last_run/student/out*
    ;;
  *)
    echo "Incorrect User Type '$user_type'. Please specificy which out log to view (instructor [i], student[s])"
    ;;
esac
